"use client"

import { useState, useEffect } from 'react'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { CalendarIcon, Filter, X } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

export interface TripFilters {
  status?: string
  clientUsername?: string
  dateFrom?: Date
  dateTo?: Date
  driverName?: string
  placa?: string
  exportador?: string
  searchTerm?: string
}

interface AdminTripFiltersProps {
  onFiltersChange: (filters: TripFilters) => void
  onReset: () => void
}

export function AdminTripFilters({ onFiltersChange, onReset }: AdminTripFiltersProps) {
  const [filters, setFilters] = useState<TripFilters>({})
  const [clients, setClients] = useState<string[]>([])
  const [exportadores, setExportadores] = useState<string[]>([])
  const supabase = createClient()

  useEffect(() => {
    loadFilterOptions()
  }, [])

  const loadFilterOptions = async () => {
    try {
      // Load unique clients
      const { data: clientData } = await supabase
        .from('client_users')
        .select('username')
        .order('username')
      
      if (clientData) {
        setClients(clientData.map(c => c.username))
      }

      // Load unique exportadores
      const { data: exportadorData } = await supabase
        .from('trips')
        .select('exportador')
        .not('exportador', 'is', null)
      
      if (exportadorData) {
        const uniqueExportadores = Array.from(new Set(exportadorData.map(t => t.exportador).filter(Boolean)))
        setExportadores(uniqueExportadores as string[])
      }
    } catch (error) {
      console.error('[v0] Error loading filter options:', error)
    }
  }

  const updateFilters = (key: keyof TripFilters, value: any) => {
    const newFilters = { ...filters, [key]: value }
    setFilters(newFilters)
    onFiltersChange(newFilters)
  }

  const handleReset = () => {
    setFilters({})
    onReset()
  }

  const statusOptions = [
    { value: 'all', label: 'Todos os Status' },
    { value: 'preparacao', label: 'Preparação' },
    { value: 'transito', label: 'Trânsito' },
    { value: 'aduana_origem', label: 'Aduana Origem' },
    { value: 'canal_vermelho', label: 'Aguardando Liberação (Canal Vermelho)' },
    { value: 'aduana_destino', label: 'Aduana Destino' },
    { value: 'entrega', label: 'Em Trânsito para Entrega' },
    { value: 'entregue', label: 'Concluída (Entregue)' },
  ]

  return (
    <Card className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">Filtros de Viagens</h3>
        </div>
        <Button variant="outline" size="sm" onClick={handleReset} className="gap-2">
          <X className="w-4 h-4" />
          Limpar Filtros
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Status Filter */}
        <div className="space-y-2">
          <Label>Status da Viagem</Label>
          <Select 
            value={filters.status || 'all'} 
            onValueChange={(value) => updateFilters('status', value === 'all' ? undefined : value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selecione o status" />
            </SelectTrigger>
            <SelectContent>
              {statusOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Client Filter */}
        <div className="space-y-2">
          <Label>Cliente</Label>
          <Select 
            value={filters.clientUsername || 'all'} 
            onValueChange={(value) => updateFilters('clientUsername', value === 'all' ? undefined : value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Todos os clientes" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os clientes</SelectItem>
              {clients.map((client) => (
                <SelectItem key={client} value={client}>
                  {client}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Exportador Filter */}
        <div className="space-y-2">
          <Label>Exportador</Label>
          <Select 
            value={filters.exportador || 'all'} 
            onValueChange={(value) => updateFilters('exportador', value === 'all' ? undefined : value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Todos os exportadores" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os exportadores</SelectItem>
              {exportadores.map((exp) => (
                <SelectItem key={exp} value={exp}>
                  {exp}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Date From */}
        <div className="space-y-2">
          <Label>Data Início</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-full justify-start text-left font-normal",
                  !filters.dateFrom && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {filters.dateFrom ? format(filters.dateFrom, "PPP", { locale: ptBR }) : "Selecione a data"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={filters.dateFrom}
                onSelect={(date) => updateFilters('dateFrom', date)}
                initialFocus
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* Date To */}
        <div className="space-y-2">
          <Label>Data Fim</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-full justify-start text-left font-normal",
                  !filters.dateTo && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {filters.dateTo ? format(filters.dateTo, "PPP", { locale: ptBR }) : "Selecione a data"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={filters.dateTo}
                onSelect={(date) => updateFilters('dateTo', date)}
                initialFocus
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* Driver Name */}
        <div className="space-y-2">
          <Label>Nome do Motorista</Label>
          <Input
            placeholder="Digite o nome..."
            value={filters.driverName || ''}
            onChange={(e) => updateFilters('driverName', e.target.value || undefined)}
          />
        </div>

        {/* Placa */}
        <div className="space-y-2">
          <Label>Placa (Cavalo ou Carreta)</Label>
          <Input
            placeholder="Digite a placa..."
            value={filters.placa || ''}
            onChange={(e) => updateFilters('placa', e.target.value || undefined)}
          />
        </div>

        {/* Search Term */}
        <div className="space-y-2 md:col-span-2">
          <Label>Busca Geral (CRT, Referência, etc.)</Label>
          <Input
            placeholder="Digite para buscar..."
            value={filters.searchTerm || ''}
            onChange={(e) => updateFilters('searchTerm', e.target.value || undefined)}
          />
        </div>
      </div>
    </Card>
  )
}
