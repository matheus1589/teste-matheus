"use client"

import type React from "react"
import { useEffect, useRef, useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { X } from "lucide-react"

interface AddressHistory {
  id: string
  address: string
  timestamp: number
}

interface AddressInputWithHistoryProps {
  id: string
  label: string
  placeholder: string
  value: string
  onChange: (value: string) => void
}

export function AddressInputWithHistory({ id, label, placeholder, value, onChange }: AddressInputWithHistoryProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [suggestions, setSuggestions] = useState<(AddressHistory | { address: string; isCep?: boolean })[]>([])
  const [selectedIndex, setSelectedIndex] = useState(-1)
  const [history, setHistory] = useState<AddressHistory[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  // Load history from localStorage
  useEffect(() => {
    const stored = localStorage.getItem(`address-history-${id}`)
    if (stored) {
      setHistory(JSON.parse(stored))
    }
  }, [id])

  const searchByName = async (query: string) => {
    if (query.length < 3) {
      setSuggestions([])
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch(`/api/search-address?q=${encodeURIComponent(query)}`)

      if (!response.ok) {
        console.error("[v0] Search failed with status:", response.status)
        setSuggestions([])
        setIsLoading(false)
        return
      }

      const data = await response.json()

      if (data && Array.isArray(data) && data.length > 0) {
        const results = data.map((item: any) => ({
          address: item.display_name || `${item.name}, ${item.address?.city || item.address?.state || "Brasil"}`,
          isFromNominatim: true,
        }))
        setSuggestions(results)
      } else {
        setSuggestions([])
      }
    } catch (error) {
      console.error("[v0] Name search error:", error)
      setSuggestions([])
    } finally {
      setIsLoading(false)
    }
  }

  // Search by CEP
  const searchByCep = async (cep: string) => {
    const cleanCep = cep.replace(/\D/g, "")
    if (cleanCep.length !== 8) {
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`)
      const data = await response.json()

      if (data.erro) {
        setSuggestions([])
        return
      }

      const fullAddress = `${data.logradouro}, ${data.bairro}, ${data.localidade} - ${data.uf}`
      onChange(fullAddress)
      addToHistory(fullAddress)
      setShowSuggestions(false)
      setSuggestions([])
    } catch (error) {
      console.error("[v0] CEP search error:", error)
      setSuggestions([])
    } finally {
      setIsLoading(false)
    }
  }

  // Add address to history
  const addToHistory = (address: string) => {
    const newEntry: AddressHistory = {
      id: Date.now().toString(),
      address,
      timestamp: Date.now(),
    }

    const updated = [newEntry, ...history.filter((h) => h.address !== address)].slice(0, 10)
    setHistory(updated)
    localStorage.setItem(`address-history-${id}`, JSON.stringify(updated))
  }

  // Remove from history
  const removeFromHistory = (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    const updated = history.filter((h) => h.id !== id)
    setHistory(updated)
    localStorage.setItem(`address-history-${id}`, JSON.stringify(updated))
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = e.target.value
    onChange(inputValue)

    if (inputValue.length === 0) {
      setSuggestions(history)
      setShowSuggestions(true)
      setSelectedIndex(-1)
      return
    }

    const cleanInput = inputValue.replace(/\D/g, "")
    if (cleanInput.length === 8 && inputValue.replace(/\D/g, "").length === 8) {
      // If it's 8 digits, treat as CEP
      searchByCep(inputValue)
    } else if (inputValue.length >= 3) {
      // Otherwise search by name using Nominatim via proxy
      searchByName(inputValue)
    }

    setShowSuggestions(true)
    setSelectedIndex(-1)
  }

  const handleSuggestionClick = (address: string) => {
    onChange(address)
    addToHistory(address)
    setShowSuggestions(false)
    setSuggestions([])
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!showSuggestions || suggestions.length === 0) return

    switch (e.key) {
      case "ArrowDown":
        e.preventDefault()
        setSelectedIndex((prev) => (prev < suggestions.length - 1 ? prev + 1 : 0))
        break
      case "ArrowUp":
        e.preventDefault()
        setSelectedIndex((prev) => (prev > 0 ? prev - 1 : suggestions.length - 1))
        break
      case "Enter":
        e.preventDefault()
        if (selectedIndex >= 0) {
          handleSuggestionClick(suggestions[selectedIndex].address)
        }
        break
      case "Escape":
        setShowSuggestions(false)
        setSuggestions([])
        setSelectedIndex(-1)
        break
    }
  }

  return (
    <div className="space-y-2 relative">
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <Input
          ref={inputRef}
          id={id}
          placeholder={placeholder}
          value={value}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onFocus={() => {
            if (!value) {
              setSuggestions(history)
              setShowSuggestions(true)
            }
          }}
          autoComplete="off"
          disabled={isLoading}
        />
        <p className="text-xs text-muted-foreground mt-1">
          💡 Digite um CEP (8 dígitos) ou o nome do endereço/rua/bairro
        </p>
      </div>

      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-background border border-input rounded-md shadow-md z-50 max-h-64 overflow-y-auto">
          {suggestions.map((suggestion, index) => (
            <button
              key={suggestion.id || suggestion.address}
              type="button"
              onClick={() => handleSuggestionClick(suggestion.address)}
              className={`w-full text-left px-3 py-2 text-sm hover:bg-muted transition flex items-center justify-between group ${
                index === selectedIndex ? "bg-muted" : ""
              }`}
            >
              <span>{suggestion.address}</span>
              {"timestamp" in suggestion && (
                <button
                  onClick={(e) => removeFromHistory(suggestion.id, e)}
                  className="opacity-0 group-hover:opacity-100 transition"
                >
                  <X className="w-4 h-4 text-muted-foreground hover:text-foreground" />
                </button>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
