"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Package, AlertCircle, CheckCircle, Clock, XCircle, FileText } from "lucide-react"
import { toast } from "sonner"

interface CollectionRequest {
  id: string
  collection_type: string
  status: string
  is_chemical: boolean
  driver_name: string | null
  origin: string | null
  destination: string | null
  pickup_address: string | null
  delivery_address: string | null
  ncm_products: string | null
  net_weight: number | null
  product_weight: number | null
  cargo_type: string | null
  volume_quantity: number | null
  is_container: boolean | null
  container_size: string | null
  is_isotank: boolean | null
  additional_info_requested: string | null
  created_at: string
  approved_at: string | null
}

const statusConfig = {
  pendente: {
    label: "Pendente",
    icon: Clock,
    color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-950 dark:text-yellow-200",
    badge: "bg-yellow-200 dark:bg-yellow-800 text-yellow-900 dark:text-yellow-100",
  },
  aprovada: {
    label: "Aprovada",
    icon: CheckCircle,
    color: "bg-green-100 text-green-800 dark:bg-green-950 dark:text-green-200",
    badge: "bg-green-200 dark:bg-green-800 text-green-900 dark:text-green-100",
  },
  rejeitada: {
    label: "Rejeitada",
    icon: XCircle,
    color: "bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-200",
    badge: "bg-red-200 dark:bg-red-800 text-red-900 dark:text-red-100",
  },
  aguardando_info: {
    label: "Aguardando Informações",
    icon: AlertCircle,
    color: "bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-200",
    badge: "bg-orange-200 dark:bg-orange-800 text-orange-900 dark:text-orange-100",
  },
}

export function CollectionRequestsList() {
  const [requests, setRequests] = useState<CollectionRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadRequests()
  }, [])

  const loadRequests = async () => {
    try {
      setError(null)
      const response = await fetch("/api/collection-requests/list")

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        console.log("[v0] API error response:", response.status, errorData)
        throw new Error(errorData.error || `HTTP ${response.status}: Failed to load requests`)
      }

      const data = await response.json()
      console.log("[v0] Collection requests loaded:", data)
      setRequests(data || [])
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error"
      console.log("[v0] Load error:", errorMessage)
      setError(errorMessage)
      toast.error(`Erro ao carregar solicitações: ${errorMessage}`)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <Card className="p-12 text-center">
        <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4 animate-pulse" />
        <p className="text-muted-foreground">Carregando solicitações...</p>
      </Card>
    )
  }

  if (error) {
    return (
      <Alert className="border-red-200 bg-red-50 dark:bg-red-950/20 dark:border-red-800">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          <strong>Erro ao carregar:</strong> {error}
        </AlertDescription>
      </Alert>
    )
  }

  if (requests.length === 0) {
    return (
      <Card className="p-12 text-center">
        <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-semibold mb-2">Nenhuma solicitação de coleta</h3>
        <p className="text-muted-foreground">Crie uma nova solicitação para começar</p>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {requests.map((request) => {
        const status = statusConfig[request.status as keyof typeof statusConfig] || statusConfig.pendente
        const Icon = status.icon

        return (
          <Card key={request.id} className="p-6">
            <div className="space-y-4">
              {/* Header */}
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3 flex-1">
                  <div className={`p-3 rounded-lg ${status.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold">
                        {request.collection_type === "exportacao" ? "Exportação" : "Importação"}
                      </h4>
                      <Badge className={status.badge}>{status.label}</Badge>
                      {request.is_chemical && <Badge variant="outline">Química</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {new Date(request.created_at).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                </div>
              </div>

              {/* Details */}
              <div className="grid md:grid-cols-2 gap-4 py-4 border-y">
                {request.pickup_address && (
                  <div>
                    <p className="text-xs text-muted-foreground font-semibold">COLETA</p>
                    <p className="text-sm">{request.pickup_address}</p>
                  </div>
                )}
                {request.delivery_address && (
                  <div>
                    <p className="text-xs text-muted-foreground font-semibold">ENTREGA</p>
                    <p className="text-sm">{request.delivery_address}</p>
                  </div>
                )}
                {request.cargo_type && (
                  <div>
                    <p className="text-xs text-muted-foreground font-semibold">TIPO DE CARGA</p>
                    <p className="text-sm capitalize">{request.cargo_type}</p>
                  </div>
                )}
                {request.volume_quantity && (
                  <div>
                    <p className="text-xs text-muted-foreground font-semibold">VOLUMES</p>
                    <p className="text-sm">{request.volume_quantity} un.</p>
                  </div>
                )}
                {request.product_weight && (
                  <div>
                    <p className="text-xs text-muted-foreground font-semibold">PESO</p>
                    <p className="text-sm">{request.product_weight} kg</p>
                  </div>
                )}
                {request.is_isotank && (
                  <div>
                    <Badge variant="outline" className="bg-purple-50 dark:bg-purple-950">
                      Isotank
                    </Badge>
                  </div>
                )}
              </div>

              {/* Additional Info Alert */}
              {request.additional_info_requested && (
                <Alert className="border-orange-200 bg-orange-50 dark:bg-orange-950/20 dark:border-orange-800">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Informações Solicitadas:</strong> {request.additional_info_requested}
                  </AlertDescription>
                </Alert>
              )}

              {/* Action */}
              {request.status === "aguardando_info" && (
                <Button variant="outline" className="w-full gap-2 bg-transparent">
                  <FileText className="w-4 h-4" />
                  Adicionar Informações
                </Button>
              )}
            </div>
          </Card>
        )
      })}
    </div>
  )
}
