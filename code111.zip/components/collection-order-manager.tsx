"use client"

import type React from "react"
import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Sheet, Table, Download, FileSpreadsheet, AlertCircle, User, Share2, Check, Mail, MessageCircle } from 'lucide-react'
import * as XLSX from "xlsx"
import { jsPDF } from "jspdf"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { createClient } from "@/lib/supabase/client"

interface CollectionOrderData {
  motorista: string
  cpf: string
  placaCavalo: string
  placaCarreta: string
  origem: string
  destino: string
  exportador: string
  importador: string
  fatura: string
  previsaoChegada: string
  // Fixed fields
  data: string
  numeroProvedor: string
  contato: string
  telefone: string
  email: string
  permisso: string
  vencimentoPermisso: string
  seguro: string
  apolice: string
  observacoes: string
}

interface DriverData {
  motorista: string
  cpf: string
  placaCavalo: string
  placaCarreta: string
  origem: string
  destino: string
  exportador: string
  importador: string
  fatura: string
  cnpj: string
  razaoSocial: string
  nomeFantasia: string
  endereco: string
  // ANTT fields
  taraCavalo?: string
  taraCarreta?: string
}

interface ImportCollectionOrderData {
  motorista: string
  cpf: string
  placaCavalo: string
  placaCarreta: string
  localCarregamento: string
  destino: string
  exportador: string
  importador: string
  fatura: string
  previsaoChegada: string
  data: string
  numeroProvedor: string
  transporte: string
  contato: string
  telefone: string
  email: string
  taraCavalo: string
  taraCarreta: string
  permisso: string
  vencimentoPermisso: string
  seguro: string
  apolice: string
  cnpjAntt: string
  razaoSocial: string
  nomeFantasia: string
  enderecoAntt: string
  observacoes: string
}

export function CollectionOrderManager() {
  const [activeTab, setActiveTab] = useState("exportacao")
  
  const [sheetUrl, setSheetUrl] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [drivers, setDrivers] = useState<DriverData[]>([])
  const [selectedDriver, setSelectedDriver] = useState<string>("")
  
  const [orderData, setOrderData] = useState<CollectionOrderData>({
    motorista: "",
    cpf: "",
    placaCavalo: "",
    placaCarreta: "",
    origem: "",
    destino: "",
    exportador: "",
    importador: "",
    fatura: "",
    previsaoChegada: "",
    // Default fixed values
    data: new Date().toLocaleDateString("pt-BR"),
    numeroProvedor: "",
    contato: "Izabelle / Leonardo",
    telefone: "(47) 9999-0395 / (47) 9938-3232",
    email: "followup@inlog.biz / leonardo.silva@inlog.biz",
    permisso: "11063 C 10781",
    vencimentoPermisso: "5/26/2032",
    seguro: "TOKIO MARINE",
    apolice: "320 4400188 - 12/2025",
    observacoes: "",
  })

  const [importOrderData, setImportOrderData] = useState<ImportCollectionOrderData>({
    motorista: "",
    cpf: "",
    placaCavalo: "",
    placaCarreta: "",
    localCarregamento: "",
    destino: "",
    exportador: "",
    importador: "",
    fatura: "",
    previsaoChegada: "",
    data: new Date().toLocaleDateString("pt-BR"),
    numeroProvedor: "",
    transporte: "INTEGRAÇÃO LOGISTICA - CNPJ: 06.009.235/0001-20",
    contato: "Izabelle / Leonardo",
    telefone: "(47) 9999-0395 / (47) 9938-3232",
    email: "followup@inlog.biz / leonardo.silva@inlog.biz",
    taraCavalo: "8850",
    taraCarreta: "10200",
    permisso: "11063 C 10781",
    vencimentoPermisso: "5/26/2032",
    seguro: "TOKIO MARINE",
    apolice: "320 4400188 - 12/2025",
    cnpjAntt: "06.009.235/0001-20",
    razaoSocial: "INTEGRACAO LOGISTICA LTDA",
    nomeFantasia: "INLOG",
    enderecoAntt: "AV DR. REINALDO SCHMITHAUSEN 495 / CORDEIROS / ITAJAÍ-SC / BRASIL",
    observacoes: "",
  })

  const [shareEmail, setShareEmail] = useState("")
  const [shareDialogOpen, setShareDialogOpen] = useState(false)
  const [shareCopied, setShareCopied] = useState(false)

  const loadFromGoogleSheets = async () => {
    setIsLoading(true)
    setError("")

    try {
      const sheetIdMatch = sheetUrl.match(/\/d\/([a-zA-Z0-9-_]+)/)
      if (!sheetIdMatch) {
        throw new Error("URL da planilha inválida")
      }

      const sheetId = sheetIdMatch[1]
      
      const csvUrl1 = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv&gid=0`
      const csvUrl2 = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv&gid=1`

      // Load Sheet 1
      const response1 = await fetch(csvUrl1)
      if (!response1.ok) {
        throw new Error("Erro ao carregar planilha. Verifique se ela está pública.")
      }

      const csvText1 = await response1.text()
      const workbook1 = XLSX.read(csvText1, { type: "string" })
      const firstSheet = workbook1.Sheets[workbook1.SheetNames[0]]
      const data = XLSX.utils.sheet_to_json(firstSheet)

      console.log("[v0] Loaded sheet 1 data:", data)

      // Load Sheet 2 (ANTT data)
      let anttData: any[] = []
      try {
        const response2 = await fetch(csvUrl2)
        if (response2.ok) {
          const csvText2 = await response2.text()
          const workbook2 = XLSX.read(csvText2, { type: "string" })
          const secondSheet = workbook2.Sheets[workbook2.SheetNames[0]]
          anttData = XLSX.utils.sheet_to_json(secondSheet)
          console.log("[v0] Loaded sheet 2 ANTT data:", anttData)
        }
      } catch (err) {
        console.warn("[v0] Sheet 2 not found or error loading, using default ANTT data")
      }

      const loadedDrivers: DriverData[] = data.map((row: any) => {
        // Extract CPF from various possible formats
        let cpf = row["CPF:"] || row["CPF"] || row["cpf"] || ""
        cpf = cpf.toString().replace(/\s*Hrs.*$/i, "").trim()
        
        let cnpj = row["CNPJ:"] || row["CNPJ"] || row["cnpj"] || ""
        cnpj = cnpj.toString().trim()
        
        let razaoSocial = row["Razão Social:\r"] || row["Razão Social:"] || row["Razão Social"] || row["razao_social"] || ""
        razaoSocial = razaoSocial.toString().trim()
        
        let nomeFantasia = row["Nome Fantasia\r:"] || row["Nome Fantasia:"] || row["Nome Fantasia"] || row["nome_fantasia"] || ""
        nomeFantasia = nomeFantasia.toString().trim()
        
        let endereco = row["Endereço:"] || row["Endereço"] || row["Endereco"] || row["endereco"] || ""
        endereco = endereco.toString().trim()

        const driverName = row["Motorista"] || row["motorista"] || ""
        const placaCavalo = row["Placa Cavalo"] || row["Placa cavalo"] || row["placa_cavalo"] || row["placaCavalo"] || ""
        const placaCarreta = row["Placa Carreta"] || row["Placa carreta"] || row["placa_carreta"] || row["placaCarreta"] || ""
        
        let anttInfo = {
          taraCavalo: "",
          taraCarreta: "",
          cnpjAntt: cnpj || "06.009.235/0001-20",
          razaoSocialAntt: razaoSocial || "INTEGRACAO LOGISTICA LTDA",
          nomeFantasiaAntt: nomeFantasia || "INLOG",
          enderecoAntt: endereco || "AV DR. REINALDO SCHMITHAUSEN 495 / CORDEIROS / ITAJAÍ-SC / BRASIL"
        }

        // Search for matching ANTT data in sheet 2
        if (anttData.length > 0) {
          const anttMatch = anttData.find((anttRow: any) => {
            const anttMotorista = (anttRow["Motorista"] || anttRow["motorista"] || "").toString().trim().toLowerCase()
            const anttPlacaCavalo = (anttRow["Placa Cavalo"] || anttRow["Placa cavalo"] || anttRow["placa_cavalo"] || anttRow["placaCavalo"] || "").toString().trim().toUpperCase()
            const anttPlacaCarreta = (anttRow["Placa Carreta"] || anttRow["Placa carreta"] || anttRow["placa_carreta"] || anttRow["placaCarreta"] || "").toString().trim().toUpperCase()
            
            return (anttMotorista === driverName.trim().toLowerCase()) ||
                   (anttPlacaCavalo && anttPlacaCavalo === placaCavalo.trim().toUpperCase()) ||
                   (anttPlacaCarreta && anttPlacaCarreta === placaCarreta.trim().toUpperCase())
          })

          if (anttMatch) {
            console.log("[v0] Found ANTT match for driver:", driverName, anttMatch)
            anttInfo = {
              taraCavalo: anttMatch["Tara Cavalo"] || anttMatch["Tara cavalo"] || anttMatch["tara_cavalo"] || anttMatch["taraCavalo"] || "",
              taraCarreta: anttMatch["Tara Carreta"] || anttMatch["Tara carreta"] || anttMatch["tara_carreta"] || anttMatch["taraCarreta"] || "",
              cnpjAntt: anttMatch["CNPJ"] || anttMatch["cnpj"] || cnpj || "06.009.235/0001-20",
              razaoSocialAntt: anttMatch["Razão Social"] || anttMatch["Razao Social"] || anttMatch["razao_social"] || razaoSocial || "INTEGRACAO LOGISTICA LTDA",
              nomeFantasiaAntt: anttMatch["Nome Fantasia"] || anttMatch["nome_fantasia"] || nomeFantasia || "INLOG",
              enderecoAntt: anttMatch["Endereço"] || anttMatch["Endereco"] || anttMatch["endereco"] || endereco || "AV DR. REINALDO SCHMITHAUSEN 495 / CORDEIROS / ITAJAÍ-SC / BRASIL"
            }
          }
        }
        
        return {
          motorista: driverName,
          cpf: cpf,
          placaCavalo: placaCavalo,
          placaCarreta: placaCarreta,
          origem: row["Origem"] || row["origem"] || "",
          destino: row["Destino"] || row["destino"] || "",
          exportador: row["Exportador"] || row["exportador"] || "",
          importador: row["Importador"] || row["importador"] || "",
          fatura: row["Fatura"] || row["fatura"] || "",
          cnpj: anttInfo.cnpjAntt,
          razaoSocial: anttInfo.razaoSocialAntt,
          nomeFantasia: anttInfo.nomeFantasiaAntt,
          endereco: anttInfo.enderecoAntt,
          taraCavalo: anttInfo.taraCavalo,
          taraCarreta: anttInfo.taraCarreta,
        }
      })

      setDrivers(loadedDrivers.filter(d => d.motorista))
      
      if (loadedDrivers.length > 0 && loadedDrivers[0].motorista) {
        setSelectedDriver(loadedDrivers[0].motorista)
        fillDriverData(loadedDrivers[0])
      }

      uploadTripsToPortal(loadedDrivers, data)
    } catch (err: any) {
      console.error("[v0] Error loading sheet:", err)
      setError(err.message || "Erro ao carregar planilha")
    } finally {
      setIsLoading(false)
    }
  }

  const uploadTripsToPortal = async (driversData: DriverData[], rawData: any[]) => {
    const supabase = createClient()
    
    console.log("[v0] ===== Starting uploadTripsToPortal =====")
    console.log("[v0] driversData length:", driversData.length)
    console.log("[v0] rawData length:", rawData.length)
    
    try {
      const { data: existingTrips, error: fetchError } = await supabase
        .from('trips')
        .select('crt')
      
      if (fetchError) {
        console.error("[v0] Error fetching existing trips:", fetchError)
        alert("Erro ao verificar viagens existentes")
        return
      }
      
      console.log("[v0] Existing trips in database:", existingTrips?.length || 0)
      
      const existingCRTs = new Set((existingTrips || []).map((trip: any) => trip.crt))
      
      const newTrips: any[] = []
      
      rawData.forEach((row: any, index: number) => {
        const driver = driversData[index]
        if (!driver || !driver.motorista) {
          console.log(`[v0] ⚠️ Row ${index} - No driver data found, skipping`)
          return
        }
        
        const crt = row["CRT"] || row["crt"] || row["Crt"] || `CRT-${Date.now()}-${index}`
        
        const usernameFromSheet = row["usuario cliente:"] || row["Usuario cliente:"] || row["Usuario Cliente:"] || 
                        row["usuario cliente"] || row["Usuario cliente"] || row["Usuario Cliente"] ||
                        row["USUARIO CLIENTE:"] || row["USUARIO CLIENTE"] ||
                        row["Usuario"] || row["usuario"] || row["Username"] || row["username"] || 
                        row["USER"] || row["user"] || row["client"] || row["cliente"] || ""
        
        const cleanUsername = String(usernameFromSheet || "").trim().toLowerCase()
        
        console.log(`[v0] Row ${index} - CRT: ${crt}, username column: "${usernameFromSheet}", cleaned: "${cleanUsername}", exportador: "${driver.exportador}"`)
        
        if (!cleanUsername || cleanUsername === "" || cleanUsername === "undefined" || cleanUsername === "null") {
          console.log(`[v0] ⚠️ Skipping trip ${crt} - no valid username assigned`)
          return
        }
        
        if (existingCRTs.has(crt)) {
          console.log(`[v0] ⚠️ Skipping duplicate CRT: ${crt}`)
          return
        }
        
        const reference = row["Referencia"] || row["referencia"] || row["Reference"] || row["REFERENCIA"] || `REF-${index + 1}`
        
        let dataInicio = row["Data"] || row["data"] || row["DATE"] || row["date"] || row["Data:"] || ""
        if (dataInicio) {
          if (typeof dataInicio === 'number') {
            const excelEpoch = new Date(Date.UTC(1899, 11, 30))
            const date = new Date(excelEpoch.getTime() + dataInicio * 24 * 60 * 60 * 1000)
            dataInicio = date.toISOString().split('T')[0]
            console.log(`[v0] Converted Excel date number to ISO: ${dataInicio}`)
          } else if (typeof dataInicio === 'string') {
            const brazilianDateMatch = dataInicio.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/)
            if (brazilianDateMatch) {
              const [, day, month, year] = brazilianDateMatch
              dataInicio = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`
            }
          }
        } else {
          dataInicio = new Date().toISOString().split('T')[0]
        }
        
        console.log(`[v0] ✅ Preparing trip ${crt} for user: ${cleanUsername}, startDate: ${dataInicio}`)
        
        newTrips.push({
          crt: crt,
          client_reference: reference,
          client_username: cleanUsername,
          start_date: dataInicio,
          end_date: null,
          origem: driver.origem,
          destino: driver.destino,
          status: "Em Trânsito",
          proof_of_delivery_url: null,
          fatura: driver.fatura || row["Fatura"] || row["fatura"] || "",
          driver_name: driver.motorista,
          driver_cpf: driver.cpf || "",
          placa_cavalo: driver.placaCavalo,
          placa_carreta: driver.placaCarreta,
          exportador: driver.exportador,
          importador: driver.importador || ""
        })
      })
      
      console.log(`[v0] Total trips to insert: ${newTrips.length}`)
      
      if (newTrips.length > 0) {
        console.log("[v0] Inserting trips into Supabase...")
        console.log("[v0] First trip sample:", JSON.stringify(newTrips[0], null, 2))
        
        const { data: insertedData, error: insertError } = await supabase
          .from('trips')
          .insert(newTrips)
          .select()
        
        if (insertError) {
          console.error("[v0] Error inserting trips:", insertError)
          alert(`Erro ao salvar viagens no banco de dados: ${insertError.message}`)
          return
        }
        
        console.log("[v0] ✅ Successfully inserted trips:", insertedData?.length || 0)
        alert(`${insertedData?.length || newTrips.length} viagens foram importadas com sucesso para o portal do cliente!`)
      } else {
        console.log("[v0] ⚠️ No new trips to insert")
        alert("Nenhuma viagem nova foi encontrada para importar. Verifique se a coluna 'usuario cliente:' está preenchida na planilha.")
      }
      
      console.log("[v0] ===== Finished uploadTripsToPortal =====")
    } catch (error) {
      console.error("[v0] Unexpected error in uploadTripsToPortal:", error)
      alert("Erro inesperado ao processar viagens")
    }
  }

  const fillDriverData = (driver: DriverData) => {
    if (activeTab === "exportacao") {
      setOrderData({
        ...orderData,
        motorista: driver.motorista,
        cpf: driver.cpf,
        placaCavalo: driver.placaCavalo,
        placaCarreta: driver.placaCarreta,
        origem: driver.origem,
        destino: driver.destino,
        exportador: driver.exportador,
        importador: driver.importador,
        fatura: driver.fatura,
      })
    } else {
      setImportOrderData({
        ...importOrderData,
        motorista: driver.motorista,
        cpf: driver.cpf,
        placaCavalo: driver.placaCavalo,
        placaCarreta: driver.placaCarreta,
        localCarregamento: driver.origem,
        destino: driver.destino,
        exportador: driver.exportador,
        importador: driver.importador,
        fatura: driver.fatura,
        taraCavalo: driver.taraCavalo || "8850",
        taraCarreta: driver.taraCarreta || "10200",
        cnpjAntt: driver.cnpj || "06.009.235/0001-20",
        razaoSocial: driver.razaoSocial || "INTEGRACAO LOGISTICA LTDA",
        nomeFantasia: driver.nomeFantasia || "INLOG",
        enderecoAntt: driver.endereco || "AV DR. REINALDO SCHMITHAUSEN 495 / CORDEIROS / ITAJAÍ-SC / BRASIL",
      })
    }
  }

  const handleDriverSelect = (driverName: string) => {
    setSelectedDriver(driverName)
    const driver = drivers.find(d => d.motorista === driverName)
    if (driver) {
      fillDriverData(driver)
    }
  }

  const handleInputChange = (field: keyof CollectionOrderData, value: string) => {
    setOrderData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleImportInputChange = (field: keyof ImportCollectionOrderData, value: string) => {
    setImportOrderData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const downloadAsExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet([
      { Campo: "Data", Valor: orderData.data },
      { Campo: "N° Provedor", Valor: orderData.numeroProvedor },
      { Campo: "Contato", Valor: orderData.contato },
      { Campo: "Telefone", Valor: orderData.telefone },
      { Campo: "E-mail", Valor: orderData.email },
      { Campo: "Motorista", Valor: orderData.motorista },
      { Campo: "CPF", Valor: orderData.cpf },
      { Campo: "Placa Cavalo", Valor: orderData.placaCavalo },
      { Campo: "Placa Carreta", Valor: orderData.placaCarreta },
      { Campo: "Origem", Valor: orderData.origem },
      { Campo: "Destino", Valor: orderData.destino },
      { Campo: "Exportador", Valor: orderData.exportador },
      { Campo: "Importador", Valor: orderData.importador },
      { Campo: "Fatura", Valor: orderData.fatura },
      { Campo: "Previsão de Chegada", Valor: orderData.previsaoChegada },
      { Campo: "Permisso", Valor: orderData.permisso },
      { Campo: "Vencimento", Valor: orderData.vencimentoPermisso },
      { Campo: "Seguro", Valor: orderData.seguro },
      { Campo: "Apólice e Validade", Valor: orderData.apolice },
      { Campo: "Observações", Valor: orderData.observacoes },
    ])

    const workbook = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(workbook, worksheet, "Ordem de Coleta")
    
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' })
    const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `Ordem_Coleta_${orderData.numeroProvedor || "novo"}.xlsx`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  const downloadAsPDF = async () => {
    try {
      const pdfBlob = await generatePDFBlob()
      
      const url = URL.createObjectURL(pdfBlob)
      const link = document.createElement('a')
      link.href = url
      link.download = `Ordem_Coleta_${orderData.numeroProvedor || "novo"}.pdf`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error("[v0] Error downloading PDF:", error)
      alert("Erro ao gerar PDF. Por favor, tente novamente.")
    }
  }

  const generatePDFBlob = async () => {
    try {
      const doc = new jsPDF()
      
      doc.setDrawColor(64, 156, 193)
      doc.setLineWidth(0.5)
      doc.rect(5, 5, 200, 287)
      
      doc.setFillColor(255, 255, 255)
      doc.rect(0, 0, 210, 297, 'F')
      
      doc.setFillColor(255, 255, 255)
      doc.rect(15, 15, 180, 30, 'F')
      
      try {
        const logoImg = new Image()
        logoImg.crossOrigin = "anonymous"
        logoImg.src = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/inlog-hUsHjenpnKw4AyJwyNOepA3aAH8PSO.png"
        
        await new Promise((resolve, reject) => {
          logoImg.onload = resolve
          logoImg.onerror = reject
          setTimeout(() => reject(new Error('Timeout')), 5000)
        })
        
        if (logoImg.complete && logoImg.naturalWidth > 0) {
          doc.addImage(logoImg, 'PNG', 20, 18, 60, 20)
        }
      } catch (err) {
        console.error("[v0] Logo loading error:", err)
        doc.setFontSize(20)
        doc.setFont("helvetica", "bold")
        doc.setTextColor(64, 156, 193)
        doc.text("INLOG", 20, 28)
      }
      
      doc.setFillColor(64, 156, 193)
      doc.roundedRect(100, 18, 90, 10, 2, 2, 'F')
      doc.setFontSize(14)
      doc.setFont("helvetica", "bold")
      doc.setTextColor(255, 255, 255)
      doc.text("ORDEM DE COLETA", 145, 25, { align: "center" })
      
      doc.setFillColor(245, 248, 250)
      doc.roundedRect(100, 31, 43, 8, 1.5, 1.5, 'F')
      doc.setFontSize(8)
      doc.setTextColor(50, 50, 50)
      doc.setFont("helvetica", "bold")
      doc.text("Data:", 102, 36)
      doc.setFont("helvetica", "normal")
      doc.text(String(orderData.data || ""), 112, 36)
      
      doc.setFillColor(245, 248, 250)
      doc.roundedRect(147, 31, 43, 8, 1.5, 1.5, 'F')
      doc.setFont("helvetica", "bold")
      doc.text("N° Provedor:", 149, 36)
      doc.setFont("helvetica", "normal")
      doc.text(String(orderData.numeroProvedor || ""), 173, 36)
      
      let y = 50
      
      const addField = (label: string, value: string, yPos: number, width: number = 180) => {
        doc.setFontSize(7)
        doc.setFont("helvetica", "bold")
        doc.setTextColor(70, 70, 70)
        doc.text(label, 15, yPos)
        
        doc.setFillColor(240, 245, 250)
        doc.roundedRect(15, yPos + 1, width, 8, 1, 1, 'F')
        
        doc.setDrawColor(210, 220, 230)
        doc.setLineWidth(0.2)
        doc.roundedRect(15, yPos + 1, width, 8, 1, 1)
        
        doc.setTextColor(20, 20, 20)
        doc.setFont("helvetica", "normal")
        doc.setFontSize(9)
        const displayValue = String(value || "").toUpperCase()
        doc.text(displayValue, 18, yPos + 6.5)
        
        return yPos + 11
      }
      
      const addSectionTitle = (title: string, yPos: number) => {
        doc.setFillColor(230, 240, 250)
        doc.roundedRect(15, yPos, 180, 6, 1, 1, 'F')
        
        doc.setFillColor(64, 156, 193)
        doc.roundedRect(15, yPos, 2, 6, 0.5, 0.5, 'F')
        
        doc.setFontSize(9)
        doc.setFont("helvetica", "bold")
        doc.setTextColor(40, 40, 40)
        doc.text(title, 20, yPos + 4.5)
        
        return yPos + 9
      }
      
      // Transport Information
      y = addSectionTitle("INFORMAÇÕES DE TRANSPORTE", y)
      y = addField("Empresa", "INTEGRAÇÃO LOGISTICA - CNPJ: 06.009.235/0001-20", y)
      y = addField("Contato", String(orderData.contato), y)
      y = addField("Telefone", String(orderData.telefone), y)
      y = addField("E-mail", String(orderData.email), y)
      
      y += 3
      
      // Driver Information
      y = addSectionTitle("DADOS DO MOTORISTA", y)
      y = addField("Motorista", String(orderData.motorista), y)
      y = addField("CPF", String(orderData.cpf), y)
      
      doc.setFontSize(7)
      doc.setFont("helvetica", "bold")
      doc.setTextColor(70, 70, 70)
      doc.text("Placa Cavalo", 15, y)
      doc.text("Placa Carreta", 105, y)
      
      doc.setFillColor(240, 245, 250)
      doc.roundedRect(15, y + 1, 85, 8, 1, 1, 'F')
      doc.roundedRect(105, y + 1, 90, 8, 1, 1, 'F')
      
      doc.setDrawColor(210, 220, 230)
      doc.setLineWidth(0.2)
      doc.roundedRect(15, y + 1, 85, 8, 1, 1)
      doc.roundedRect(105, y + 1, 90, 8, 1, 1)
      
      doc.setTextColor(20, 20, 20)
      doc.setFont("helvetica", "normal")
      doc.setFontSize(9)
      doc.text(String(orderData.placaCavalo || "").toUpperCase(), 18, y + 6.5)
      doc.text(String(orderData.placaCarreta || "").toUpperCase(), 108, y + 6.5)
      
      y += 11
      y += 3
      
      // Route Information
      y = addSectionTitle("ROTA DA VIAGEM", y)
      y = addField("Origem / Local de Carregamento", String(orderData.origem), y)
      y = addField("Destino", String(orderData.destino), y)
      
      y += 3
      
      // Cargo Information
      y = addSectionTitle("INFORMAÇÕES DA CARGA", y)
      y = addField("Exportador", String(orderData.exportador), y)
      y = addField("Importador", String(orderData.importador), y)
      y = addField("Fatura", String(orderData.fatura), y)
      y = addField("Previsão de Chegada", String(orderData.previsaoChegada), y)
      
      y += 3
      
      // Documentation
      y = addSectionTitle("DOCUMENTAÇÃO", y)
      
      doc.setFontSize(7)
      doc.setFont("helvetica", "bold")
      doc.setTextColor(70, 70, 70)
      doc.text("Permisso", 15, y)
      doc.text("Vencimento", 105, y)
      
      doc.setFillColor(240, 245, 250)
      doc.roundedRect(15, y + 1, 85, 8, 1, 1, 'F')
      doc.roundedRect(105, y + 1, 90, 8, 1, 1, 'F')
      
      doc.setDrawColor(210, 220, 230)
      doc.setLineWidth(0.2)
      doc.roundedRect(15, y + 1, 85, 8, 1, 1)
      doc.roundedRect(105, y + 1, 90, 8, 1, 1)
      
      doc.setTextColor(20, 20, 20)
      doc.setFont("helvetica", "normal")
      doc.setFontSize(9)
      doc.text(String(orderData.permisso || ""), 18, y + 6.5)
      doc.text(String(orderData.vencimentoPermisso || ""), 108, y + 6.5)
      
      y += 13
      
      doc.setFontSize(7)
      doc.setFont("helvetica", "bold")
      doc.setTextColor(70, 70, 70)
      doc.text("Seguro", 15, y)
      doc.text("Apólice e Validade", 105, y)
      
      doc.setFillColor(240, 245, 250)
      doc.roundedRect(15, y + 1, 85, 8, 1, 1, 'F')
      doc.roundedRect(105, y + 1, 90, 8, 1, 1, 'F')
      
      doc.setDrawColor(210, 220, 230)
      doc.setLineWidth(0.2)
      doc.roundedRect(15, y + 1, 85, 8, 1, 1)
      doc.roundedRect(105, y + 1, 90, 8, 1, 1)
      
      doc.setTextColor(20, 20, 20)
      doc.setFont("helvetica", "normal")
      doc.setFontSize(9)
      doc.text(String(orderData.seguro || ""), 18, y + 6.5)
      doc.text(String(orderData.apolice || ""), 108, y + 6.5)
      
      y += 13
      
      doc.setFontSize(7)
      doc.setFont("helvetica", "bold")
      doc.setTextColor(70, 70, 70)
      doc.text("Observações", 15, y)
      
      doc.setFillColor(240, 245, 250)
      doc.roundedRect(15, y + 1, 180, 10, 1, 1, 'F')
      
      doc.setDrawColor(210, 220, 230)
      doc.setLineWidth(0.2)
      doc.roundedRect(15, y + 1, 180, 10, 1, 1)
      
      if (orderData.observacoes) {
        doc.setTextColor(20, 20, 20)
        doc.setFont("helvetica", "normal")
        doc.setFontSize(8)
        const obsLines = doc.splitTextToSize(String(orderData.observacoes), 175)
        doc.text(obsLines, 18, y + 5)
      }
      
      y += 14
      
      const certY = Math.max(y, 258)
      
      doc.setFillColor(248, 250, 252)
      doc.rect(10, certY, 190, 29, 'F')
      
      doc.setDrawColor(220, 220, 220)
      doc.setLineWidth(0.3)
      doc.line(15, certY, 195, certY)
      
      doc.setFontSize(7)
      doc.setFont("helvetica", "bold")
      doc.setTextColor(100, 100, 100)
      doc.text("Certificações e Licenças", 105, certY + 4, { align: "center" })
      
      const certifications = [
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ISO-dBVWD2krB7BGoPlsgLSfaYEh24osBc.jpg", x: 18 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/thumb1000_sassmaq-l9lGc4TanCJXvZLDmidjSObygCg2AQ.jpg", x: 34 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IBAMA-pbTI9HDec3tZ0o6mpwJSEo2ybPCkcu.jpg", x: 50 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/FAMAI-z4LqOxH7IAYujVeISmgyCLMTu4WfoE.jpg", x: 66 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ANVISA-oqD7l7Qldr7r1WQupttEBVlBpSQQWD.jpg", x: 82 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/thumb1000_mapa-Qg0yr4BxhTORya8akz6UfRZFRi4S71.jpg", x: 98 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMA-RLjAEiyl2UTHNSjnM4PZt3Y3TXOh0e.jpg", x: 114 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/thumb360_policia-civil-dipXdi0HcKmBIUm5N7nfmntt9XY8qz.jpg", x: 130 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/thumb1000_policia-federal-ITU1pFA6DelQRYfrVdZzPWnDtVj5Pa.jpg", x: 146 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/EXECIRTO-0oNkOr0R8sbs5k2jkBrnrfOHbzOarF.jpg", x: 162 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/BOMBEIROS-06igHs8TuiJh8BjLAiNE2FH0bg2h44.jpg", x: 178 },
      ]
      
      for (const cert of certifications) {
        try {
          const img = new Image()
          img.crossOrigin = "anonymous"
          img.src = cert.url
          
          await new Promise((resolve) => {
            img.onload = resolve
            img.onerror = () => resolve(null)
            setTimeout(() => resolve(null), 2000)
          })
          
          if (img.complete && img.naturalWidth > 0) {
            doc.addImage(img, 'JPEG', cert.x, certY + 8, 14, 14)
          }
        } catch (err) {
          console.log(`[v0] Certification ${cert.url} skipped`)
        }
      }
      
      doc.setFontSize(6)
      doc.setFont("helvetica", "normal")
      doc.setTextColor(130, 130, 130)
      doc.text("www.inlog.biz", 105, certY + 26, { align: "center" })
      
      return doc.output('blob')
    } catch (error) {
      console.error("[v0] Error generating PDF blob:", error)
      throw error
    }
  }

  const downloadImportAsExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet([
      { Campo: "Data", Valor: importOrderData.data },
      { Campo: "N° Provedor", Valor: importOrderData.numeroProvedor },
      { Campo: "Transporte", Valor: importOrderData.transporte },
      { Campo: "Contato", Valor: importOrderData.contato },
      { Campo: "Telefone", Valor: importOrderData.telefone },
      { Campo: "E-mail", Valor: importOrderData.email },
      { Campo: "Motorista", Valor: importOrderData.motorista },
      { Campo: "CPF", Valor: importOrderData.cpf },
      { Campo: "Placa Cavalo", Valor: importOrderData.placaCavalo },
      { Campo: "Placa Carreta", Valor: importOrderData.placaCarreta },
      { Campo: "Tara Cavalo", Valor: importOrderData.taraCavalo },
      { Campo: "Tara Carreta", Valor: importOrderData.taraCarreta },
      { Campo: "Local de Carregamento", Valor: importOrderData.localCarregamento },
      { Campo: "Destino", Valor: importOrderData.destino },
      { Campo: "Exportador", Valor: importOrderData.exportador },
      { Campo: "Importador", Valor: importOrderData.importador },
      { Campo: "Fatura", Valor: importOrderData.fatura },
      { Campo: "Previsão de Chegada", Valor: importOrderData.previsaoChegada },
      { Campo: "Permisso", Valor: importOrderData.permisso },
      { Campo: "Vencimento", Valor: importOrderData.vencimentoPermisso },
      { Campo: "Seguro", Valor: importOrderData.seguro },
      { Campo: "Apólice e Validade", Valor: importOrderData.apolice },
      { Campo: "CNPJ ANTT", Valor: importOrderData.cnpjAntt },
      { Campo: "Razão Social", Valor: importOrderData.razaoSocial },
      { Campo: "Nome Fantasia", Valor: importOrderData.nomeFantasia },
      { Campo: "Endereço", Valor: importOrderData.enderecoAntt },
      { Campo: "Observações", Valor: importOrderData.observacoes },
    ])

    const workbook = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(workbook, worksheet, "Ordem de Importação")
    
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' })
    const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `Ordem_Importacao_${importOrderData.numeroProvedor || "novo"}.xlsx`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  const downloadImportAsPDF = async () => {
    try {
      const pdfBlob = await generateImportPDFBlob()
      
      const url = URL.createObjectURL(pdfBlob)
      const link = document.createElement('a')
      link.href = url
      link.download = `Ordem_Importacao_${importOrderData.numeroProvedor || "novo"}.pdf`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error("[v0] Error downloading import PDF:", error)
      alert("Erro ao gerar PDF. Por favor, tente novamente.")
    }
  }

  const generateImportPDFBlob = async () => {
    try {
      const doc = new jsPDF()
      
      doc.setDrawColor(64, 156, 193)
      doc.setLineWidth(0.5)
      doc.rect(5, 5, 200, 287)
      
      doc.setFillColor(255, 255, 255)
      doc.rect(0, 0, 210, 297, 'F')
      
      doc.setFillColor(255, 255, 255)
      doc.rect(12, 12, 186, 22, 'F')
      
      try {
        const logoImg = new Image()
        logoImg.crossOrigin = "anonymous"
        logoImg.src = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/inlog-hUsHjenpnKw4AyJwyNOepA3aAH8PSO.png"
        
        await new Promise((resolve, reject) => {
          logoImg.onload = resolve
          logoImg.onerror = reject
          setTimeout(() => reject(new Error('Timeout')), 5000)
        })
        
        if (logoImg.complete && logoImg.naturalWidth > 0) {
          doc.addImage(logoImg, 'PNG', 15, 14, 45, 15)
        }
      } catch (err) {
        console.error("[v0] Logo loading error:", err)
        doc.setFontSize(16)
        doc.setFont("helvetica", "bold")
        doc.setTextColor(64, 156, 193)
        doc.text("INLOG", 15, 22)
      }
      
      doc.setFillColor(64, 156, 193)
      doc.roundedRect(105, 14, 88, 8, 1.5, 1.5, 'F')
      doc.setFontSize(11)
      doc.setFont("helvetica", "bold")
      doc.setTextColor(255, 255, 255)
      doc.text("ORDEM DE COLETA - IMPORTAÇÃO", 149, 19.5, { align: "center" })
      
      doc.setFillColor(245, 248, 250)
      doc.roundedRect(105, 24, 40, 7, 1, 1, 'F')
      doc.setFontSize(7)
      doc.setTextColor(50, 50, 50)
      doc.setFont("helvetica", "bold")
      doc.text("Data:", 107, 28.5)
      doc.setFont("helvetica", "normal")
      doc.text(String(importOrderData.data || ""), 116, 28.5)
      
      doc.setFillColor(245, 248, 250)
      doc.roundedRect(148, 24, 45, 7, 1, 1, 'F')
      doc.setFont("helvetica", "bold")
      doc.text("N° Provedor:", 150, 28.5)
      doc.setFont("helvetica", "normal")
      doc.text(String(importOrderData.numeroProvedor || ""), 171, 28.5)
      
      let y = 38
      
      const addField = (label: string, value: string, yPos: number, width: number = 186) => {
        doc.setFontSize(6.5)
        doc.setFont("helvetica", "bold")
        doc.setTextColor(70, 70, 70)
        doc.text(label, 12, yPos)
        
        doc.setFillColor(240, 245, 250)
        doc.roundedRect(12, yPos + 0.5, width, 7, 0.8, 0.8, 'F')
        
        doc.setDrawColor(210, 220, 230)
        doc.setLineWidth(0.15)
        doc.roundedRect(12, yPos + 0.5, width, 7, 0.8, 0.8)
        
        doc.setTextColor(20, 20, 20)
        doc.setFont("helvetica", "normal")
        doc.setFontSize(8)
        const displayValue = String(value || "").toUpperCase()
        doc.text(displayValue, 14, yPos + 5.5)
        
        return yPos + 9
      }
      
      const addSectionTitle = (title: string, yPos: number) => {
        doc.setFillColor(230, 240, 250)
        doc.roundedRect(12, yPos, 186, 5, 0.8, 0.8, 'F')
        
        doc.setFillColor(64, 156, 193)
        doc.roundedRect(12, yPos, 1.5, 5, 0.4, 0.4, 'F')
        
        doc.setFontSize(8)
        doc.setFont("helvetica", "bold")
        doc.setTextColor(40, 40, 40)
        doc.text(title, 16, yPos + 3.5)
        
        return yPos + 7
      }
      
      // Transport Information
      y = addSectionTitle("INFORMAÇÕES DE TRANSPORTE", y)
      y = addField("Transporte", String(importOrderData.transporte), y)
      y = addField("Contato", String(importOrderData.contato), y)
      y = addField("Telefone", String(importOrderData.telefone), y)
      y = addField("E-mail", String(importOrderData.email), y)
      
      y += 1
      
      // Driver Information
      y = addSectionTitle("DADOS DO MOTORISTA", y)
      y = addField("Motorista", String(importOrderData.motorista), y)
      y = addField("CPF", String(importOrderData.cpf), y)
      
      doc.setFontSize(6.5)
      doc.setFont("helvetica", "bold")
      doc.setTextColor(70, 70, 70)
      doc.text("Placa Cavalo", 12, y)
      doc.text("Placa Carreta", 105, y)
      
      doc.setFillColor(240, 245, 250)
      doc.roundedRect(12, y + 0.5, 88, 7, 0.8, 0.8, 'F')
      doc.roundedRect(105, y + 0.5, 93, 7, 0.8, 0.8, 'F')
      
      doc.setDrawColor(210, 220, 230)
      doc.setLineWidth(0.15)
      doc.roundedRect(12, y + 0.5, 88, 7, 0.8, 0.8)
      doc.roundedRect(105, y + 0.5, 93, 7, 0.8, 0.8)
      
      doc.setTextColor(20, 20, 20)
      doc.setFont("helvetica", "normal")
      doc.setFontSize(8)
      doc.text(String(importOrderData.placaCavalo || "").toUpperCase(), 14, y + 5.5)
      doc.text(String(importOrderData.placaCarreta || "").toUpperCase(), 107, y + 5.5)
      
      y += 9
      
      // Tara side by side
      doc.setFontSize(6.5)
      doc.setFont("helvetica", "bold")
      doc.setTextColor(70, 70, 70)
      doc.text("Tara Cavalo", 12, y)
      doc.text("Tara Carreta", 105, y)
      
      doc.setFillColor(240, 245, 250)
      doc.roundedRect(12, y + 0.5, 88, 7, 0.8, 0.8, 'F')
      doc.roundedRect(105, y + 0.5, 93, 7, 0.8, 0.8, 'F')
      
      doc.setDrawColor(210, 220, 230)
      doc.setLineWidth(0.15)
      doc.roundedRect(12, y + 0.5, 88, 7, 0.8, 0.8)
      doc.roundedRect(105, y + 0.5, 93, 7, 0.8, 0.8)
      
      doc.setTextColor(20, 20, 20)
      doc.setFont("helvetica", "normal")
      doc.setFontSize(8)
      doc.text(String(importOrderData.taraCavalo || ""), 14, y + 5.5)
      doc.text(String(importOrderData.taraCarreta || ""), 107, y + 5.5)
      
      y += 9
      y += 1
      
      // Route Information
      y = addSectionTitle("ROTA DA VIAGEM", y)
      y = addField("Local de Carregamento", String(importOrderData.localCarregamento), y)
      y = addField("Destino", String(importOrderData.destino), y)
      
      y += 1
      
      // Cargo Information
      y = addSectionTitle("INFORMAÇÕES DA CARGA", y)
      y = addField("Exportador", String(importOrderData.exportador), y)
      y = addField("Importador", String(importOrderData.importador), y)
      y = addField("Fatura", String(importOrderData.fatura), y)
      y = addField("Previsão de Chegada", String(importOrderData.previsaoChegada), y)
      
      y += 1
      
      // Documentation
      y = addSectionTitle("DOCUMENTAÇÃO", y)
      
      // Permisso and Vencimento side by side
      doc.setFontSize(6.5)
      doc.setFont("helvetica", "bold")
      doc.setTextColor(70, 70, 70)
      doc.text("Permisso", 12, y)
      doc.text("Vencimento", 105, y)
      
      doc.setFillColor(240, 245, 250)
      doc.roundedRect(12, y + 0.5, 88, 7, 0.8, 0.8, 'F')
      doc.roundedRect(105, y + 0.5, 93, 7, 0.8, 0.8, 'F')
      
      doc.setDrawColor(210, 220, 230)
      doc.setLineWidth(0.15)
      doc.roundedRect(12, y + 0.5, 88, 7, 0.8, 0.8)
      doc.roundedRect(105, y + 0.5, 93, 7, 0.8, 0.8)
      
      doc.setTextColor(20, 20, 20)
      doc.setFont("helvetica", "normal")
      doc.setFontSize(8)
      doc.text(String(importOrderData.permisso || ""), 14, y + 5.5)
      doc.text(String(importOrderData.vencimentoPermisso || ""), 107, y + 5.5)
      
      y += 9
      
      // Seguro and Apólice side by side
      doc.setFontSize(6.5)
      doc.setFont("helvetica", "bold")
      doc.setTextColor(70, 70, 70)
      doc.text("Seguro", 12, y)
      doc.text("Apólice e Validade", 105, y)
      
      doc.setFillColor(240, 245, 250)
      doc.roundedRect(12, y + 0.5, 88, 7, 0.8, 0.8, 'F')
      doc.roundedRect(105, y + 0.5, 93, 7, 0.8, 0.8, 'F')
      
      doc.setDrawColor(210, 220, 230)
      doc.setLineWidth(0.15)
      doc.roundedRect(12, y + 0.5, 88, 7, 0.8, 0.8)
      doc.roundedRect(105, y + 0.5, 93, 7, 0.8, 0.8)
      
      doc.setTextColor(20, 20, 20)
      doc.setFont("helvetica", "normal")
      doc.setFontSize(8)
      doc.text(String(importOrderData.seguro || ""), 14, y + 5.5)
      doc.text(String(importOrderData.apolice || ""), 107, y + 5.5)
      
      y += 10
      
      // ANTT Data
      y = addSectionTitle("DADOS DA EMPRESA ANTT", y)
      y = addField("CNPJ", String(importOrderData.cnpjAntt), y)
      y = addField("Razão Social", String(importOrderData.razaoSocial), y)
      y = addField("Nome Fantasia", String(importOrderData.nomeFantasia), y)
      y = addField("Endereço", String(importOrderData.enderecoAntt), y)
      
      y += 1
      
      doc.setFontSize(6.5)
      doc.setFont("helvetica", "bold")
      doc.setTextColor(70, 70, 70)
      doc.text("Observações", 12, y)
      
      doc.setFillColor(240, 245, 250)
      doc.roundedRect(12, y + 0.5, 186, 8, 0.8, 0.8, 'F')
      
      doc.setDrawColor(210, 220, 230)
      doc.setLineWidth(0.15)
      doc.roundedRect(12, y + 0.5, 186, 8, 0.8, 0.8)
      
      if (importOrderData.observacoes) {
        doc.setTextColor(20, 20, 20)
        doc.setFont("helvetica", "normal")
        doc.setFontSize(7)
        const obsLines = doc.splitTextToSize(String(importOrderData.observacoes), 180)
        doc.text(obsLines, 14, y + 4.5)
      }
      
      y += 11
      
      const certY = Math.max(y, 263)
      
      doc.setFillColor(248, 250, 252)
      doc.rect(8, certY, 194, 24, 'F')
      
      doc.setDrawColor(220, 220, 220)
      doc.setLineWidth(0.2)
      doc.line(12, certY, 198, certY)
      
      doc.setFontSize(6)
      doc.setFont("helvetica", "bold")
      doc.setTextColor(100, 100, 100)
      doc.text("Certificações e Licenças", 105, certY + 3, { align: "center" })
      
      const certifications = [
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ISO-dBVWD2krB7BGoPlsgLSfaYEh24osBc.jpg", x: 18 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/thumb1000_sassmaq-l9lGc4TanCJXvZLDmidjSObygCg2AQ.jpg", x: 34 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IBAMA-pbTI9HDec3tZ0o6mpwJSEo2ybPCkcu.jpg", x: 50 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/FAMAI-z4LqOxH7IAYujVeISmgyCLMTu4WfoE.jpg", x: 66 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ANVISA-oqD7l7Qldr7r1WQupttEBVlBpSQQWD.jpg", x: 82 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/thumb1000_mapa-Qg0yr4BxhTORya8akz6UfRZFRi4S71.jpg", x: 98 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMA-RLjAEiyl2UTHNSjnM4PZt3Y3TXOh0e.jpg", x: 114 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/thumb360_policia-civil-dipXdi0HcKmBIUm5N7nfmntt9XY8qz.jpg", x: 130 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/thumb1000_policia-federal-ITU1pFA6DelQRYfrVdZzPWnDtVj5Pa.jpg", x: 146 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/EXECIRTO-0oNkOr0R8sbs5k2jkBrnrfOHbzOarF.jpg", x: 162 },
        { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/BOMBEIROS-06igHs8TuiJh8BjLAiNE2FH0bg2h44.jpg", x: 178 },
      ]
      
      for (const cert of certifications) {
        try {
          const img = new Image()
          img.crossOrigin = "anonymous"
          img.src = cert.url
          
          await new Promise((resolve) => {
            img.onload = resolve
            img.onerror = () => resolve(null)
            setTimeout(() => resolve(null), 2000)
          })
          
          if (img.complete && img.naturalWidth > 0) {
            doc.addImage(img, 'JPEG', cert.x, certY + 6, 12, 12)
          }
        } catch (err) {
          console.log(`[v0] Certification ${cert.url} skipped`)
        }
      }
      
      doc.setFontSize(5.5)
      doc.setFont("helvetica", "normal")
      doc.setTextColor(130, 130, 130)
      doc.text("www.inlog.biz", 105, certY + 21, { align: "center" })
      
      return doc.output('blob')
    } catch (error) {
      console.error("[v0] Error generating import PDF blob:", error)
      throw error
    }
  }

  const shareViaWhatsApp = async () => {
    try {
      const motoristaName = orderData.motorista.trim()
      const message = `${motoristaName}, segue ordem de coleta referente sua viagem\n\n` +
                     `📍 Origem: ${orderData.origem}\n` +
                     `🎯 Destino: ${orderData.destino}\n` +
                     `📅 Previsão: ${orderData.previsaoChegada}`
      
      // Generate PDF blob
      const pdfBlob = await generatePDFBlob()
      
      // Check if Web Share API is available with files support
      if (navigator.share && navigator.canShare && navigator.canShare({ files: [new File([pdfBlob], 'ordem.pdf')] })) {
        const file = new File([pdfBlob], `Ordem_Coleta_${orderData.numeroProvedor || 'nova'}.pdf`, { type: 'application/pdf' })
        await navigator.share({
          title: 'Ordem de Coleta',
          text: message,
          files: [file]
        })
      } else {
        // Fallback: Download PDF and open WhatsApp with text
        const url = URL.createObjectURL(pdfBlob)
        const link = document.createElement('a')
        link.href = url
        link.download = `Ordem_Coleta_${orderData.numeroProvedor || "novo"}.pdf`
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
        URL.revokeObjectURL(url)
        
        // Open WhatsApp after download starts
        const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message + '\n\n(PDF foi baixado - envie manualmente)')}`
        window.open(whatsappUrl, '_blank')
      }
      
      setShareDialogOpen(false)
    } catch (error) {
      console.error("[v0] Error sharing via WhatsApp:", error)
      alert("Erro ao compartilhar. O PDF foi baixado - envie manualmente pelo WhatsApp.")
      downloadAsPDF() // Ensure PDF is downloaded even if sharing fails
    }
  }

  const shareViaEmail = () => {
    const subject = `Ordem de Coleta ${orderData.numeroProvedor || "Nova"}`
    const body = `Confira a ordem de coleta:\n\nMotorista: ${orderData.motorista}\nOrigem: ${orderData.origem}\nDestino: ${orderData.destino}\n\nLink: ${window.location.href}`
    const mailtoLink = `mailto:${shareEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
    window.location.href = mailtoLink
    setShareDialogOpen(false)
  }

  return (
    <div className="space-y-8">
      {/* Google Sheets Import */}
      <Card className="p-8 border-0 shadow-sm bg-gradient-to-br from-background to-muted/20">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center shadow-lg">
            <Sheet className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-semibold tracking-tight">Importar Dados</h2>
            <p className="text-sm text-muted-foreground mt-1">Conecte sua planilha Google Sheets</p>
          </div>
        </div>

        <div className="flex gap-3">
          <Input
            placeholder="https://docs.google.com/spreadsheets/d/..."
            value={sheetUrl}
            onChange={(e) => setSheetUrl(e.target.value)}
            className="flex-1 h-12 px-4 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
          />
          <Button 
            onClick={loadFromGoogleSheets} 
            disabled={isLoading || !sheetUrl}
            className="h-12 px-6 rounded-xl font-medium shadow-sm hover:shadow-md transition-all"
          >
            {isLoading ? "Carregando..." : "Importar"}
          </Button>
        </div>

        {error && (
          <div className="mt-6 p-4 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/30 rounded-xl flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-medium text-red-900 dark:text-red-200">Erro ao importar</p>
              <p className="text-sm text-red-700 dark:text-red-300 mt-1">{error}</p>
            </div>
          </div>
        )}

        {drivers.length > 0 && (
          <div className="mt-6 p-6 bg-gradient-to-br from-primary/5 to-primary/10 rounded-2xl border border-primary/20">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                <User className="w-5 h-5 text-primary" />
              </div>
              <div>
                <Label className="text-base font-semibold">Selecionar Motorista</Label>
                <p className="text-sm text-muted-foreground mt-0.5">
                  {drivers.length} motorista{drivers.length > 1 ? 's' : ''} disponível{drivers.length > 1 ? 'is' : ''}
                </p>
              </div>
            </div>
            <Select value={selectedDriver} onValueChange={handleDriverSelect}>
              <SelectTrigger className="w-full h-12 rounded-xl bg-background border-muted-foreground/20">
                <SelectValue placeholder="Escolha um motorista..." />
              </SelectTrigger>
              <SelectContent className="rounded-xl">
                {drivers.map((driver, index) => (
                  <SelectItem key={index} value={driver.motorista} className="rounded-lg">
                    <div className="flex flex-col py-1">
                      <span className="font-medium">{driver.motorista}</span>
                      <span className="text-xs text-muted-foreground mt-1">
                        {driver.placaCavalo} • {driver.origem} → {driver.destino}
                      </span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="exportacao">Exportação</TabsTrigger>
          <TabsTrigger value="importacao">Importação</TabsTrigger>
        </TabsList>

        <TabsContent value="exportacao">
          <Card className="p-8 border-0 shadow-lg bg-white dark:bg-zinc-900">
            <div className="flex items-center justify-between mb-8 pb-6 border-b border-muted-foreground/10">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center shadow-lg">
                  <FileSpreadsheet className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-semibold tracking-tight">Ordem de Coleta</h2>
                  <p className="text-sm text-muted-foreground mt-1">Revise e complete as informações</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="h-10 rounded-xl border-muted-foreground/20 hover:bg-muted/50">
                      <Share2 className="w-4 h-4 mr-2" />
                      Compartilhar
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="rounded-2xl">
                    <DialogHeader>
                      <DialogTitle className="text-xl">Compartilhar Ordem</DialogTitle>
                      <DialogDescription className="text-muted-foreground">
                        Envie esta ordem por WhatsApp ou e-mail
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 pt-4">
                      <div className="space-y-3">
                        <Label className="text-sm font-medium">WhatsApp</Label>
                        <Button 
                          onClick={shareViaWhatsApp} 
                          className="w-full h-12 bg-green-600 hover:bg-green-700 rounded-xl shadow-sm"
                          disabled={!orderData.motorista}
                        >
                          <MessageCircle className="w-4 h-4 mr-2" />
                          Enviar para {orderData.motorista || 'Motorista'}
                        </Button>
                        {!orderData.motorista && (
                          <p className="text-xs text-muted-foreground">Preencha o nome do motorista primeiro</p>
                        )}
                      </div>
                      
                      <div className="relative">
                        <div className="absolute inset-0 flex items-center">
                          <span className="w-full border-t border-muted-foreground/10" />
                        </div>
                        <div className="relative flex justify-center text-xs uppercase">
                          <span className="bg-background px-3 text-muted-foreground">Ou</span>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <Label htmlFor="shareEmail" className="text-sm font-medium">E-mail</Label>
                        <div className="flex gap-2">
                          <Input
                            id="shareEmail"
                            type="email"
                            placeholder="email@exemplo.com"
                            value={shareEmail}
                            onChange={(e) => setShareEmail(e.target.value)}
                            className="flex-1 h-12 rounded-xl border-muted-foreground/20"
                          />
                          <Button onClick={shareViaEmail} disabled={!shareEmail} className="h-12 rounded-xl">
                            <Mail className="w-4 h-4 mr-2" />
                            Enviar
                          </Button>
                        </div>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
                
                <Button variant="outline" onClick={downloadAsExcel} className="h-10 rounded-xl border-muted-foreground/20 hover:bg-muted/50">
                  <Table className="w-4 h-4 mr-2" />
                  Excel
                </Button>
                <Button onClick={downloadAsPDF} className="h-10 rounded-xl shadow-sm">
                  <Download className="w-4 h-4 mr-2" />
                  Baixar PDF
                </Button>
              </div>
            </div>

            <div className="space-y-8">
              {/* Header Info Section */}
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-6 bg-gradient-to-b from-blue-500 to-cyan-500 rounded-full" />
                  <h3 className="text-lg font-semibold tracking-tight">Informações Gerais</h3>
                </div>
                
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-2.5">
                    <Label htmlFor="data" className="text-sm font-medium text-muted-foreground">Data</Label>
                    <Input 
                      id="data" 
                      value={orderData.data} 
                      onChange={(e) => handleInputChange("data", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="numeroProvedor" className="text-sm font-medium text-muted-foreground">N° Provedor</Label>
                    <Input
                      id="numeroProvedor"
                      value={orderData.numeroProvedor}
                      onChange={(e) => handleInputChange("numeroProvedor", e.target.value)}
                      placeholder="Ex: 6297595/3"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="contato" className="text-sm font-medium text-muted-foreground">Contato</Label>
                    <Input 
                      id="contato" 
                      value={orderData.contato} 
                      onChange={(e) => handleInputChange("contato", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="telefone" className="text-sm font-medium text-muted-foreground">Telefone</Label>
                    <Input 
                      id="telefone" 
                      value={orderData.telefone} 
                      onChange={(e) => handleInputChange("telefone", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5 md:col-span-2">
                    <Label htmlFor="email" className="text-sm font-medium text-muted-foreground">E-mail</Label>
                    <Input 
                      id="email" 
                      value={orderData.email} 
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>
                </div>
              </div>

              {/* Transport Info Section */}
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-6 bg-gradient-to-b from-purple-500 to-pink-500 rounded-full" />
                  <h3 className="text-lg font-semibold tracking-tight">Dados do Transporte</h3>
                </div>
                
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-2.5">
                    <Label htmlFor="motorista" className="text-sm font-medium text-muted-foreground">
                      Motorista <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="motorista"
                      value={orderData.motorista}
                      onChange={(e) => handleInputChange("motorista", e.target.value)}
                      placeholder="Nome completo"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="cpf" className="text-sm font-medium text-muted-foreground">
                      CPF <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="cpf"
                      value={orderData.cpf}
                      onChange={(e) => handleInputChange("cpf", e.target.value)}
                      placeholder="000.000.000-00"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="placaCavalo" className="text-sm font-medium text-muted-foreground">
                      Placa Cavalo <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="placaCavalo"
                      value={orderData.placaCavalo}
                      onChange={(e) => handleInputChange("placaCavalo", e.target.value)}
                      placeholder="ABC1D23"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="placaCarreta" className="text-sm font-medium text-muted-foreground">
                      Placa Carreta <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="placaCarreta"
                      value={orderData.placaCarreta}
                      onChange={(e) => handleInputChange("placaCarreta", e.target.value)}
                      placeholder="XYZ9W87"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="origem" className="text-sm font-medium text-muted-foreground">
                      Local de Carregamento <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="origem"
                      value={orderData.origem}
                      onChange={(e) => handleInputChange("origem", e.target.value)}
                      placeholder="Ex: CURITIBA - PR"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="destino" className="text-sm font-medium text-muted-foreground">
                      Destino <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="destino"
                      value={orderData.destino}
                      onChange={(e) => handleInputChange("destino", e.target.value)}
                      placeholder="Ex: BUENOS AIRES - AR"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>
                </div>
              </div>

              {/* Cargo Info Section */}
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-6 bg-gradient-to-b from-orange-500 to-red-500 rounded-full" />
                  <h3 className="text-lg font-semibold tracking-tight">Dados da Carga</h3>
                </div>
                
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-2.5">
                    <Label htmlFor="exportador" className="text-sm font-medium text-muted-foreground">
                      Exportador <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="exportador"
                      value={orderData.exportador}
                      onChange={(e) => handleInputChange("exportador", e.target.value)}
                      placeholder="Nome do exportador"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="importador" className="text-sm font-medium text-muted-foreground">
                      Importador <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="importador"
                      value={orderData.importador}
                      onChange={(e) => handleInputChange("importador", e.target.value)}
                      placeholder="Nome do importador"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="fatura" className="text-sm font-medium text-muted-foreground">
                      Fatura <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="fatura"
                      value={orderData.fatura}
                      onChange={(e) => handleInputChange("fatura", e.target.value)}
                      placeholder="Número da fatura"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="previsaoChegada" className="text-sm font-medium text-muted-foreground">
                      Previsão de Chegada <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="previsaoChegada"
                      type="datetime-local"
                      value={orderData.previsaoChegada}
                      onChange={(e) => handleInputChange("previsaoChegada", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>
                </div>
              </div>

              {/* Additional Info Section */}
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-6 bg-gradient-to-b from-green-500 to-emerald-500 rounded-full" />
                  <h3 className="text-lg font-semibold tracking-tight">Informações Adicionais</h3>
                </div>
                
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-2.5">
                    <Label htmlFor="permisso" className="text-sm font-medium text-muted-foreground">Permisso</Label>
                    <Input 
                      id="permisso" 
                      value={orderData.permisso} 
                      onChange={(e) => handleInputChange("permisso", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="vencimentoPermisso" className="text-sm font-medium text-muted-foreground">Vencimento</Label>
                    <Input
                      id="vencimentoPermisso"
                      value={orderData.vencimentoPermisso}
                      onChange={(e) => handleInputChange("vencimentoPermisso", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="seguro" className="text-sm font-medium text-muted-foreground">Seguro</Label>
                    <Input 
                      id="seguro" 
                      value={orderData.seguro} 
                      onChange={(e) => handleInputChange("seguro", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="apolice" className="text-sm font-medium text-muted-foreground">Apólice e Validade</Label>
                    <Input 
                      id="apolice" 
                      value={orderData.apolice} 
                      onChange={(e) => handleInputChange("apolice", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5 md:col-span-2">
                    <Label htmlFor="observacoes" className="text-sm font-medium text-muted-foreground">Observações</Label>
                    <Textarea
                      id="observacoes"
                      value={orderData.observacoes}
                      onChange={(e) => handleInputChange("observacoes", e.target.value)}
                      rows={4}
                      placeholder="Adicione observações sobre a coleta..."
                      className="rounded-xl border-muted-foreground/20 focus:border-primary transition-colors resize-none"
                    />
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="importacao">
          <Card className="p-8 border-0 shadow-lg bg-white dark:bg-zinc-900">
            <div className="flex items-center justify-between mb-8 pb-6 border-b border-muted-foreground/10">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center shadow-lg">
                  <FileSpreadsheet className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-semibold tracking-tight">Ordem de Coleta - Importação</h2>
                  <p className="text-sm text-muted-foreground mt-1">Revise e complete as informações de importação</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={downloadImportAsExcel} className="h-10 rounded-xl border-muted-foreground/20 hover:bg-muted/50">
                  <Table className="w-4 h-4 mr-2" />
                  Excel
                </Button>
                <Button onClick={downloadImportAsPDF} className="h-10 rounded-xl shadow-sm">
                  <Download className="w-4 h-4 mr-2" />
                  Baixar PDF
                </Button>
              </div>
            </div>

            <div className="space-y-8">
              {/* Header Info Section */}
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-6 bg-gradient-to-b from-blue-500 to-cyan-500 rounded-full" />
                  <h3 className="text-lg font-semibold tracking-tight">Informações Gerais</h3>
                </div>
                
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-2.5">
                    <Label htmlFor="import-data" className="text-sm font-medium text-muted-foreground">Data</Label>
                    <Input 
                      id="import-data" 
                      value={importOrderData.data} 
                      onChange={(e) => handleImportInputChange("data", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-numeroProvedor" className="text-sm font-medium text-muted-foreground">N° Provedor</Label>
                    <Input
                      id="import-numeroProvedor"
                      value={importOrderData.numeroProvedor}
                      onChange={(e) => handleImportInputChange("numeroProvedor", e.target.value)}
                      placeholder="Ex: 6297595/3"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5 md:col-span-2">
                    <Label htmlFor="import-transporte" className="text-sm font-medium text-muted-foreground">Transporte</Label>
                    <Input 
                      id="import-transporte" 
                      value={importOrderData.transporte} 
                      onChange={(e) => handleImportInputChange("transporte", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-contato" className="text-sm font-medium text-muted-foreground">Contato</Label>
                    <Input 
                      id="import-contato" 
                      value={importOrderData.contato} 
                      onChange={(e) => handleImportInputChange("contato", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-telefone" className="text-sm font-medium text-muted-foreground">Telefone</Label>
                    <Input 
                      id="import-telefone" 
                      value={importOrderData.telefone} 
                      onChange={(e) => handleImportInputChange("telefone", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5 md:col-span-2">
                    <Label htmlFor="import-email" className="text-sm font-medium text-muted-foreground">E-mail</Label>
                    <Input 
                      id="import-email" 
                      value={importOrderData.email} 
                      onChange={(e) => handleImportInputChange("email", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>
                </div>
              </div>

              {/* Transport Info Section */}
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-6 bg-gradient-to-b from-purple-500 to-pink-500 rounded-full" />
                  <h3 className="text-lg font-semibold tracking-tight">Dados do Transporte</h3>
                </div>
                
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-2.5">
                    <Label htmlFor="import-motorista" className="text-sm font-medium text-muted-foreground">
                      Motorista <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="import-motorista"
                      value={importOrderData.motorista}
                      onChange={(e) => handleImportInputChange("motorista", e.target.value)}
                      placeholder="Nome completo"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-cpf" className="text-sm font-medium text-muted-foreground">
                      CPF <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="import-cpf"
                      value={importOrderData.cpf}
                      onChange={(e) => handleImportInputChange("cpf", e.target.value)}
                      placeholder="000.000.000-00"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-placaCavalo" className="text-sm font-medium text-muted-foreground">
                      Placa Cavalo <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="import-placaCavalo"
                      value={importOrderData.placaCavalo}
                      onChange={(e) => handleImportInputChange("placaCavalo", e.target.value)}
                      placeholder="ABC1D23"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-placaCarreta" className="text-sm font-medium text-muted-foreground">
                      Placa Carreta <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="import-placaCarreta"
                      value={importOrderData.placaCarreta}
                      onChange={(e) => handleImportInputChange("placaCarreta", e.target.value)}
                      placeholder="XYZ9W87"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-taraCavalo" className="text-sm font-medium text-muted-foreground">
                      Tara Cavalo <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="import-taraCavalo"
                      value={importOrderData.taraCavalo}
                      onChange={(e) => handleImportInputChange("taraCavalo", e.target.value)}
                      placeholder="Ex: 8850"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-taraCarreta" className="text-sm font-medium text-muted-foreground">
                      Tara Carreta <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="import-taraCarreta"
                      value={importOrderData.taraCarreta}
                      onChange={(e) => handleImportInputChange("taraCarreta", e.target.value)}
                      placeholder="Ex: 10200"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-localCarregamento" className="text-sm font-medium text-muted-foreground">
                      Local de Carregamento <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="import-localCarregamento"
                      value={importOrderData.localCarregamento}
                      onChange={(e) => handleImportInputChange("localCarregamento", e.target.value)}
                      placeholder="Ex: JUNIN - AR"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-destino" className="text-sm font-medium text-muted-foreground">
                      Destino <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="import-destino"
                      value={importOrderData.destino}
                      onChange={(e) => handleImportInputChange("destino", e.target.value)}
                      placeholder="Ex: ITAJAI - SC"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>
                </div>
              </div>

              {/* Cargo Info Section */}
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-6 bg-gradient-to-b from-orange-500 to-red-500 rounded-full" />
                  <h3 className="text-lg font-semibold tracking-tight">Dados da Carga</h3>
                </div>
                
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-2.5">
                    <Label htmlFor="import-exportador" className="text-sm font-medium text-muted-foreground">
                      Exportador <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="import-exportador"
                      value={importOrderData.exportador}
                      onChange={(e) => handleImportInputChange("exportador", e.target.value)}
                      placeholder="Nome do exportador"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-importador" className="text-sm font-medium text-muted-foreground">
                      Importador <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="import-importador"
                      value={importOrderData.importador}
                      onChange={(e) => handleImportInputChange("importador", e.target.value)}
                      placeholder="Nome do importador"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-fatura" className="text-sm font-medium text-muted-foreground">
                      Fatura <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="import-fatura"
                      value={importOrderData.fatura}
                      onChange={(e) => handleImportInputChange("fatura", e.target.value)}
                      placeholder="Número da fatura"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-previsaoChegada" className="text-sm font-medium text-muted-foreground">
                      Previsão de Chegada <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="import-previsaoChegada"
                      value={importOrderData.previsaoChegada}
                      onChange={(e) => handleImportInputChange("previsaoChegada", e.target.value)}
                      placeholder="Ex: 10/11/2025 as 08 Hrs"
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>
                </div>
              </div>

              {/* Documentation Section */}
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-6 bg-gradient-to-b from-green-500 to-emerald-500 rounded-full" />
                  <h3 className="text-lg font-semibold tracking-tight">Documentação</h3>
                </div>
                
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-2.5">
                    <Label htmlFor="import-permisso" className="text-sm font-medium text-muted-foreground">Permisso</Label>
                    <Input 
                      id="import-permisso" 
                      value={importOrderData.permisso} 
                      onChange={(e) => handleImportInputChange("permisso", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-vencimentoPermisso" className="text-sm font-medium text-muted-foreground">Vencimento</Label>
                    <Input
                      id="import-vencimentoPermisso"
                      value={importOrderData.vencimentoPermisso}
                      onChange={(e) => handleImportInputChange("vencimentoPermisso", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-seguro" className="text-sm font-medium text-muted-foreground">Seguro</Label>
                    <Input 
                      id="import-seguro" 
                      value={importOrderData.seguro} 
                      onChange={(e) => handleImportInputChange("seguro", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-apolice" className="text-sm font-medium text-muted-foreground">Apólice e Validade</Label>
                    <Input 
                      id="import-apolice" 
                      value={importOrderData.apolice} 
                      onChange={(e) => handleImportInputChange("apolice", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>
                </div>
              </div>

              {/* ANTT Data Section */}
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-6 bg-gradient-to-b from-indigo-500 to-purple-500 rounded-full" />
                  <h3 className="text-lg font-semibold tracking-tight">Dados da Empresa ANTT</h3>
                </div>
                
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-2.5">
                    <Label htmlFor="import-cnpjAntt" className="text-sm font-medium text-muted-foreground">CNPJ</Label>
                    <Input 
                      id="import-cnpjAntt" 
                      value={importOrderData.cnpjAntt} 
                      onChange={(e) => handleImportInputChange("cnpjAntt", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5">
                    <Label htmlFor="import-nomeFantasia" className="text-sm font-medium text-muted-foreground">Nome Fantasia</Label>
                    <Input 
                      id="import-nomeFantasia" 
                      value={importOrderData.nomeFantasia} 
                      onChange={(e) => handleImportInputChange("nomeFantasia", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5 md:col-span-2">
                    <Label htmlFor="import-razaoSocial" className="text-sm font-medium text-muted-foreground">Razão Social</Label>
                    <Input 
                      id="import-razaoSocial" 
                      value={importOrderData.razaoSocial} 
                      onChange={(e) => handleImportInputChange("razaoSocial", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2.5 md:col-span-2">
                    <Label htmlFor="import-enderecoAntt" className="text-sm font-medium text-muted-foreground">Endereço</Label>
                    <Input 
                      id="import-enderecoAntt" 
                      value={importOrderData.enderecoAntt} 
                      onChange={(e) => handleImportInputChange("enderecoAntt", e.target.value)}
                      className="h-11 rounded-xl border-muted-foreground/20 focus:border-primary transition-colors"
                    />
                  </div>
                </div>
              </div>

              {/* Observations Section */}
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-6 bg-gradient-to-b from-amber-500 to-orange-500 rounded-full" />
                  <h3 className="text-lg font-semibold tracking-tight">Observações</h3>
                </div>
                
                <div className="space-y-2.5">
                  <Label htmlFor="import-observacoes" className="text-sm font-medium text-muted-foreground">Observações</Label>
                  <Textarea
                    id="import-observacoes"
                    value={importOrderData.observacoes}
                    onChange={(e) => handleImportInputChange("observacoes", e.target.value)}
                    rows={4}
                    placeholder="Adicione observações sobre a coleta..."
                    className="rounded-xl border-muted-foreground/20 focus:border-primary transition-colors resize-none"
                  />
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
