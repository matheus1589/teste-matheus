"use client"

import { useState, useEffect, useMemo } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Download,
  Search,
  MapPin,
  Calendar,
  FileText,
  Package,
  BarChart3,
  Filter,
  TrendingUp,
  User,
  TruckIcon,
  LayoutGrid,
  ListIcon,
} from "lucide-react"
import jsPDF from "jspdf"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { TrackingShare } from "./tracking-share" // Added import for TrackingShare component
import { ClientCollectionRequestsTab } from "./client-collection-requests-tab"

interface TrackingMilestone {
  status: string
  details: string
  timestamp: string
}

interface Trip {
  id: string
  crt: string
  clientReference: string
  clientUsername: string
  startDate: string
  endDate: string
  origin: string
  destination: string
  status: string
  proofOfDelivery?: string
  invoice?: string
  driverName?: string
  vehiclePlate?: string
  trailerPlate?: string
  exportador?: string
  trackingStatus?: string
  trackingDetails?: TrackingMilestone[]
}

interface ClientPortalTripsProps {
  username: string
}

export function ClientPortalTrips({ username }: ClientPortalTripsProps) {
  const [trips, setTrips] = useState<Trip[]>([])
  const [filteredTrips, setFilteredTrips] = useState<Trip[]>([])
  const [crtFilter, setCrtFilter] = useState("")
  const [referenceFilter, setReferenceFilter] = useState("")
  const [dateFilter, setDateFilter] = useState("")

  const [viewMode, setViewMode] = useState<"card" | "list">("card")

  const [exportPeriodStart, setExportPeriodStart] = useState("")
  const [exportPeriodEnd, setExportPeriodEnd] = useState("")
  const [exportOnlyCompleted, setExportOnlyCompleted] = useState(false)
  const [exportOriginFilter, setExportOriginFilter] = useState("")
  const [exportDestinationFilter, setExportDestinationFilter] = useState("")
  const [showExportFilters, setShowExportFilters] = useState(false)
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null)
  const [showTrackingDialog, setShowTrackingDialog] = useState(false)

  const uniqueOrigins = useMemo(() => {
    const origins = new Set(trips.map((t) => t.origin))
    return Array.from(origins).sort()
  }, [trips])

  const uniqueDestinations = useMemo(() => {
    const destinations = new Set(trips.map((t) => t.destination))
    return Array.from(destinations).sort()
  }, [trips])

  useEffect(() => {
    const loadTrips = async () => {
      const supabase = createClient()

      console.log(`[v0] Loading trips from Supabase for username: ${username}`)

      try {
        let query = supabase.from("trips").select("*").eq("client_username", username)

        // For cliente2, only show trips with exportador "PEROXIDOS"
        if (username.toLowerCase() === "cliente2") {
          query = query.ilike("exportador", "%PEROXIDOS%")
        }

        const { data, error } = await query

        if (error) {
          console.error("[v0] Error loading trips from Supabase:", error)
          return
        }

        console.log(`[v0] Loaded ${data?.length || 0} trips from Supabase`)

        // Map Supabase data to Trip interface
        const mappedTrips: Trip[] = (data || []).map((trip) => ({
          id: trip.id,
          crt: trip.crt || "",
          clientReference: trip.client_reference || "",
          clientUsername: trip.client_username || "",
          startDate: trip.start_date || "",
          endDate: trip.end_date || "",
          origin: trip.origem || "",
          destination: trip.destino || "",
          status: trip.status || "pending",
          proofOfDelivery: trip.proof_of_delivery_url || "",
          invoice: trip.fatura || "",
          driverName: trip.driver_name || "",
          vehiclePlate: trip.placa_cavalo || "",
          trailerPlate: trip.placa_carreta || "",
          exportador: trip.exportador || "",
          trackingStatus: trip.tracking_status || "",
          trackingDetails: trip.tracking_details || [],
        }))

        setTrips(mappedTrips)
        setFilteredTrips(mappedTrips)
      } catch (error) {
        console.error("[v0] Error loading trips:", error)
      }
    }

    loadTrips()
  }, [username])

  const handleSearch = () => {
    let filtered = trips

    if (crtFilter) {
      filtered = filtered.filter((trip) => trip.crt.toLowerCase().includes(crtFilter.toLowerCase()))
    }

    if (referenceFilter) {
      filtered = filtered.filter((trip) => trip.clientReference.toLowerCase().includes(referenceFilter.toLowerCase()))
    }

    if (dateFilter) {
      filtered = filtered.filter((trip) => trip.startDate.includes(dateFilter) || trip.endDate.includes(dateFilter))
    }

    setFilteredTrips(filtered)
  }

  const handleDownloadProof = (trip: Trip) => {
    if (!trip.proofOfDelivery) {
      alert("Comprovante de entrega não disponível para esta viagem")
      return
    }

    const link = document.createElement("a")
    link.href = trip.proofOfDelivery
    link.download = `comprovante-${trip.crt}.pdf`
    link.click()
  }

  const clearFilters = () => {
    setCrtFilter("")
    setReferenceFilter("")
    setDateFilter("")
    setFilteredTrips(trips)
  }

  const generatePDFReport = () => {
    // Apply export filters
    let tripsToExport = [...trips]

    // Filter by period
    if (exportPeriodStart) {
      tripsToExport = tripsToExport.filter((t) => new Date(t.startDate) >= new Date(exportPeriodStart))
    }
    if (exportPeriodEnd) {
      tripsToExport = tripsToExport.filter((t) => new Date(t.startDate) <= new Date(exportPeriodEnd))
    }

    // Filter by completed status
    if (exportOnlyCompleted) {
      tripsToExport = tripsToExport.filter((t) => t.status === "Concluída")
    }

    // Filter by origin
    if (exportOriginFilter && exportOriginFilter !== "all") {
      tripsToExport = tripsToExport.filter((t) => t.origin.toLowerCase().includes(exportOriginFilter.toLowerCase()))
    }

    // Filter by destination
    if (exportDestinationFilter && exportDestinationFilter !== "all") {
      tripsToExport = tripsToExport.filter((t) =>
        t.destination.toLowerCase().includes(exportDestinationFilter.toLowerCase()),
      )
    }

    const pdf = new jsPDF()
    const pageWidth = pdf.internal.pageSize.getWidth()
    const pageHeight = pdf.internal.pageSize.getHeight()
    const margin = 15
    let yPos = margin

    pdf.setFillColor(64, 156, 193)
    pdf.rect(0, 0, pageWidth, 35, "F")

    pdf.setFontSize(22)
    pdf.setFont("helvetica", "bold")
    pdf.setTextColor(255, 255, 255)
    pdf.text("RELATÓRIO DE VIAGENS", pageWidth / 2, 15, { align: "center" })

    pdf.setFontSize(11)
    pdf.setFont("helvetica", "normal")
    pdf.text(`Cliente: ${username}`, pageWidth / 2, 23, { align: "center" })

    pdf.setFontSize(9)
    pdf.text(
      `Gerado em: ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}`,
      pageWidth / 2,
      29,
      { align: "center" },
    )

    yPos = 45

    if (exportPeriodStart || exportPeriodEnd || exportOnlyCompleted || exportOriginFilter || exportDestinationFilter) {
      pdf.setFillColor(245, 248, 250)
      pdf.roundedRect(margin, yPos, pageWidth - 2 * margin, 15, 2, 2, "F")

      yPos += 5
      pdf.setFontSize(9)
      pdf.setFont("helvetica", "bold")
      pdf.setTextColor(64, 156, 193)
      pdf.text("Filtros Aplicados:", margin + 3, yPos)

      yPos += 5
      pdf.setFontSize(8)
      pdf.setFont("helvetica", "normal")
      pdf.setTextColor(80, 80, 80)

      const filters: string[] = []
      if (exportPeriodStart) filters.push(`Período: desde ${new Date(exportPeriodStart).toLocaleDateString("pt-BR")}`)
      if (exportPeriodEnd) filters.push(`até ${new Date(exportPeriodEnd).toLocaleDateString("pt-BR")}`)
      if (exportOnlyCompleted) filters.push("Status: Concluídas")
      if (exportOriginFilter) filters.push(`Origem: ${exportOriginFilter}`)
      if (exportDestinationFilter) filters.push(`Destino: ${exportDestinationFilter}`)

      pdf.text(filters.join(" | "), margin + 3, yPos)
      yPos += 10
    }

    yPos += 5
    const cardWidth = (pageWidth - 2 * margin - 10) / 3

    // Total trips card
    pdf.setFillColor(59, 130, 246)
    pdf.roundedRect(margin, yPos, cardWidth, 25, 3, 3, "F")
    pdf.setFontSize(24)
    pdf.setFont("helvetica", "bold")
    pdf.setTextColor(255, 255, 255)
    pdf.text(String(tripsToExport.length), margin + cardWidth / 2, yPos + 12, { align: "center" })
    pdf.setFontSize(9)
    pdf.setFont("helvetica", "normal")
    pdf.text("Total de Viagens", margin + cardWidth / 2, yPos + 20, { align: "center" })

    // Completed trips card
    const completedCount = tripsToExport.filter((t) => t.status === "Concluída").length
    pdf.setFillColor(34, 197, 94)
    pdf.roundedRect(margin + cardWidth + 5, yPos, cardWidth, 25, 3, 3, "F")
    pdf.setFontSize(24)
    pdf.setFont("helvetica", "bold")
    pdf.setTextColor(255, 255, 255)
    pdf.text(String(completedCount), margin + cardWidth + 5 + cardWidth / 2, yPos + 12, { align: "center" })
    pdf.setFontSize(9)
    pdf.setFont("helvetica", "normal")
    pdf.text("Concluídas", margin + cardWidth + 5 + cardWidth / 2, yPos + 20, { align: "center" })

    // In transit card
    const inTransitCount = tripsToExport.filter((t) => t.status === "Em Trânsito").length
    pdf.setFillColor(249, 115, 22)
    pdf.roundedRect(margin + 2 * (cardWidth + 5), yPos, cardWidth, 25, 3, 3, "F")
    pdf.setFontSize(24)
    pdf.setFont("helvetica", "bold")
    pdf.setTextColor(255, 255, 255)
    pdf.text(String(inTransitCount), margin + 2 * (cardWidth + 5) + cardWidth / 2, yPos + 12, { align: "center" })
    pdf.setFontSize(9)
    pdf.setFont("helvetica", "normal")
    pdf.text("Em Trânsito", margin + 2 * (cardWidth + 5) + cardWidth / 2, yPos + 20, { align: "center" })

    yPos += 35

    pdf.setFontSize(12)
    pdf.setFont("helvetica", "bold")
    pdf.setTextColor(40, 40, 40)
    pdf.text("Viagens por Mês", margin, yPos)

    yPos += 8

    const tripsByMonth = getTripsByMonth(tripsToExport)
    const maxTrips = Math.max(...tripsByMonth.map((m) => m.count), 1)
    const chartHeight = 50
    const barSpacing = 2
    const barWidth = Math.min((pageWidth - 2 * margin) / tripsByMonth.length - barSpacing, 20)

    tripsByMonth.forEach(({ month, count }, index) => {
      const barHeight = (count / maxTrips) * chartHeight
      const x = margin + index * (barWidth + barSpacing)
      const y = yPos + chartHeight - barHeight

      // Draw bar with gradient effect
      pdf.setFillColor(64, 156, 193)
      pdf.roundedRect(x, y, barWidth, barHeight, 1, 1, "F")

      // Count on top of bar
      pdf.setFontSize(8)
      pdf.setFont("helvetica", "bold")
      pdf.setTextColor(64, 156, 193)
      pdf.text(String(count), x + barWidth / 2, y - 2, { align: "center" })

      // Month label
      pdf.setFontSize(7)
      pdf.setFont("helvetica", "normal")
      pdf.setTextColor(100, 100, 100)
      pdf.text(month, x + barWidth / 2, yPos + chartHeight + 5, { align: "center", angle: 45 })
    })

    yPos += chartHeight + 15

    pdf.setFontSize(12)
    pdf.setFont("helvetica", "bold")
    pdf.setTextColor(40, 40, 40)
    pdf.text("Detalhamento de Viagens", margin, yPos)

    yPos += 8

    tripsToExport.forEach((trip, index) => {
      if (yPos > pageHeight - 45) {
        pdf.addPage()
        yPos = margin
      }

      // Trip card background
      pdf.setFillColor(248, 250, 252)
      pdf.roundedRect(margin, yPos, pageWidth - 2 * margin, 28, 2, 2, "F")

      // Status badge
      const statusColor = trip.status === "Concluída" ? [34, 197, 94] : [249, 115, 22]
      pdf.setFillColor(statusColor[0], statusColor[1], statusColor[2])
      pdf.roundedRect(pageWidth - margin - 30, yPos + 3, 25, 6, 1.5, 1.5, "F")
      pdf.setFontSize(7)
      pdf.setFont("helvetica", "bold")
      pdf.setTextColor(255, 255, 255)
      pdf.text(trip.status, pageWidth - margin - 17.5, yPos + 6.5, { align: "center" })

      // Trip info
      yPos += 6
      pdf.setFontSize(10)
      pdf.setFont("helvetica", "bold")
      pdf.setTextColor(30, 30, 30)
      pdf.text(`${index + 1}. CRT: ${trip.crt}`, margin + 3, yPos)

      yPos += 5
      pdf.setFontSize(8)
      pdf.setFont("helvetica", "normal")
      pdf.setTextColor(80, 80, 80)
      pdf.text(`Ref: ${trip.clientReference}`, margin + 3, yPos)

      yPos += 5
      pdf.setFont("helvetica", "bold")
      pdf.text("Origem: ", margin + 3, yPos)
      pdf.setFont("helvetica", "normal")
      pdf.text(trip.origin, margin + 20, yPos)

      yPos += 5
      pdf.setFont("helvetica", "bold")
      pdf.text("Destino: ", margin + 3, yPos)
      pdf.setFont("helvetica", "normal")
      pdf.text(trip.destination, margin + 22, yPos)

      yPos += 5
      pdf.setFontSize(7)
      pdf.setTextColor(100, 100, 100)
      pdf.text(`Início: ${new Date(trip.startDate).toLocaleDateString("pt-BR")}`, margin + 3, yPos)

      if (trip.endDate) {
        pdf.text(`| Término: ${new Date(trip.endDate).toLocaleDateString("pt-BR")}`, margin + 40, yPos)
      }

      yPos += 7

      // Invoice
      if (trip.invoice) {
        pdf.text(`Fatura: ${trip.invoice}`, margin + 3, yPos)
        yPos += 5
      }

      // Driver
      if (trip.driverName) {
        pdf.text(`Motorista: ${trip.driverName}`, margin + 3, yPos)
        yPos += 5
      }

      // Vehicle
      if (trip.vehiclePlate || trip.trailerPlate) {
        pdf.text(
          `Veículo: ${trip.vehiclePlate ? `Cavalo: ${trip.vehiclePlate}` : ""} ${trip.vehiclePlate && trip.trailerPlate ? "| " : ""} ${trip.trailerPlate ? `Carreta: ${trip.trailerPlate}` : ""}`,
          margin + 3,
          yPos,
        )
        yPos += 5
      }
    })

    // Footer
    yPos = pageHeight - 10
    pdf.setFontSize(7)
    pdf.setFont("helvetica", "normal")
    pdf.setTextColor(150, 150, 150)
    pdf.text("INLOG - Integração Logística | www.inlog.biz", pageWidth / 2, yPos, { align: "center" })

    pdf.save(`relatorio-viagens-${username}-${new Date().toISOString().split("T")[0]}.pdf`)
  }

  const getTripsByMonth = (tripsData: Trip[] = trips) => {
    const monthCounts: { [key: string]: number } = {}

    tripsData.forEach((trip) => {
      const date = new Date(trip.startDate)
      const monthYear = `${(date.getMonth() + 1).toString().padStart(2, "0")}/${date.getFullYear()}`
      monthCounts[monthYear] = (monthCounts[monthYear] || 0) + 1
    })

    return Object.entries(monthCounts)
      .sort((a, b) => {
        const [monthA, yearA] = a[0].split("/").map(Number)
        const [monthB, yearB] = b[0].split("/").map(Number)
        return yearA !== yearB ? yearA - yearB : monthA - monthB
      })
      .map(([month, count]) => ({ month, count }))
  }

  const tripsByMonth = getTripsByMonth()
  const maxTrips = Math.max(...tripsByMonth.map((m) => m.count), 1)

  const handleViewTracking = (trip: Trip) => {
    setSelectedTrip(trip)
    setShowTrackingDialog(true)
  }

  const renderTrips = (tripsToRender: Trip[]) => {
    if (viewMode === "card") {
      return <div className="grid gap-4">{tripsToRender.map(renderTripCard)}</div>
    }

    return (
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/50 border-b">
              <tr>
                <th className="text-left p-3 text-sm font-semibold">CRT</th>
                <th className="text-left p-3 text-sm font-semibold">Referência</th>
                <th className="text-left p-3 text-sm font-semibold">Rota</th>
                <th className="text-left p-3 text-sm font-semibold">Status</th>
                <th className="text-left p-3 text-sm font-semibold">Datas</th>
                <th className="text-right p-3 text-sm font-semibold">Ações</th>
              </tr>
            </thead>
            <tbody>
              {tripsToRender.map((trip) => (
                <tr key={trip.id} className="border-b hover:bg-muted/30 transition-colors">
                  <td className="p-3 text-sm font-medium">{trip.crt}</td>
                  <td className="p-3 text-sm text-muted-foreground">{trip.clientReference}</td>
                  <td className="p-3 text-sm">
                    <div className="flex items-center gap-1">
                      <span className="truncate max-w-[100px]">{trip.origin}</span>
                      <span>→</span>
                      <span className="truncate max-w-[100px]">{trip.destination}</span>
                    </div>
                  </td>
                  <td className="p-3">
                    <div
                      className={`px-2 py-1 rounded-full text-xs font-medium inline-block ${
                        trip.status === "Concluída"
                          ? "bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-400"
                          : trip.status === "Em Trânsito"
                            ? "bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400"
                            : "bg-amber-100 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400"
                      }`}
                    >
                      {trip.status}
                    </div>
                  </td>
                  <td className="p-3 text-sm">
                    <div className="flex flex-col">
                      <span>Início: {new Date(trip.startDate).toLocaleDateString("pt-BR")}</span>
                      {trip.endDate && (
                        <span className="text-muted-foreground">
                          Fim: {new Date(trip.endDate).toLocaleDateString("pt-BR")}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="p-3 text-right">
                    <div className="flex gap-2 justify-end">
                      {trip.trackingStatus && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleViewTracking(trip)}
                          title="Ver Rastreamento"
                        >
                          <TruckIcon className="w-4 h-4" />
                        </Button>
                      )}
                      {trip.proofOfDelivery && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDownloadProof(trip)}
                          title="Baixar Comprovante"
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    )
  }

  const renderTripCard = (trip: Trip) => (
    <Card key={trip.id} className="p-6 hover:shadow-lg transition-shadow border-l-4 border-l-primary">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-xl font-semibold mb-1">CRT: {trip.crt}</h3>
          <p className="text-sm text-muted-foreground">Ref: {trip.clientReference}</p>
          {trip.invoice && <p className="text-sm text-muted-foreground">Fatura: {trip.invoice}</p>}
        </div>
        <div
          className={`px-3 py-1 rounded-full text-sm font-medium ${
            trip.status === "Concluída"
              ? "bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-400"
              : trip.status === "Em Trânsito"
                ? "bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400"
                : "bg-amber-100 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400"
          }`}
        >
          {trip.status}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <div className="flex items-start gap-3">
          <MapPin className="w-5 h-5 text-primary mt-0.5" />
          <div>
            <p className="text-sm font-medium">Origem</p>
            <p className="text-sm text-muted-foreground">{trip.origin}</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <MapPin className="w-5 h-5 text-primary mt-0.5" />
          <div>
            <p className="text-sm font-medium">Destino</p>
            <p className="text-sm text-muted-foreground">{trip.destination}</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Calendar className="w-5 h-5 text-primary mt-0.5" />
          <div>
            <p className="text-sm font-medium">Data de Início</p>
            <p className="text-sm text-muted-foreground">{new Date(trip.startDate).toLocaleDateString("pt-BR")}</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Calendar className="w-5 h-5 text-primary mt-0.5" />
          <div>
            <p className="text-sm font-medium">Data de Término</p>
            <p className="text-sm text-muted-foreground">
              {trip.endDate ? new Date(trip.endDate).toLocaleDateString("pt-BR") : "Em andamento"}
            </p>
          </div>
        </div>

        {trip.driverName && (
          <div className="flex items-start gap-3">
            <User className="w-5 h-5 text-primary mt-0.5" />
            <div>
              <p className="text-sm font-medium">Motorista</p>
              <p className="text-sm text-muted-foreground">{trip.driverName}</p>
            </div>
          </div>
        )}

        {(trip.vehiclePlate || trip.trailerPlate) && (
          <div className="flex items-start gap-3">
            <Package className="w-5 h-5 text-primary mt-0.5" />
            <div>
              <p className="text-sm font-medium">Veículo</p>
              <p className="text-sm text-muted-foreground">
                {trip.vehiclePlate && `Cavalo: ${trip.vehiclePlate}`}
                {trip.vehiclePlate && trip.trailerPlate && " | "}
                {trip.trailerPlate && `Carreta: ${trip.trailerPlate}`}
              </p>
            </div>
          </div>
        )}
      </div>

      {trip.trackingStatus && (
        <div className="pt-4 border-t mt-4 space-y-3">
          <Button variant="outline" onClick={() => handleViewTracking(trip)} className="gap-2 w-full">
            <TruckIcon className="w-4 h-4" />
            Ver Rastreamento da Viagem
          </Button>

          <TrackingShare
            crt={trip.crt}
            origin={trip.origin}
            destination={trip.destination}
            trackingStatus={trip.trackingStatus}
            clientReference={trip.clientReference}
          />
        </div>
      )}

      {trip.proofOfDelivery && (
        <div className="pt-4 border-t">
          <Button onClick={() => handleDownloadProof(trip)} className="gap-2">
            <Download className="w-4 h-4" />
            Baixar Comprovante de Entrega
          </Button>
        </div>
      )}

      {!trip.proofOfDelivery && trip.status === "Concluída" && (
        <div className="pt-4 border-t">
          <p className="text-sm text-muted-foreground flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Comprovante de entrega em processamento
          </p>
        </div>
      )}
    </Card>
  )

  return (
    <div className="w-full space-y-6">
      <div className="text-center bg-gradient-to-r from-primary/10 via-primary/5 to-background p-8 rounded-2xl">
        <h2 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          Portal do Cliente
        </h2>
        <p className="text-muted-foreground">Acompanhe suas viagens e baixe comprovantes de entrega</p>
      </div>

      <Tabs defaultValue="dashboard" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="search">Pesquisar</TabsTrigger>
          <TabsTrigger value="all">Todas</TabsTrigger>
          <TabsTrigger value="collection-requests">Coletas</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-6">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Download className="w-5 h-5 text-primary" />
                <h3 className="text-lg font-semibold">Exportar Relatório</h3>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowExportFilters(!showExportFilters)}
                className="gap-2"
              >
                <Filter className="w-4 h-4" />
                {showExportFilters ? "Ocultar" : "Mostrar"} Filtros
              </Button>
            </div>

            {showExportFilters && (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4 p-4 bg-muted/30 rounded-lg">
                <div className="space-y-2">
                  <Label htmlFor="export-period-start" className="text-sm">
                    Data Início
                  </Label>
                  <Input
                    id="export-period-start"
                    type="date"
                    value={exportPeriodStart}
                    onChange={(e) => setExportPeriodStart(e.target.value)}
                    className="h-9"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="export-period-end" className="text-sm">
                    Data Fim
                  </Label>
                  <Input
                    id="export-period-end"
                    type="date"
                    value={exportPeriodEnd}
                    onChange={(e) => setExportPeriodEnd(e.target.value)}
                    className="h-9"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="export-origin" className="text-sm">
                    Origem
                  </Label>
                  <Select value={exportOriginFilter} onValueChange={setExportOriginFilter}>
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="Selecione a origem" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas as origens</SelectItem>
                      {uniqueOrigins.map((origin) => (
                        <SelectItem key={origin} value={origin}>
                          {origin}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="export-destination" className="text-sm">
                    Destino
                  </Label>
                  <Select value={exportDestinationFilter} onValueChange={setExportDestinationFilter}>
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="Selecione o destino" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os destinos</SelectItem>
                      {uniqueDestinations.map((destination) => (
                        <SelectItem key={destination} value={destination}>
                          {destination}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2 pt-6">
                  <Checkbox
                    id="export-completed"
                    checked={exportOnlyCompleted}
                    onCheckedChange={(checked) => setExportOnlyCompleted(checked as boolean)}
                  />
                  <Label htmlFor="export-completed" className="text-sm cursor-pointer">
                    Apenas viagens concluídas
                  </Label>
                </div>
              </div>
            )}

            <Button onClick={generatePDFReport} className="w-full gap-2" disabled={trips.length === 0}>
              <Download className="w-4 h-4" />
              Gerar Relatório em PDF
            </Button>
          </Card>

          {/* Statistics cards */}
          <div className="grid md:grid-cols-3 gap-4">
            <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 border-blue-200 dark:border-blue-800">
              <div className="text-center">
                <TrendingUp className="w-8 h-8 text-blue-600 dark:text-blue-400 mx-auto mb-2" />
                <p className="text-4xl font-bold text-blue-600 dark:text-blue-400">{trips.length}</p>
                <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">Total de Viagens</p>
              </div>
            </Card>
            <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950 dark:to-green-900 border-green-200 dark:border-green-800">
              <div className="text-center">
                <Package className="w-8 h-8 text-green-600 dark:text-green-400 mx-auto mb-2" />
                <p className="text-4xl font-bold text-green-600 dark:text-green-400">
                  {trips.filter((t) => t.status === "Concluída").length}
                </p>
                <p className="text-sm text-green-700 dark:text-green-300 mt-1">Concluídas</p>
              </div>
            </Card>
            <Card className="p-6 bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-950 dark:to-orange-900 border-orange-200 dark:border-orange-800">
              <div className="text-center">
                <MapPin className="w-8 h-8 text-orange-600 dark:text-orange-400 mx-auto mb-2" />
                <p className="text-4xl font-bold text-orange-600 dark:text-orange-400">
                  {trips.filter((t) => t.status === "Em Trânsito").length}
                </p>
                <p className="text-sm text-orange-700 dark:text-orange-300 mt-1">Em Trânsito</p>
              </div>
            </Card>
          </div>

          <Card className="p-6">
            <div className="flex items-center gap-2 mb-6">
              <BarChart3 className="w-6 h-6 text-primary" />
              <h3 className="text-2xl font-bold">Viagens por Mês</h3>
            </div>

            {tripsByMonth.length === 0 ? (
              <div className="py-12 text-center">
                <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Nenhuma viagem cadastrada ainda</p>
              </div>
            ) : (
              <div className="space-y-4">
                {tripsByMonth.map(({ month, count }) => (
                  <div key={month} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{month}</span>
                      <span className="text-sm text-muted-foreground">{count} viagens</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-10 overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-primary to-primary/70 h-full flex items-center justify-end px-4 text-primary-foreground text-sm font-medium transition-all duration-500"
                        style={{ width: `${(count / maxTrips) * 100}%` }}
                      >
                        {count}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </TabsContent>

        {/* Buscar viagens com filtros */}
        <TabsContent value="search" className="space-y-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Search className="w-5 h-5 text-primary" />
              <h3 className="text-lg font-semibold">Buscar Viagens</h3>
            </div>
            <div className="flex gap-2">
              <div className="flex gap-1 border rounded-lg p-1 bg-background">
                <Button
                  variant={viewMode === "card" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("card")}
                  className="gap-2"
                >
                  <LayoutGrid className="w-4 h-4" />
                  Cards
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                  className="gap-2"
                >
                  <ListIcon className="w-4 h-4" />
                  Lista
                </Button>
              </div>
              <Button onClick={clearFilters} className="gap-2">
                <Download className="w-4 h-4" />
                Limpar Filtros
              </Button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4 mb-4">
            <div className="space-y-2">
              <Label htmlFor="crt" className="text-sm">
                CRT
              </Label>
              <Input id="crt" value={crtFilter} onChange={(e) => setCrtFilter(e.target.value)} className="h-9" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="reference" className="text-sm">
                Referência do Cliente
              </Label>
              <Input
                id="reference"
                value={referenceFilter}
                onChange={(e) => setReferenceFilter(e.target.value)}
                className="h-9"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="date" className="text-sm">
                Data
              </Label>
              <Input
                id="date"
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="h-9"
              />
            </div>
          </div>

          <Button onClick={handleSearch} className="w-full gap-2">
            <Search className="w-4 h-4" />
            Buscar
          </Button>

          <div className="space-y-4 mt-4">
            {filteredTrips.length === 0 ? (
              <Card className="p-12 text-center">
                <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Nenhuma viagem encontrada</h3>
                <p className="text-muted-foreground">Não foram encontradas viagens com os filtros aplicados</p>
              </Card>
            ) : (
              renderTrips(filteredTrips)
            )}
          </div>
        </TabsContent>

        {/* Todas as viagens */}
        <TabsContent value="all" className="space-y-6">
          <div className="flex items-center justify-between mb-4">
            <div className="text-left">
              <h3 className="text-xl font-semibold">Histórico Completo de Viagens</h3>
              <p className="text-muted-foreground">Visualize todas as suas viagens cadastradas</p>
            </div>
            <div className="flex gap-1 border rounded-lg p-1 bg-background">
              <Button
                variant={viewMode === "card" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("card")}
                className="gap-2"
              >
                <LayoutGrid className="w-4 h-4" />
                Cards
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("list")}
                className="gap-2"
              >
                <ListIcon className="w-4 h-4" />
                Lista
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            {trips.length === 0 ? (
              <Card className="p-12 text-center">
                <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Nenhuma viagem encontrada</h3>
                <p className="text-muted-foreground">Você ainda não possui viagens cadastradas</p>
              </Card>
            ) : (
              renderTrips(trips)
            )}
          </div>
        </TabsContent>

        <TabsContent value="collection-requests">
          <ClientCollectionRequestsTab username={username} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
