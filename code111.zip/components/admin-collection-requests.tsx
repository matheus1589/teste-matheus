"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Package, CheckCircle, XCircle, AlertCircle, Clock, Loader2, Eye, FileText, Download } from "lucide-react"
import { toast } from "sonner"

interface CollectionRequest {
  id: string
  client_username: string
  collection_type: string
  status: string
  is_chemical: boolean
  driver_name: string | null
  origin: string | null
  destination: string | null
  pickup_address: string | null
  delivery_address: string | null
  ncm_products: string | null
  net_weight: number | null
  product_weight: number | null
  cargo_type: string | null
  volume_quantity: number | null
  is_container: boolean | null
  container_size: string | null
  is_isotank: boolean | null
  additional_info_requested: string | null
  admin_notes: string | null
  document_url: string | null
  created_at: string
  approved_at: string | null
  client_users?: {
    company_name: string
    contact_name: string
  }
  incoterms: string | null
  observation: string | null
  admin_observation: string | null
  is_palletized: boolean | null
  pallet_quantity: number | null
  loading_forecast: string | null
}

const statusConfig = {
  pendente: {
    label: "Carga pendente de aprovação",
    icon: Clock,
    color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-950 dark:text-yellow-200",
    badge: "bg-yellow-200 dark:bg-yellow-800 text-yellow-900 dark:text-yellow-100",
  },
  aprovada: {
    label: "Aprovada",
    icon: CheckCircle,
    color: "bg-green-100 text-green-800 dark:bg-green-950 dark:text-green-200",
    badge: "bg-green-200 dark:bg-green-800 text-green-900 dark:text-green-100",
  },
  rejeitada: {
    label: "Rejeitada",
    icon: XCircle,
    color: "bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-200",
    badge: "bg-red-200 dark:bg-red-800 text-red-900 dark:text-red-100",
  },
  aguardando_info: {
    label: "Aguardando Informações",
    icon: AlertCircle,
    color: "bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-200",
    badge: "bg-orange-200 dark:bg-orange-800 text-orange-900 dark:text-orange-100",
  },
}

export function AdminCollectionRequests() {
  const [requests, setRequests] = useState<CollectionRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [updatingId, setUpdatingId] = useState<string | null>(null)
  const [filterStatus, setFilterStatus] = useState<string>("all")
  const [selectedRequest, setSelectedRequest] = useState<CollectionRequest | null>(null)
  const [showDetailsDialog, setShowDetailsDialog] = useState(false)

  useEffect(() => {
    loadRequests()
  }, [])

  const loadRequests = async () => {
    try {
      const response = await fetch("/api/collection-requests/admin/list")
      if (!response.ok) throw new Error("Falha ao carregar solicitações")

      const data = await response.json()
      setRequests(data)
    } catch (error) {
      console.error("[v0] Load error:", error)
      toast.error("Erro ao carregar solicitações")
    } finally {
      setLoading(false)
    }
  }

  const handleStatusUpdate = async (
    requestId: string,
    status: string,
    rejectionReason?: string,
    additionalInfo?: string,
    adminObservation?: string,
  ) => {
    setUpdatingId(requestId)
    try {
      const response = await fetch("/api/collection-requests/admin/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          collectionRequestId: requestId,
          status,
          rejectionReason,
          additionalInfoRequested: additionalInfo,
          adminNotes: adminObservation,
        }),
      })

      if (!response.ok) throw new Error("Erro ao atualizar status")

      toast.success("Solicitação atualizada com sucesso")
      loadRequests()
    } catch (error) {
      console.error("[v0] Update error:", error)
      toast.error("Erro ao atualizar solicitação")
    } finally {
      setUpdatingId(null)
    }
  }

  const filteredRequests = filterStatus === "all" ? requests : requests.filter((r) => r.status === filterStatus)

  if (loading) {
    return (
      <Card className="p-12 text-center">
        <Loader2 className="w-16 h-16 text-muted-foreground mx-auto mb-4 animate-spin" />
        <p className="text-muted-foreground">Carregando solicitações...</p>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header com filtro */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h3 className="text-lg font-semibold">Solicitações de Coleta</h3>
          <p className="text-sm text-muted-foreground">
            Total: {requests.length} | Pendentes: {requests.filter((r) => r.status === "pendente").length}
          </p>
        </div>
        <div className="flex gap-2 items-center">
          <Label className="text-sm">Filtrar por status:</Label>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              <SelectItem value="pendente">Pendente</SelectItem>
              <SelectItem value="aprovada">Aprovada</SelectItem>
              <SelectItem value="rejeitada">Rejeitada</SelectItem>
              <SelectItem value="aguardando_info">Aguardando Info</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Lista de solicitações */}
      {filteredRequests.length === 0 ? (
        <Card className="p-12 text-center">
          <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Nenhuma solicitação</h3>
          <p className="text-muted-foreground">Não há solicitações com este status</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredRequests.map((request) => {
            const status = statusConfig[request.status as keyof typeof statusConfig] || statusConfig.pendente
            const Icon = status.icon

            return (
              <Card key={request.id} className="p-6">
                <div className="space-y-4">
                  {/* Header */}
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3 flex-1">
                      <div className={`p-3 rounded-lg ${status.color}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                          <h4 className="font-semibold">
                            {request.collection_type === "exportacao" ? "Exportação" : "Importação"}
                          </h4>
                          <Badge className={status.badge}>{status.label}</Badge>
                          {request.is_chemical && (
                            <Badge variant="outline" className="bg-orange-50 dark:bg-orange-950">
                              Química
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm font-medium text-foreground">
                          {request.client_users?.company_name || request.client_username}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(request.created_at).toLocaleDateString("pt-BR")} às{" "}
                          {new Date(request.created_at).toLocaleTimeString("pt-BR")}
                        </p>
                      </div>
                    </div>

                    {/* Quick Actions */}
                    <div className="flex gap-2">
                      <Dialog
                        open={showDetailsDialog && selectedRequest?.id === request.id}
                        onOpenChange={setShowDetailsDialog}
                      >
                        <DialogTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedRequest(request)}
                            className="gap-2"
                          >
                            <Eye className="w-4 h-4" />
                            Detalhes
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>Detalhes da Solicitação de Coleta</DialogTitle>
                          </DialogHeader>
                          {selectedRequest && (
                            <div className="space-y-6">
                              {/* Client Info */}
                              <div className="grid md:grid-cols-2 gap-4 pb-4 border-b">
                                <div>
                                  <p className="text-xs text-muted-foreground font-semibold">CLIENTE</p>
                                  <p className="text-sm font-medium">{selectedRequest.client_users?.company_name}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {selectedRequest.client_users?.contact_name}
                                  </p>
                                </div>
                                <div>
                                  <p className="text-xs text-muted-foreground font-semibold">TIPO</p>
                                  <p className="text-sm font-medium">
                                    {selectedRequest.collection_type === "exportacao" ? "Exportação" : "Importação"}
                                  </p>
                                  {selectedRequest.is_chemical && (
                                    <p className="text-xs text-orange-600 dark:text-orange-400 font-medium">
                                      Carga Química
                                    </p>
                                  )}
                                </div>
                              </div>

                              {/* Cargo Details */}
                              <div className="pb-4 border-b">
                                <p className="text-xs text-muted-foreground font-semibold mb-3">INFORMAÇÕES DE CARGA</p>
                                <div className="grid md:grid-cols-2 gap-4">
                                  {selectedRequest.pickup_address && (
                                    <div>
                                      <p className="text-xs text-muted-foreground">Endereço de Coleta</p>
                                      <p className="text-sm font-medium">{selectedRequest.pickup_address}</p>
                                    </div>
                                  )}
                                  {selectedRequest.delivery_address && (
                                    <div>
                                      <p className="text-xs text-muted-foreground">Endereço de Entrega</p>
                                      <p className="text-sm font-medium">{selectedRequest.delivery_address}</p>
                                    </div>
                                  )}
                                  {selectedRequest.ncm_products && (
                                    <div>
                                      <p className="text-xs text-muted-foreground">NCM Produtos</p>
                                      <p className="text-sm font-medium">{selectedRequest.ncm_products}</p>
                                    </div>
                                  )}
                                  {selectedRequest.cargo_type && (
                                    <div>
                                      <p className="text-xs text-muted-foreground">Tipo de Carga</p>
                                      <p className="text-sm font-medium capitalize">{selectedRequest.cargo_type}</p>
                                    </div>
                                  )}
                                  {selectedRequest.product_weight && (
                                    <div>
                                      <p className="text-xs text-muted-foreground">Peso do Produto</p>
                                      <p className="text-sm font-medium">{selectedRequest.product_weight} kg</p>
                                    </div>
                                  )}
                                  {selectedRequest.net_weight && (
                                    <div>
                                      <p className="text-xs text-muted-foreground">Peso Líquido</p>
                                      <p className="text-sm font-medium">{selectedRequest.net_weight} kg</p>
                                    </div>
                                  )}
                                  {selectedRequest.volume_quantity && (
                                    <div>
                                      <p className="text-xs text-muted-foreground">Quantidade de Volumes</p>
                                      <p className="text-sm font-medium">{selectedRequest.volume_quantity} un.</p>
                                    </div>
                                  )}
                                  {selectedRequest.container_size && (
                                    <div>
                                      <p className="text-xs text-muted-foreground">Tamanho do Container</p>
                                      <p className="text-sm font-medium">{selectedRequest.container_size}</p>
                                    </div>
                                  )}
                                  {selectedRequest.is_isotank && (
                                    <div>
                                      <p className="text-xs text-muted-foreground">Tipo Especial</p>
                                      <Badge variant="outline" className="bg-purple-50 dark:bg-purple-950">
                                        Isotank
                                      </Badge>
                                    </div>
                                  )}
                                </div>
                              </div>

                              {/* Trip Details */}
                              <div className="grid md:grid-cols-2 gap-4 pb-4 border-b">
                                {selectedRequest.driver_name && (
                                  <div>
                                    <p className="text-xs text-muted-foreground font-semibold">MOTORISTA</p>
                                    <p className="text-sm">{selectedRequest.driver_name}</p>
                                  </div>
                                )}
                                {selectedRequest.origin && (
                                  <div>
                                    <p className="text-xs text-muted-foreground font-semibold">ORIGEM</p>
                                    <p className="text-sm">{selectedRequest.origin}</p>
                                  </div>
                                )}
                                {selectedRequest.destination && (
                                  <div>
                                    <p className="text-xs text-muted-foreground font-semibold">DESTINO</p>
                                    <p className="text-sm">{selectedRequest.destination}</p>
                                  </div>
                                )}
                              </div>

                              {/* Document */}
                              {selectedRequest.document_url && (
                                <div className="pb-4 border-b">
                                  <p className="text-xs text-muted-foreground font-semibold mb-2">DOCUMENTO</p>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="gap-2 bg-transparent"
                                    onClick={() => window.open(selectedRequest.document_url, "_blank")}
                                  >
                                    <Download className="w-4 h-4" />
                                    Download Documento
                                  </Button>
                                </div>
                              )}

                              {/* Admin Notes */}
                              {selectedRequest.admin_notes && (
                                <Alert>
                                  <AlertCircle className="h-4 w-4" />
                                  <AlertDescription>
                                    <strong>Notas Admin:</strong> {selectedRequest.admin_notes}
                                  </AlertDescription>
                                </Alert>
                              )}
                            </div>
                          )}
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>

                  {/* Action Section based on status */}
                  {request.status === "pendente" && (
                    <AdminCollectionActionDialog
                      request={request}
                      onApprove={(obs) => handleStatusUpdate(request.id, "aprovada", undefined, undefined, obs)}
                      onRequestInfo={(info) => handleStatusUpdate(request.id, "aguardando_info", undefined, info)}
                      onReject={(reason) => handleStatusUpdate(request.id, "rejeitada", reason)}
                      isLoading={updatingId === request.id}
                    />
                  )}

                  {request.status === "aguardando_info" && (
                    <Alert className="border-orange-200 bg-orange-50 dark:bg-orange-950/20 dark:border-orange-800">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Informações Solicitadas:</strong> {request.additional_info_requested}
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}

interface AdminCollectionActionDialogProps {
  request: CollectionRequest
  onApprove: (observation: string) => void
  onRequestInfo: (info: string) => void
  onReject: (reason: string) => void
  isLoading: boolean
}

function AdminCollectionActionDialog({
  request,
  onApprove,
  onRequestInfo,
  onReject,
  isLoading,
}: AdminCollectionActionDialogProps) {
  const [action, setAction] = useState<"approve" | "reject" | "request-info" | null>(null)
  const [reason, setReason] = useState("")
  const [observation, setObservation] = useState("")
  const [open, setOpen] = useState(false)

  const handleSubmit = () => {
    switch (action) {
      case "approve":
        onApprove(observation)
        setOpen(false)
        break
      case "reject":
        if (reason.trim()) {
          onReject(reason)
          setOpen(false)
        }
        break
      case "request-info":
        if (reason.trim()) {
          onRequestInfo(reason)
          setOpen(false)
        }
        break
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="w-full gap-2">
          <FileText className="w-4 h-4" />
          Processar Solicitação
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Processar Solicitação</DialogTitle>
        </DialogHeader>

        {!action ? (
          <div className="grid grid-cols-1 gap-3">
            <Button
              onClick={() => setAction("approve")}
              className="bg-green-600 hover:bg-green-700 text-white justify-start"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Aprovar Solicitação
            </Button>
            <Button onClick={() => setAction("reject")} variant="destructive" className="justify-start">
              <XCircle className="w-4 h-4 mr-2" />
              Rejeitar Solicitação
            </Button>
            <Button
              onClick={() => setAction("request-info")}
              className="bg-orange-600 hover:bg-orange-700 text-white justify-start"
            >
              <AlertCircle className="w-4 h-4 mr-2" />
              Solicitar Informações
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {action === "approve" && (
              <div className="space-y-2">
                <Label>Observação de Aprovação (Opcional)</Label>
                <Textarea
                  value={observation}
                  onChange={(e) => setObservation(e.target.value)}
                  placeholder="Adicione uma observação para o cliente..."
                />
                <div className="flex gap-2 justify-end mt-4">
                  <Button variant="ghost" onClick={() => setAction(null)}>
                    Voltar
                  </Button>
                  <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700 text-white">
                    Confirmar Aprovação
                  </Button>
                </div>
              </div>
            )}

            {action === "reject" && (
              <div className="space-y-2">
                <Label>Motivo da Rejeição</Label>
                <Textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Explique o motivo da rejeição..."
                />
                <div className="flex gap-2 justify-end mt-4">
                  <Button variant="ghost" onClick={() => setAction(null)}>
                    Voltar
                  </Button>
                  <Button onClick={handleSubmit} variant="destructive">
                    Confirmar Rejeição
                  </Button>
                </div>
              </div>
            )}

            {action === "request-info" && (
              <div className="space-y-2">
                <Label>Informações Necessárias</Label>
                <Textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Descreva quais informações estão faltando..."
                />
                <div className="flex gap-2 justify-end mt-4">
                  <Button variant="ghost" onClick={() => setAction(null)}>
                    Voltar
                  </Button>
                  <Button onClick={handleSubmit} className="bg-orange-600 hover:bg-orange-700 text-white">
                    Solicitar Informações
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
