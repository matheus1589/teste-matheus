"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Upload, FileText, Loader2, CalendarIcon } from "lucide-react"
import { toast } from "sonner"
import { AddressInputWithHistory } from "./address-input-with-history"

interface ExtractedData {
  driver_name: string | null
  driver_cpf: string | null
  vehicle_plate_head: string | null
  vehicle_plate_trailer: string | null
  origin: string | null
  destination: string | null
  exporter: string | null
  importer: string | null
  invoice: string | null
  pickup_address: string | null
  delivery_address: string | null
  ncm_products: string | null
  net_weight: number | null
  product_weight: number | null
  cargo_type: string | null
  volume_quantity: number | null
  is_isotank: boolean | null
  container_size: string | null
}

export function CollectionRequestForm({ onSuccess }: { onSuccess?: () => void }) {
  const [userEmail, setUserEmail] = useState<string | null>(null)

  const [collectionType, setCollectionType] = useState<"exportacao" | "importacao">("exportacao")
  const [isChemical, setIsChemical] = useState(false)
  const [isPalletized, setIsPalletized] = useState(false)
  const [palletQuantity, setPalletQuantity] = useState<number | null>(null)
  const [incoterms, setIncoterms] = useState("")
  const [observation, setObservation] = useState("")
  const [loadingForecast, setLoadingForecast] = useState("")
  const [manualAddressData, setManualAddressData] = useState({
    pickup_address: "",
    delivery_address: "",
    ncm_products: "",
    net_weight: "",
    cargo_type: "",
  })

  const [file, setFile] = useState<File | null>(null)
  const [extractedData, setExtractedData] = useState<Partial<ExtractedData>>({})
  const [loading, setLoading] = useState(false)
  const [extracting, setExtracting] = useState(false)
  const [fileName, setFileName] = useState("")

  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const { createClient } = await import("@/lib/supabase/client")
        const supabase = createClient()

        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (session?.user?.email) {
          setUserEmail(session.user.email)
          console.log("[v0] User email set from initial session:", session.user.email)
        }

        // Then subscribe to future auth state changes
        const {
          data: { subscription },
        } = supabase.auth.onAuthStateChange(async (event, session) => {
          if (session?.user?.email) {
            setUserEmail(session.user.email)
            console.log("[v0] User email updated from auth change:", session.user.email)
          } else {
            console.log("[v0] No active session found")
            setUserEmail(null)
          }
        })

        // Cleanup subscription on unmount
        return () => {
          subscription?.unsubscribe()
        }
      } catch (error) {
        console.error("[v0] Error initializing auth:", error)
      }
    }

    const cleanup = initializeAuth()
    return () => {
      cleanup?.then((fn) => fn?.())
    }
  }, [])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      setFile(selectedFile)
      setFileName(selectedFile.name)
    }
  }

  const handleExtractData = async () => {
    if (!file) {
      toast.error("Selecione um arquivo primeiro")
      return
    }

    setExtracting(true)
    try {
      const formData = new FormData()
      formData.append("file", file)

      const response = await fetch("/api/collection-requests/extract-data", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) throw new Error("Falha ao extrair dados")

      const { extractedData: data } = await response.json()
      setExtractedData(data)
      toast.success("Dados extraídos com sucesso")
    } catch (error) {
      console.error("[v0] Extraction error:", error)
      toast.error("Erro ao extrair dados do documento")
    } finally {
      setExtracting(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!userEmail) {
      toast.error("Sessão expirada. Por favor, faça login novamente.")
      return
    }

    setLoading(true)
    try {
      let documentUrl = null
      let documentFilename = null

      if (file) {
        const { createClient } = await import("@/lib/supabase/client")
        const supabase = createClient()
        const uploadFileName = `${Date.now()}-${file.name}`

        console.log("[v0] Starting file upload to bucket: collection-documents")

        const { data: uploadData, error: uploadError } = await supabase.storage
          .from("collection-documents")
          .upload(uploadFileName, file)

        if (uploadError) {
          console.log("[v0] Upload error details:", uploadError)
          throw new Error(uploadError.message || "Falha ao fazer upload do arquivo")
        }

        console.log("[v0] File uploaded successfully:", uploadData)

        const {
          data: { publicUrl },
        } = supabase.storage.from("collection-documents").getPublicUrl(uploadFileName)

        console.log("[v0] Public URL generated:", publicUrl)
        documentUrl = publicUrl
        documentFilename = file.name
      }

      // Create collection request
      const submissionData = {
        collectionType,
        isChemical,
        documentUrl,
        documentFilename,
        userEmail,
        extractedData: {
          ...extractedData,
          pickup_address: extractedData.pickup_address || manualAddressData.pickup_address,
          delivery_address: extractedData.delivery_address || manualAddressData.delivery_address,
          ncm_products: extractedData.ncm_products || manualAddressData.ncm_products,
          net_weight:
            extractedData.net_weight || (manualAddressData.net_weight ? Number(manualAddressData.net_weight) : null),
          cargo_type: extractedData.cargo_type || manualAddressData.cargo_type,
          incoterms,
          observation,
          is_palletized: isPalletized,
          pallet_quantity: palletQuantity,
          loading_forecast: loadingForecast ? new Date(loadingForecast).toISOString() : null,
        },
      }

      console.log("[v0] Sending collection request data:", submissionData)

      const response = await fetch("/api/collection-requests/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(submissionData),
      })

      console.log("[v0] API response status:", response.status)

      const responseData = await response.json()
      console.log("[v0] API response data:", responseData)

      if (!response.ok) {
        const errorMessage = responseData.error || "Erro ao criar solicitação"
        throw new Error(errorMessage)
      }

      toast.success("Solicitação de coleta criada com sucesso")
      setFile(null)
      setFileName("")
      setExtractedData({})
      setIncoterms("")
      setObservation("")
      setLoadingForecast("")
      setIsPalletized(false)
      setPalletQuantity(null)
      setManualAddressData({
        pickup_address: "",
        delivery_address: "",
        ncm_products: "",
        net_weight: "",
        cargo_type: "",
      })

      onSuccess?.()
    } catch (error) {
      console.error("[v0] Submit error:", error)
      const errorMessage = error instanceof Error ? error.message : "Erro ao criar solicitação"

      if (errorMessage.includes("Unauthorized") || errorMessage.includes("Session expired")) {
        toast.error("Sessão expirada. Por favor, faça login novamente.")
      } else if (errorMessage.includes("not found") || errorMessage.includes("bucket")) {
        toast.error("Erro: Bucket de armazenamento não configurado. Contate o administrador.")
      } else if (errorMessage.includes("403")) {
        toast.error("Erro: Sem permissão para fazer upload. Contate o administrador.")
      } else if (errorMessage.includes("Client user not found")) {
        toast.error("Erro: Usuário cliente não encontrado. Contate o administrador.")
      } else {
        toast.error(errorMessage)
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Collection Type */}
      <Card className="p-6">
        <div className="space-y-4">
          <div>
            <Label className="text-base font-semibold mb-3 block">Tipo de Coleta</Label>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setCollectionType("exportacao")}
                className={`p-4 rounded-lg border-2 text-center transition ${
                  collectionType === "exportacao" ? "border-primary bg-primary/5" : "border-muted"
                }`}
              >
                <div className="font-semibold">Exportação</div>
                <div className="text-sm text-muted-foreground">Coleta para exportação</div>
              </button>
              <button
                type="button"
                onClick={() => setCollectionType("importacao")}
                className={`p-4 rounded-lg border-2 text-center transition ${
                  collectionType === "importacao" ? "border-primary bg-primary/5" : "border-muted"
                }`}
              >
                <div className="font-semibold">Importação</div>
                <div className="text-sm text-muted-foreground">Coleta para importação</div>
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2 pt-2 border-t">
            <Checkbox
              id="chemical"
              checked={isChemical}
              onCheckedChange={(checked) => setIsChemical(checked as boolean)}
            />
            <Label htmlFor="chemical" className="font-medium cursor-pointer">
              Carga Química
            </Label>
          </div>
        </div>
      </Card>

      {/* Informações da Carga */}
      <Card className="p-6">
        <h3 className="text-base font-semibold mb-4">Informações da Carga</h3>
        <div className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="loadingForecast">Previsão de Carregamento</Label>
              <Input
                id="loadingForecast"
                type="datetime-local"
                value={loadingForecast}
                onChange={(e) => setLoadingForecast(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="incoterms">Incoterms</Label>
              <Input
                id="incoterms"
                placeholder="Ex: FOB, CIF, EXW"
                value={incoterms}
                onChange={(e) => setIncoterms(e.target.value)}
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <AddressInputWithHistory
                id="pickup_address"
                label="Local de Coleta"
                placeholder="Digite um CEP ou endereço"
                value={extractedData.pickup_address || manualAddressData.pickup_address}
                onChange={(value) => {
                  setManualAddressData({ ...manualAddressData, pickup_address: value })
                  setExtractedData({ ...extractedData, pickup_address: value })
                }}
              />
            </div>
            <div className="space-y-2">
              <AddressInputWithHistory
                id="delivery_address"
                label="Local de Entrega"
                placeholder="Digite um CEP ou endereço"
                value={extractedData.delivery_address || manualAddressData.delivery_address}
                onChange={(value) => {
                  setManualAddressData({ ...manualAddressData, delivery_address: value })
                  setExtractedData({ ...extractedData, delivery_address: value })
                }}
              />
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="net_weight">Peso Líquido (kg)</Label>
              <Input
                id="net_weight"
                type="number"
                placeholder="0.00"
                value={extractedData.net_weight || manualAddressData.net_weight}
                onChange={(e) => {
                  setManualAddressData({ ...manualAddressData, net_weight: e.target.value })
                  setExtractedData({ ...extractedData, net_weight: Number(e.target.value) })
                }}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ncm_products">NCM do Produto</Label>
              <Input
                id="ncm_products"
                placeholder="Código NCM"
                value={extractedData.ncm_products || manualAddressData.ncm_products}
                onChange={(e) => {
                  setManualAddressData({ ...manualAddressData, ncm_products: e.target.value })
                  setExtractedData({ ...extractedData, ncm_products: e.target.value })
                }}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cargo_type">Tipo de Carga</Label>
              <select
                id="cargo_type"
                value={extractedData.cargo_type || manualAddressData.cargo_type}
                onChange={(e) => {
                  setManualAddressData({ ...manualAddressData, cargo_type: e.target.value })
                  setExtractedData({ ...extractedData, cargo_type: e.target.value })
                }}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              >
                <option value="">Selecionar...</option>
                <option value="bag">Bag</option>
                <option value="pallet">Pallet</option>
                <option value="caixa">Caixa</option>
                <option value="conteiner">Container</option>
                <option value="isotank">Isotank</option>
                <option value="solto">Solta</option>
              </select>
            </div>
          </div>

          <div className="space-y-4 pt-2">
            <div className="flex items-center gap-2">
              <Checkbox
                id="isPalletized"
                checked={isPalletized}
                onCheckedChange={(checked) => setIsPalletized(checked as boolean)}
              />
              <Label htmlFor="isPalletized" className="font-medium cursor-pointer">
                Carga Paletizada?
              </Label>
            </div>

            {isPalletized && (
              <div className="space-y-2 pl-6 border-l-2 border-muted animate-in fade-in slide-in-from-top-2">
                <Label htmlFor="palletQuantity">Quantidade de Pallets</Label>
                <Input
                  id="palletQuantity"
                  type="number"
                  placeholder="Qtd."
                  value={palletQuantity || ""}
                  onChange={(e) => setPalletQuantity(Number(e.target.value))}
                  className="max-w-[200px]"
                />
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="observation">Observações</Label>
            <Textarea
              id="observation"
              placeholder="Observações adicionais sobre a coleta..."
              value={observation}
              onChange={(e) => setObservation(e.target.value)}
            />
          </div>
        </div>
      </Card>

      {/* Document Upload */}
      <Card className="p-6">
        <div className="space-y-4">
          <div>
            <Label className="text-base font-semibold mb-3 block">Upload do Documento de Carregamento</Label>
            <div className="border-2 border-dashed rounded-lg p-6 text-center hover:bg-muted/50 transition cursor-pointer">
              <input
                type="file"
                onChange={handleFileChange}
                accept=".pdf,.jpg,.jpeg,.png,.txt"
                className="hidden"
                id="file-input"
              />
              <label htmlFor="file-input" className="cursor-pointer block">
                <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                <p className="font-semibold">{fileName || "Clique para fazer upload"}</p>
                <p className="text-sm text-muted-foreground">PDF, JPG, PNG ou TXT</p>
              </label>
            </div>
          </div>

          {file && (
            <Button type="button" onClick={handleExtractData} disabled={extracting} className="w-full gap-2">
              {extracting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Extraindo dados...
                </>
              ) : (
                <>
                  <FileText className="w-4 h-4" />
                  Preencher com IA (Extrair do Documento)
                </>
              )}
            </Button>
          )}
        </div>
      </Card>

      {/* Extracted Data Fields */}
      {Object.values(extractedData).some((v) => v) && (
        <Card className="p-6 bg-blue-50/50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
          <div className="flex items-center gap-2 mb-2">
            <CalendarIcon className="w-5 h-5 text-green-600" />
            <p className="font-semibold text-green-900 dark:text-green-100">Dados preenchidos automaticamente</p>
          </div>
          <p className="text-sm text-muted-foreground">
            Verifique os campos acima para confirmar as informações extraídas.
          </p>
        </Card>
      )}

      {/* Submit Button */}
      <Button type="submit" disabled={loading || !userEmail} className="w-full" size="lg">
        {loading ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin mr-2" />
            Criando solicitação...
          </>
        ) : (
          "Criar Solicitação de Coleta"
        )}
      </Button>
    </form>
  )
}
