"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Download, Plus, Trash2, FileText, GripVertical, Eye, Archive, Lock } from 'lucide-react'
import { jsPDF } from "jspdf"
import { DocumentPreviewModal } from "./document-preview-modal"
import { ArchiveToPortalModal } from "./archive-to-portal-modal"
import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { AdminLogin } from "./admin-login"

interface ProcessedPage {
  id: string
  originalImage: string
  processedImage: string | null
}

interface MultiDocumentManagerProps {
  pages: ProcessedPage[]
  currentPageIndex: number | null
  onSelectPage: (index: number) => void
  onDeletePage: (index: number) => void
  onReorderPages: (fromIndex: number, toIndex: number) => void
  onAddMore: (e: React.ChangeEvent<HTMLInputElement>) => void
  onReset: () => void
}

export function MultiDocumentManager({
  pages,
  currentPageIndex,
  onSelectPage,
  onDeletePage,
  onReorderPages,
  onAddMore,
  onReset,
}: MultiDocumentManagerProps) {
  const [previewModal, setPreviewModal] = useState<{ isOpen: boolean; image: string | null; pageNumber: number }>({
    isOpen: false,
    image: null,
    pageNumber: 0,
  })
  
  const [archiveModal, setArchiveModal] = useState<{ isOpen: boolean; pdfData: string | null }>({
    isOpen: false,
    pdfData: null,
  })

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false)
  const [showAdminLogin, setShowAdminLogin] = useState(false)

  const processedCount = pages.filter((p) => p.processedImage).length

  const handleExportPDF = async () => {
    const processedPages = pages.filter((p) => p.processedImage)

    if (processedPages.length === 0) {
      alert("Processe pelo menos uma página antes de exportar")
      return
    }

    const pdf = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
    })

    for (let i = 0; i < processedPages.length; i++) {
      const page = processedPages[i]

      if (i > 0) {
        pdf.addPage()
      }

      const img = new Image()
      img.src = page.processedImage!

      await new Promise<void>((resolve) => {
        img.onload = () => {
          const imgWidth = img.width
          const imgHeight = img.height
          const ratio = imgWidth / imgHeight

          const pageWidth = 210
          const pageHeight = 297

          let finalWidth = pageWidth
          let finalHeight = pageWidth / ratio

          if (finalHeight > pageHeight) {
            finalHeight = pageHeight
            finalWidth = pageHeight * ratio
          }

          const x = (pageWidth - finalWidth) / 2
          const y = (pageHeight - finalHeight) / 2

          pdf.addImage(page.processedImage!, "JPEG", x, y, finalWidth, finalHeight, undefined, "FAST")
          resolve()
        }
      })
    }

    pdf.save(`documento-${Date.now()}.pdf`)
  }

  const handleArchiveToPortal = async () => {
    const processedPages = pages.filter((p) => p.processedImage)

    if (processedPages.length === 0) {
      alert("Processe pelo menos uma página antes de arquivar")
      return
    }

    // Check if admin is authenticated
    const adminAuth = sessionStorage.getItem('admin_authenticated')
    if (adminAuth !== 'true') {
      setShowAdminLogin(true)
      return
    }

    // Generate PDF
    const pdf = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
    })

    for (let i = 0; i < processedPages.length; i++) {
      const page = processedPages[i]

      if (i > 0) {
        pdf.addPage()
      }

      const img = new Image()
      img.src = page.processedImage!

      await new Promise<void>((resolve) => {
        img.onload = () => {
          const imgWidth = img.width
          const imgHeight = img.height
          const ratio = imgWidth / imgHeight

          const pageWidth = 210
          const pageHeight = 297

          let finalWidth = pageWidth
          let finalHeight = pageWidth / ratio

          if (finalHeight > pageHeight) {
            finalHeight = pageHeight
            finalWidth = pageHeight * ratio
          }

          const x = (pageWidth - finalWidth) / 2
          const y = (pageHeight - finalHeight) / 2

          pdf.addImage(page.processedImage!, "JPEG", x, y, finalWidth, finalHeight, undefined, "FAST")
          resolve()
        }
      })
    }

    const pdfData = pdf.output("dataurlstring")
    setArchiveModal({ isOpen: true, pdfData })
  }

  const handleAdminLoginSuccess = () => {
    setIsAdminAuthenticated(true)
    sessionStorage.setItem('admin_authenticated', 'true')
    setShowAdminLogin(false)
    // Retry archive after successful login
    handleArchiveToPortal()
  }

  const handleDragStart = (e: React.DragEvent, index: number) => {
    e.dataTransfer.effectAllowed = "move"
    e.dataTransfer.setData("text/plain", index.toString())
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = "move"
  }

  const handleDrop = (e: React.DragEvent, toIndex: number) => {
    e.preventDefault()
    const fromIndex = Number.parseInt(e.dataTransfer.getData("text/plain"))
    if (fromIndex !== toIndex) {
      onReorderPages(fromIndex, toIndex)
    }
  }

  const handlePreviewClick = (e: React.MouseEvent, page: ProcessedPage, index: number) => {
    e.stopPropagation()
    if (page.processedImage) {
      setPreviewModal({
        isOpen: true,
        image: page.processedImage,
        pageNumber: index + 1,
      })
    }
  }

  return (
    <>
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xl font-semibold">Documentos ({pages.length})</h3>
            <p className="text-sm text-muted-foreground">
              {processedCount} de {pages.length} processados
            </p>
          </div>
          <div className="flex gap-2">
            <label htmlFor="add-more-upload">
              <Button variant="outline" size="sm" className="cursor-pointer bg-transparent" asChild>
                <span>
                  <Plus className="w-4 h-4 mr-1" />
                  Adicionar
                </span>
              </Button>
            </label>
            <input id="add-more-upload" type="file" accept="image/*" multiple onChange={onAddMore} className="hidden" />
            
            <Button
              variant="outline"
              size="sm"
              onClick={handleArchiveToPortal}
              disabled={processedCount === 0}
              className="gap-1"
            >
              <Archive className="w-4 h-4" />
              Arquivar no Portal
              <Lock className="w-3 h-3 ml-1 opacity-50" />
            </Button>
            
            <Button
              variant="default"
              size="sm"
              onClick={handleExportPDF}
              disabled={processedCount === 0}
              className="min-w-32"
            >
              <Download className="w-4 h-4 mr-1" />
              Exportar PDF
            </Button>
            <Button variant="ghost" size="sm" onClick={onReset}>
              Reiniciar
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {pages.map((page, index) => (
            <div
              key={page.id}
              draggable
              onDragStart={(e) => handleDragStart(e, index)}
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, index)}
              onClick={() => onSelectPage(index)}
              className={`relative group cursor-pointer rounded-lg border-2 overflow-hidden transition-all ${
                currentPageIndex === index
                  ? "border-primary ring-2 ring-primary/20"
                  : "border-border hover:border-primary/50"
              }`}
            >
              <div className="aspect-[3/4] relative bg-muted">
                {page.processedImage ? (
                  <img
                    src={page.processedImage || "/placeholder.svg"}
                    alt={`Página ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <img
                    src={page.originalImage || "/placeholder.svg"}
                    alt={`Página ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                )}

                {page.processedImage && (
                  <div className="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-1 rounded">✓</div>
                )}

                {page.processedImage && (
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={(e) => handlePreviewClick(e, page, index)}
                      className="bg-white/90 hover:bg-white"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      Visualizar
                    </Button>
                  </div>
                )}

                {!page.processedImage && (
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <GripVertical className="w-5 h-5 text-white" />
                  </div>
                )}
              </div>

              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-2">
                <div className="flex items-center justify-between">
                  <span className="text-white text-xs font-medium">Pág. {index + 1}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      onDeletePage(index)
                    }}
                    className="text-white hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {pages.length > 0 && processedCount < pages.length && (
          <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-lg">
            <p className="text-sm text-amber-800 dark:text-amber-200">
              <FileText className="w-4 h-4 inline mr-1" />
              Você tem {pages.length - processedCount} página(s) não processada(s). Processe todas antes de exportar
              para PDF.
            </p>
          </div>
        )}
      </Card>

      <DocumentPreviewModal
        isOpen={previewModal.isOpen}
        onClose={() => setPreviewModal({ isOpen: false, image: null, pageNumber: 0 })}
        image={previewModal.image}
        pageNumber={previewModal.pageNumber}
      />
      
      <ArchiveToPortalModal
        isOpen={archiveModal.isOpen}
        onClose={() => setArchiveModal({ isOpen: false, pdfData: null })}
        pdfData={archiveModal.pdfData}
      />

      <Dialog open={showAdminLogin} onOpenChange={setShowAdminLogin}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-primary" />
              Autenticação Necessária
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Para arquivar documentos no portal do cliente, é necessário fazer login como administrador.
            </p>
            <AdminLogin onLoginSuccess={handleAdminLoginSuccess} />
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
