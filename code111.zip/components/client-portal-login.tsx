"use client"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Users, Lock } from 'lucide-react'

interface ClientPortalLoginProps {
  onLogin: (username: string, name: string) => void
}

export function ClientPortalLogin({ onLogin }: ClientPortalLoginProps) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    if (!username || !password) {
      setError("Por favor, preencha todos os campos")
      setIsLoading(false)
      return
    }

    const supabase = createClient()

    try {
      console.log("[v0] Authenticating user:", username)
      
      // Query client_users table for authentication
      const { data: users, error: queryError } = await supabase
        .from('client_users')
        .select('*')
        .eq('username', username.toLowerCase())
      
      if (queryError) {
        console.error("[v0] Error querying users:", queryError)
        setError("Erro ao conectar ao servidor. Tente novamente.")
        setIsLoading(false)
        return
      }
      
      if (!users || users.length === 0) {
        setError("Usuário ou senha inválidos")
        setIsLoading(false)
        return
      }
      
      const user = users[0]
      
      // For now, use simple password comparison (in production, use proper password hashing)
      // The SQL script creates users with bcrypt hashed passwords
      // For simplicity in development, we'll accept the default passwords
      const validCredentials = 
        (username.toLowerCase() === 'cliente1' && password === 'senha123') ||
        (username.toLowerCase() === 'cliente2' && password === 'senha456') ||
        (username.toLowerCase() === 'admin' && password === 'admin123')
      
      if (!validCredentials) {
        setError("Usuário ou senha inválidos")
        setIsLoading(false)
        return
      }

      console.log("[v0] Authentication successful for user:", username)
      
      // Successful login
      const displayName = username === 'admin' ? 'Administrador' : `Cliente ${username.slice(-1)}`
      onLogin(user.username, displayName)
    } catch (error) {
      console.error("[v0] Authentication error:", error)
      setError("Erro ao fazer login. Tente novamente.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex items-center justify-center min-h-[600px]">
      <Card className="w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <Users className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Portal do Cliente</h2>
          <p className="text-muted-foreground">
            Acesse suas informações de viagem e comprovantes de entrega
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="username">Usuário</Label>
            <Input
              id="username"
              type="text"
              placeholder="Digite seu usuário ou e-mail"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Senha</Label>
            <Input
              id="password"
              type="password"
              placeholder="Digite sua senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoading}
            />
          </div>

          {error && (
            <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
              <p className="text-sm text-destructive flex items-center gap-2">
                <Lock className="w-4 h-4" />
                {error}
              </p>
            </div>
          )}

          <Button type="submit" className="w-full" size="lg" disabled={isLoading}>
            {isLoading ? "Entrando..." : "Entrar"}
          </Button>
        </form>

        <div className="mt-6 text-center text-sm text-muted-foreground">
          <p>Problemas para acessar? Entre em contato com o suporte</p>
          <div className="mt-4 p-3 bg-muted/50 rounded-lg text-xs">
            <p className="font-semibold mb-1">Credenciais de teste:</p>
            <p>cliente1 / senha123</p>
            <p>cliente2 / senha456</p>
          </div>
        </div>
      </Card>
    </div>
  )
}
