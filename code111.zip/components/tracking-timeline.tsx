"use client"

import { Card } from "@/components/ui/card"
import { Package, TruckIcon, Building2, MapPin, CheckCircle2, AlertTriangle } from 'lucide-react'
import { TrackingShare } from "./tracking-share"

interface TrackingMilestone {
  status: string
  details: string
  timestamp: string
}

interface TrackingTimelineProps {
  trackingStatus?: string
  trackingDetails?: TrackingMilestone[]
  crt?: string
  origin?: string
  destination?: string
  clientReference?: string
}

const statusConfig = {
  preparacao: {
    label: "Preparação",
    icon: Package,
    order: 0
  },
  transito: {
    label: "Trânsito",
    icon: TruckIcon,
    order: 1
  },
  aduana_origem: {
    label: "Aduana Origem",
    icon: Building2,
    order: 2
  },
  canal_vermelho: {
    label: "Canal Vermelho",
    icon: AlertTriangle,
    order: 2.5
  },
  aduana_destino: {
    label: "Aduana Destino",
    icon: Building2,
    order: 3
  },
  entrega: {
    label: "Em transito para Entrega",
    icon: MapPin,
    order: 4
  },
  entregue: {
    label: "Entregue",
    icon: CheckCircle2,
    order: 5
  }
}

export function TrackingTimeline({ 
  trackingStatus, 
  trackingDetails = [],
  crt = "",
  origin = "",
  destination = "",
  clientReference
}: TrackingTimelineProps) {
  if (!trackingStatus) {
    return (
      <Card className="p-6">
        <p className="text-center text-muted-foreground">
          Informações de rastreamento não disponíveis para esta viagem
        </p>
      </Card>
    )
  }

  const hasCanalVermelho = trackingDetails.some(
    detail => detail.status.toLowerCase().includes('canal vermelho') || 
              detail.status === 'canal_vermelho'
  )

  let milestones = ['preparacao', 'transito', 'aduana_origem']
  if (hasCanalVermelho) {
    milestones.push('canal_vermelho')
  }
  milestones.push('aduana_destino', 'entrega', 'entregue')

  const currentIndex = milestones.indexOf(trackingStatus)
  const sortedDetails = [...trackingDetails].sort((a, b) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  )

  const getMilestoneDate = (milestone: string) => {
    const detail = trackingDetails.find(d => 
      d.status === milestone || 
      d.status.toLowerCase().replace(/\s+/g, '_') === milestone
    )
    return detail ? new Date(detail.timestamp).toLocaleDateString('pt-BR', { 
      day: '2-digit', 
      month: '2-digit' 
    }) : null
  }

  return (
    <Card className="p-6">
      <div className="space-y-6">
        {crt && origin && destination && (
          <div className="pb-4 border-b">
            <h4 className="font-semibold text-sm mb-3">Compartilhar Rastreamento</h4>
            <TrackingShare 
              crt={crt}
              origin={origin}
              destination={destination}
              trackingStatus={trackingStatus}
              clientReference={clientReference}
            />
          </div>
        )}

        {/* Timeline visual */}
        <div className="relative">
          <div className="flex items-center justify-between">
            {milestones.map((milestone, index) => {
              const config = statusConfig[milestone as keyof typeof statusConfig]
              const Icon = config.icon
              const isCompleted = index <= currentIndex
              const isCurrent = index === currentIndex
              const isRed = milestone === 'canal_vermelho'
              const milestoneDate = getMilestoneDate(milestone)

              return (
                <div key={milestone} className="flex flex-col items-center flex-1 relative">
                  {/* Line connecting to previous milestone */}
                  {index > 0 && (
                    <div className={`absolute top-6 right-1/2 w-full h-1 -z-10 ${
                      isCompleted ? 'bg-green-500' : 'bg-gray-200 dark:bg-gray-800'
                    }`} />
                  )}
                  
                  {/* Icon */}
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                    isCompleted 
                      ? isRed 
                        ? 'bg-red-100 dark:bg-red-950/20' 
                        : 'bg-green-100 dark:bg-green-950/20'
                      : 'bg-gray-100 dark:bg-gray-800'
                  } ${isCurrent ? 'ring-4 ring-green-500/20' : ''}`}>
                    <Icon className={`w-6 h-6 ${
                      isCompleted 
                        ? isRed 
                          ? 'text-red-600 dark:text-red-400' 
                          : 'text-green-600 dark:text-green-400'
                        : 'text-gray-400 dark:text-gray-600'
                    }`} />
                  </div>
                  
                  {/* Label */}
                  <p className={`text-xs mt-2 text-center font-medium ${
                    isCompleted ? 'text-foreground' : 'text-muted-foreground'
                  }`}>
                    {config.label}
                  </p>
                  
                  {milestoneDate && (
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      {milestoneDate}
                    </p>
                  )}
                </div>
              )
            })}
          </div>
        </div>

        {/* Status details */}
        {sortedDetails.length > 0 && (
          <div className="space-y-3 pt-6 border-t">
            <h4 className="font-semibold text-sm">Histórico de Atualizações</h4>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {sortedDetails.map((detail, index) => {
                const isRed = detail.status.toLowerCase().includes('canal vermelho') || detail.status === 'canal_vermelho'
                
                return (
                  <div key={index} className="flex gap-3 p-3 bg-muted/30 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className={`font-medium text-sm ${
                          isRed ? 'text-red-600 dark:text-red-400' : 'text-orange-600 dark:text-orange-400'
                        }`}>
                          {detail.status}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {new Date(detail.timestamp).toLocaleString('pt-BR')}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {detail.details}
                      </p>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}
      </div>
    </Card>
  )
}
