"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Loader2, RotateCcw, RotateCw } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

interface Point {
  x: number
  y: number
}

interface DocumentScannerProps {
  imageUrl: string
  onProcessComplete: (processedImage: string) => void
  isProcessing: boolean
  setIsProcessing: (processing: boolean) => void
}

const PAPER_SIZES = {
  auto: { name: "Auto Detectar", ratio: null },
  a4: { name: "A4 (21 × 29.7 cm)", ratio: 21 / 29.7 },
  letter: { name: "Carta (21.6 × 27.9 cm)", ratio: 21.6 / 27.9 },
  legal: { name: "Ofício (21.6 × 35.6 cm)", ratio: 21.6 / 35.6 },
  a5: { name: "A5 (14.8 × 21 cm)", ratio: 14.8 / 21 },
}

type FilterMode = "original" | "bw" | "grayscale" | "enhance" | "lighten" | "magic" | "textsharp"

export function DocumentScanner({ imageUrl, onProcessComplete, isProcessing, setIsProcessing }: DocumentScannerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [corners, setCorners] = useState<Point[]>([])
  const [draggedCorner, setDraggedCorner] = useState<number | null>(null)
  const [imageLoaded, setImageLoaded] = useState(false)
  const imageRef = useRef<HTMLImageElement | null>(null)
  const [paperSize, setPaperSize] = useState<keyof typeof PAPER_SIZES>("auto")
  const [filterMode, setFilterMode] = useState<FilterMode>("magic")
  const [rotation, setRotation] = useState<number>(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const img = new Image()
    img.crossOrigin = "anonymous"
    img.onload = () => {
      imageRef.current = img
      const ctx = canvas.getContext("2d")
      if (!ctx) return

      const maxWidth = 800
      const isRotated = rotation % 180 !== 0
      const imgWidth = isRotated ? img.height : img.width
      const imgHeight = isRotated ? img.width : img.height

      const scale = maxWidth / imgWidth
      canvas.width = imgWidth * scale
      canvas.height = imgHeight * scale

      ctx.save()
      ctx.translate(canvas.width / 2, canvas.height / 2)
      ctx.rotate((rotation * Math.PI) / 180)
      ctx.drawImage(img, (-img.width * scale) / 2, (-img.height * scale) / 2, img.width * scale, img.height * scale)
      ctx.restore()

      const detectedCorners = calculateCorners(canvas.width, canvas.height, paperSize)

      setCorners(detectedCorners)
      setImageLoaded(true)
      drawOverlay(ctx, img, canvas, detectedCorners)
    }
    img.src = imageUrl
  }, [imageUrl, paperSize, rotation])

  const calculateCorners = (width: number, height: number, size: keyof typeof PAPER_SIZES): Point[] => {
    const margin = 0.1

    if (size === "auto") {
      return [
        { x: width * margin, y: height * margin },
        { x: width * (1 - margin), y: height * margin },
        { x: width * (1 - margin), y: height * (1 - margin) },
        { x: width * margin, y: height * (1 - margin) },
      ]
    }

    const ratio = PAPER_SIZES[size].ratio
    if (!ratio) return []

    let docWidth = width * (1 - 2 * margin)
    let docHeight = docWidth / ratio

    if (docHeight > height * (1 - 2 * margin)) {
      docHeight = height * (1 - 2 * margin)
      docWidth = docHeight * ratio
    }

    const offsetX = (width - docWidth) / 2
    const offsetY = (height - docHeight) / 2

    return [
      { x: offsetX, y: offsetY },
      { x: offsetX + docWidth, y: offsetY },
      { x: offsetX + docWidth, y: offsetY + docHeight },
      { x: offsetX, y: offsetY + docHeight },
    ]
  }

  useEffect(() => {
    if (imageLoaded && corners.length === 4) {
      const canvas = canvasRef.current
      const ctx = canvas?.getContext("2d")
      if (ctx && canvas && imageRef.current) {
        drawOverlay(ctx, imageRef.current, canvas, corners)
      }
    }
  }, [corners, imageLoaded])

  const drawOverlay = (
    ctx: CanvasRenderingContext2D,
    img: HTMLImageElement,
    canvas: HTMLCanvasElement,
    points: Point[],
  ) => {
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    const maxWidth = 800
    const isRotated = rotation % 180 !== 0
    const imgWidth = isRotated ? img.height : img.width
    const imgHeight = isRotated ? img.width : img.height
    const scale = maxWidth / imgWidth

    ctx.save()
    ctx.translate(canvas.width / 2, canvas.height / 2)
    ctx.rotate((rotation * Math.PI) / 180)
    ctx.drawImage(img, (-img.width * scale) / 2, (-img.height * scale) / 2, img.width * scale, img.height * scale)
    ctx.restore()

    if (points.length < 4) return

    ctx.fillStyle = "rgba(0, 0, 0, 0.4)"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    ctx.save()
    ctx.globalCompositeOperation = "destination-out"
    ctx.beginPath()
    ctx.moveTo(points[0].x, points[0].y)
    for (let i = 1; i < points.length; i++) {
      ctx.lineTo(points[i].x, points[i].y)
    }
    ctx.closePath()
    ctx.fill()
    ctx.restore()

    ctx.strokeStyle = "#3b82f6"
    ctx.lineWidth = 3
    ctx.setLineDash([10, 5])
    ctx.beginPath()
    ctx.moveTo(points[0].x, points[0].y)
    for (let i = 1; i < points.length; i++) {
      ctx.lineTo(points[i].x, points[i].y)
    }
    ctx.closePath()
    ctx.stroke()
    ctx.setLineDash([])

    points.forEach((point) => {
      ctx.fillStyle = "#3b82f6"
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.arc(point.x, point.y, 10, 0, Math.PI * 2)
      ctx.fill()
      ctx.stroke()
    })
  }

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = (e.clientX - rect.left) * (canvas.width / rect.width)
    const y = (e.clientY - rect.top) * (canvas.height / rect.height)

    const cornerIndex = corners.findIndex((corner) => Math.hypot(corner.x - x, corner.y - y) < 20)

    if (cornerIndex !== -1) {
      setDraggedCorner(cornerIndex)
    }
  }

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (draggedCorner === null) return

    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = Math.max(0, Math.min(canvas.width, (e.clientX - rect.left) * (canvas.width / rect.width)))
    const y = Math.max(0, Math.min(canvas.height, (e.clientY - rect.top) * (canvas.height / rect.height)))

    const newCorners = [...corners]
    newCorners[draggedCorner] = { x, y }
    setCorners(newCorners)
  }

  const handleMouseUp = () => {
    setDraggedCorner(null)
  }

  const handleRotateLeft = () => {
    setRotation((prev) => (prev - 90 + 360) % 360)
  }

  const handleRotateRight = () => {
    setRotation((prev) => (prev + 90) % 360)
  }

  const applyScanFilter = (ctx: CanvasRenderingContext2D, width: number, height: number, mode: FilterMode) => {
    console.log("[v0] Applying scan filter:", mode)
    const imageData = ctx.getImageData(0, 0, width, height)
    const data = imageData.data

    if (mode === "original") {
      // No filter, keep original
      return
    } else if (mode === "bw") {
      // High contrast black and white with adaptive threshold
      const threshold = 140
      for (let i = 0; i < data.length; i += 4) {
        const luminance = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]
        const value = luminance > threshold ? 255 : 0
        data[i] = data[i + 1] = data[i + 2] = value
      }
    } else if (mode === "grayscale") {
      // Clean grayscale with slight contrast enhancement
      const contrast = 1.2
      for (let i = 0; i < data.length; i += 4) {
        const luminance = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]
        const enhanced = Math.min(255, Math.max(0, (luminance - 128) * contrast + 128))
        data[i] = data[i + 1] = data[i + 2] = enhanced
      }
    } else if (mode === "enhance") {
      // Strong enhancement for text clarity
      const contrast = 1.5
      const brightness = 25
      const saturation = 0.8

      for (let i = 0; i < data.length; i += 4) {
        // Apply contrast and brightness
        let r = (data[i] - 128) * contrast + 128 + brightness
        let g = (data[i + 1] - 128) * contrast + 128 + brightness
        let b = (data[i + 2] - 128) * contrast + 128 + brightness

        // Reduce saturation slightly for cleaner look
        const gray = 0.299 * r + 0.587 * g + 0.114 * b
        r = gray + (r - gray) * saturation
        g = gray + (g - gray) * saturation
        b = gray + (b - gray) * saturation

        data[i] = Math.min(255, Math.max(0, r))
        data[i + 1] = Math.min(255, Math.max(0, g))
        data[i + 2] = Math.min(255, Math.max(0, b))
      }
    } else if (mode === "lighten") {
      // Lighten and increase clarity
      const brightness = 40
      const contrast = 1.3

      for (let i = 0; i < data.length; i += 4) {
        data[i] = Math.min(255, Math.max(0, (data[i] - 128) * contrast + 128 + brightness))
        data[i + 1] = Math.min(255, Math.max(0, (data[i + 1] - 128) * contrast + 128 + brightness))
        data[i + 2] = Math.min(255, Math.max(0, (data[i + 2] - 128) * contrast + 128 + brightness))
      }
    } else if (mode === "magic") {
      // Magic Color: Auto-enhance with intelligent adjustments
      const contrast = 1.6
      const brightness = 30
      const sharpness = 1.2

      // First pass: contrast and brightness
      for (let i = 0; i < data.length; i += 4) {
        const r = (data[i] - 128) * contrast + 128 + brightness
        const g = (data[i + 1] - 128) * contrast + 128 + brightness
        const b = (data[i + 2] - 128) * contrast + 128 + brightness

        data[i] = Math.min(255, Math.max(0, r))
        data[i + 1] = Math.min(255, Math.max(0, g))
        data[i + 2] = Math.min(255, Math.max(0, b))
      }

      // Second pass: sharpening (simple edge enhancement)
      const tempData = new Uint8ClampedArray(data)
      for (let y = 1; y < height - 1; y++) {
        for (let x = 1; x < width - 1; x++) {
          const idx = (y * width + x) * 4

          for (let c = 0; c < 3; c++) {
            const center = tempData[idx + c]
            const avg =
              (tempData[idx + c - 4] +
                tempData[idx + c + 4] +
                tempData[idx + c - width * 4] +
                tempData[idx + c + width * 4]) /
              4
            const sharpened = center + (center - avg) * (sharpness - 1)
            data[idx + c] = Math.min(255, Math.max(0, sharpened))
          }
        }
      }
    } else if (mode === "textsharp") {
      // Extreme contrast and adaptive thresholding for maximum text clarity
      const tempData = new Uint8ClampedArray(data)

      // First pass: Convert to grayscale with weighted luminance
      for (let i = 0; i < data.length; i += 4) {
        const luminance = 0.299 * tempData[i] + 0.587 * tempData[i + 1] + 0.114 * tempData[i + 2]
        data[i] = data[i + 1] = data[i + 2] = luminance
      }

      // Second pass: Apply extreme contrast to separate text from background
      const contrast = 2.5
      const brightness = 40
      for (let i = 0; i < data.length; i += 4) {
        const gray = data[i]
        let enhanced = (gray - 128) * contrast + 128 + brightness
        enhanced = Math.min(255, Math.max(0, enhanced))
        data[i] = data[i + 1] = data[i + 2] = enhanced
      }

      // Third pass: Adaptive thresholding to make dark pixels darker and light pixels lighter
      const tempData2 = new Uint8ClampedArray(data)
      const windowSize = 15
      const halfWindow = Math.floor(windowSize / 2)

      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
          const idx = (y * width + x) * 4

          // Calculate local average
          let sum = 0
          let count = 0
          for (let dy = -halfWindow; dy <= halfWindow; dy++) {
            for (let dx = -halfWindow; dx <= halfWindow; dx++) {
              const ny = y + dy
              const nx = x + dx
              if (ny >= 0 && ny < height && nx >= 0 && nx < width) {
                const nidx = (ny * width + nx) * 4
                sum += tempData2[nidx]
                count++
              }
            }
          }
          const localAvg = sum / count

          // Apply adaptive threshold with bias towards darker text
          const currentValue = tempData2[idx]
          const threshold = localAvg - 15 // Bias towards making text darker

          if (currentValue < threshold) {
            // Dark pixel (text) - make it darker
            const newValue = Math.max(0, currentValue * 0.3)
            data[idx] = data[idx + 1] = data[idx + 2] = newValue
          } else {
            // Light pixel (background) - make it lighter
            const newValue = Math.min(255, currentValue * 1.15 + 30)
            data[idx] = data[idx + 1] = data[idx + 2] = newValue
          }
        }
      }

      // Fourth pass: Sharpening for crisp edges
      const tempData3 = new Uint8ClampedArray(data)
      const sharpness = 1.5
      for (let y = 1; y < height - 1; y++) {
        for (let x = 1; x < width - 1; x++) {
          const idx = (y * width + x) * 4

          const center = tempData3[idx]
          const avg =
            (tempData3[idx - 4] + tempData3[idx + 4] + tempData3[idx - width * 4] + tempData3[idx + width * 4]) / 4

          const sharpened = center + (center - avg) * sharpness
          const value = Math.min(255, Math.max(0, sharpened))
          data[idx] = data[idx + 1] = data[idx + 2] = value
        }
      }
    }

    ctx.putImageData(imageData, 0, 0)
    console.log("[v0] Filter applied successfully")
  }

  const handleProcess = async () => {
    console.log("[v0] Starting document processing")
    if (!imageRef.current || corners.length !== 4) {
      console.log("[v0] Cannot process: missing image or corners")
      return
    }

    setIsProcessing(true)

    setTimeout(async () => {
      try {
        console.log("[v0] Creating output canvas")
        const outputCanvas = document.createElement("canvas")
        const ctx = outputCanvas.getContext("2d", { willReadFrequently: true })
        if (!ctx) {
          console.log("[v0] Failed to get canvas context")
          return
        }

        const canvas = canvasRef.current
        if (!canvas) return

        const tempCanvas = document.createElement("canvas")
        const isRotated = rotation % 180 !== 0
        const imgWidth = isRotated ? imageRef.current!.height : imageRef.current!.width
        const imgHeight = isRotated ? imageRef.current!.width : imageRef.current!.height

        tempCanvas.width = imgWidth
        tempCanvas.height = imgHeight
        const tempCtx = tempCanvas.getContext("2d", { willReadFrequently: true })
        if (!tempCtx) return

        // Draw the rotated image on temp canvas
        tempCtx.save()
        tempCtx.translate(tempCanvas.width / 2, tempCanvas.height / 2)
        tempCtx.rotate((rotation * Math.PI) / 180)
        tempCtx.drawImage(imageRef.current!, -imageRef.current!.width / 2, -imageRef.current!.height / 2)
        tempCtx.restore()

        const scaleX = tempCanvas.width / canvas.width
        const scaleY = tempCanvas.height / canvas.height

        const scaledCorners = corners.map((corner) => ({
          x: corner.x * scaleX,
          y: corner.y * scaleY,
        }))

        console.log("[v0] Calculating output dimensions")
        const width = Math.round(
          Math.max(
            Math.hypot(scaledCorners[1].x - scaledCorners[0].x, scaledCorners[1].y - scaledCorners[0].y),
            Math.hypot(scaledCorners[2].x - scaledCorners[3].x, scaledCorners[2].y - scaledCorners[3].y),
          ),
        )

        const height = Math.round(
          Math.max(
            Math.hypot(scaledCorners[3].x - scaledCorners[0].x, scaledCorners[3].y - scaledCorners[0].y),
            Math.hypot(scaledCorners[2].x - scaledCorners[1].x, scaledCorners[2].y - scaledCorners[1].y),
          ),
        )

        console.log("[v0] Output dimensions:", width, "x", height)
        outputCanvas.width = width
        outputCanvas.height = height

        console.log("[v0] Preparing source image data")
        const sourceImageData = tempCtx.getImageData(0, 0, tempCanvas.width, tempCanvas.height)
        const sourceData = sourceImageData.data

        console.log("[v0] Applying perspective transformation")
        const orderedCorners = [scaledCorners[0], scaledCorners[1], scaledCorners[2], scaledCorners[3]]

        const outputImageData = ctx.createImageData(width, height)
        const outputData = outputImageData.data

        for (let y = 0; y < height; y++) {
          const v = y / height

          for (let x = 0; x < width; x++) {
            const u = x / width

            const srcX = Math.round(
              (1 - v) * ((1 - u) * orderedCorners[0].x + u * orderedCorners[1].x) +
                v * ((1 - u) * orderedCorners[3].x + u * orderedCorners[2].x),
            )

            const srcY = Math.round(
              (1 - v) * ((1 - u) * orderedCorners[0].y + u * orderedCorners[1].y) +
                v * ((1 - u) * orderedCorners[3].y + u * orderedCorners[2].y),
            )

            if (srcX >= 0 && srcX < tempCanvas.width && srcY >= 0 && srcY < tempCanvas.height) {
              const srcIndex = (srcY * tempCanvas.width + srcX) * 4
              const dstIndex = (y * width + x) * 4

              outputData[dstIndex] = sourceData[srcIndex]
              outputData[dstIndex + 1] = sourceData[srcIndex + 1]
              outputData[dstIndex + 2] = sourceData[srcIndex + 2]
              outputData[dstIndex + 3] = 255
            }
          }
        }

        console.log("[v0] Transformation complete, putting image data")
        ctx.putImageData(outputImageData, 0, 0)

        console.log("[v0] Applying scan filter")
        applyScanFilter(ctx, width, height, filterMode)

        console.log("[v0] Generating final image")
        const processedDataUrl = outputCanvas.toDataURL("image/jpeg", 0.92)

        console.log("[v0] Processing complete")
        onProcessComplete(processedDataUrl)
        setIsProcessing(false)
      } catch (error) {
        console.error("[v0] Error processing document:", error)
        setIsProcessing(false)
      }
    }, 100)
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">Dimensão do Documento</label>
        <Select value={paperSize} onValueChange={(value) => setPaperSize(value as keyof typeof PAPER_SIZES)}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Selecione o tamanho" />
          </SelectTrigger>
          <SelectContent>
            {Object.entries(PAPER_SIZES).map(([key, { name }]) => (
              <SelectItem key={key} value={key}>
                {name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">Filtro de Digitalização</label>
        <RadioGroup value={filterMode} onValueChange={(value) => setFilterMode(value as FilterMode)}>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="textsharp" id="textsharp" />
            <Label htmlFor="textsharp" className="font-normal cursor-pointer">
              Texto Nítido - Letras ultra legíveis
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="magic" id="magic" />
            <Label htmlFor="magic" className="font-normal cursor-pointer">
              Mágico - Auto-melhoramento
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="bw" id="bw" />
            <Label htmlFor="bw" className="font-normal cursor-pointer">
              Preto e Branco - Máxima clareza
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="enhance" id="enhance" />
            <Label htmlFor="enhance" className="font-normal cursor-pointer">
              Melhorado - Alto contraste
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="lighten" id="lighten" />
            <Label htmlFor="lighten" className="font-normal cursor-pointer">
              Clarear - Iluminar documento
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="grayscale" id="grayscale" />
            <Label htmlFor="grayscale" className="font-normal cursor-pointer">
              Tons de Cinza - Clássico
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="original" id="original" />
            <Label htmlFor="original" className="font-normal cursor-pointer">
              Original - Sem filtro
            </Label>
          </div>
        </RadioGroup>
      </div>

      <div className="relative border-2 border-border rounded-lg overflow-hidden bg-muted">
        <canvas
          ref={canvasRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          className="w-full h-auto cursor-crosshair"
        />
        <div className="absolute top-3 right-3 flex gap-2">
          <Button
            onClick={handleRotateLeft}
            size="icon"
            variant="secondary"
            className="h-10 w-10 rounded-full shadow-lg"
            title="Girar para esquerda"
          >
            <RotateCcw className="h-5 w-5" />
          </Button>
          <Button
            onClick={handleRotateRight}
            size="icon"
            variant="secondary"
            className="h-10 w-10 rounded-full shadow-lg"
            title="Girar para direita"
          >
            <RotateCw className="h-5 w-5" />
          </Button>
        </div>
      </div>
      <div className="flex gap-3">
        <Button onClick={handleProcess} disabled={!imageLoaded || isProcessing} className="flex-1" size="lg">
          {isProcessing ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Processando...
            </>
          ) : (
            "Processar Documento"
          )}
        </Button>
      </div>
      <p className="text-xs text-muted-foreground text-center">
        Arraste os pontos azuis para ajustar as bordas do documento
      </p>
    </div>
  )
}
