"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Menu, Phone, Mail } from 'lucide-react'
import { useState } from "react"
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet"

export function SiteHeader() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white shadow-sm">
      <div className="bg-[#005f8f] text-white py-2 text-xs hidden md:block">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex gap-6">
            <span className="flex items-center gap-2"><Phone className="h-3 w-3" /> +55 (47) 3343 7864</span>
            <span className="flex items-center gap-2"><Mail className="h-3 w-3" /> contato@inlog.biz</span>
          </div>
          <div className="flex gap-4">
            <Link href="/portal" className="hover:text-gray-200 transition-colors">Área do Cliente</Link>
            <Link href="/dashboard" className="hover:text-gray-200 transition-colors">Sistema Interno</Link>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="relative h-12 w-40">
            <Image 
              src="/images/inlog-logo.png" 
              alt="INLOG Logo" 
              fill
              className="object-contain"
              priority
            />
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8 font-medium text-sm text-gray-700">
          <Link href="/" className="hover:text-[#005f8f] transition-colors">Home</Link>
          <Link href="/quem-somos" className="hover:text-[#005f8f] transition-colors">Quem Somos</Link>
          <Link href="/servicos" className="hover:text-[#005f8f] transition-colors">Serviços</Link>
          <Link href="/contato" className="hover:text-[#005f8f] transition-colors">Contato</Link>
          <Link href="/cotacao">
            <Button className="bg-[#005f8f] hover:bg-[#004b73] text-white">
              Solicitar Cotação
            </Button>
          </Link>
        </nav>

        {/* Mobile Navigation */}
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent>
            <div className="flex flex-col gap-6 mt-8">
              <Link href="/" className="text-lg font-medium hover:text-[#005f8f]" onClick={() => setIsOpen(false)}>Home</Link>
              <Link href="/quem-somos" className="text-lg font-medium hover:text-[#005f8f]" onClick={() => setIsOpen(false)}>Quem Somos</Link>
              <Link href="/servicos" className="text-lg font-medium hover:text-[#005f8f]" onClick={() => setIsOpen(false)}>Serviços</Link>
              <Link href="/contato" className="text-lg font-medium hover:text-[#005f8f]" onClick={() => setIsOpen(false)}>Contato</Link>
              <Link href="/cotacao" className="text-lg font-medium hover:text-[#005f8f]" onClick={() => setIsOpen(false)}>Cotação</Link>
              <hr />
              <Link href="/portal" className="text-lg font-medium text-gray-600" onClick={() => setIsOpen(false)}>Portal do Cliente</Link>
              <Link href="/dashboard" className="text-lg font-medium text-gray-600" onClick={() => setIsOpen(false)}>Sistema Interno</Link>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  )
}
