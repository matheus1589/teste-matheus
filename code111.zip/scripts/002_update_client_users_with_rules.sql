-- Add columns to client_users for access rules
ALTER TABLE public.client_users 
ADD COLUMN IF NOT EXISTS full_name TEXT,
ADD COLUMN IF NOT EXISTS email TEXT,
ADD COLUMN IF NOT EXISTS importador TEXT,
ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- Update existing users with proper names
UPDATE public.client_users 
SET full_name = 'Cliente Um',
    email = 'cliente1@example.com'
WHERE username = 'cliente1';

UPDATE public.client_users 
SET full_name = 'Cliente Dois',
    email = 'cliente2@example.com'
WHERE username = 'cliente2';

-- Add trigger for updated_at
CREATE TRIGGER update_client_users_updated_at
  BEFORE UPDATE ON public.client_users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
