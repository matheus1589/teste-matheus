-- Create client users table for portal access
create table if not exists public.client_users (
  id uuid primary key default gen_random_uuid(),
  username text unique not null,
  password_hash text not null,
  exportador text,
  created_at timestamptz default now()
);

-- Create trips table
create table if not exists public.trips (
  id uuid primary key default gen_random_uuid(),
  crt text not null,
  client_username text not null,
  exportador text,
  importador text,
  driver_name text,
  driver_cpf text,
  placa_cavalo text,
  placa_carreta text,
  origem text,
  destino text,
  start_date text,
  end_date text,
  fatura text,
  client_reference text,
  proof_of_delivery_url text,
  status text default 'pending',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Create index for faster queries
create index if not exists idx_trips_client_username on public.trips(client_username);
create index if not exists idx_trips_exportador on public.trips(exportador);
create index if not exists idx_trips_crt on public.trips(crt);

-- Enable Row Level Security
alter table public.client_users enable row level security;
alter table public.trips enable row level security;

-- RLS policies for client_users (only for admin operations)
create policy "Allow public read of client_users for authentication"
  on public.client_users for select
  using (true);

-- RLS policies for trips
create policy "Anyone can read trips"
  on public.trips for select
  using (true);

create policy "Anyone can insert trips"
  on public.trips for insert
  with check (true);

create policy "Anyone can update trips"
  on public.trips for update
  using (true);

create policy "Anyone can delete trips"
  on public.trips for delete
  using (true);

-- Insert default client users
insert into public.client_users (username, password_hash, exportador) values
  ('cliente1', crypt('senha123', gen_salt('bf')), null),
  ('cliente2', crypt('senha456', gen_salt('bf')), 'PEROXIDOS')
on conflict (username) do nothing;
