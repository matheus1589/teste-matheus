-- Add tracking fields to trips table
ALTER TABLE trips ADD COLUMN IF NOT EXISTS tracking_status TEXT;
ALTER TABLE trips ADD COLUMN IF NOT EXISTS tracking_details JSONB;
ALTER TABLE trips ADD COLUMN IF NOT EXISTS tracking_updated_at TIMESTAMP WITH TIME ZONE;

-- Tracking status can be: preparacao, transito, aduana_origem, aduana_destino, entrega, entregue
-- Tracking details will store array of status updates with timestamps and descriptions

COMMENT ON COLUMN trips.tracking_status IS 'Current tracking status of the trip';
COMMENT ON COLUMN trips.tracking_details IS 'Array of tracking milestones with timestamps and descriptions';
COMMENT ON COLUMN trips.tracking_updated_at IS 'Last time tracking was updated';
