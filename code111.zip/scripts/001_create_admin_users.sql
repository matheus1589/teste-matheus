-- Create admin_users table for admin authentication
CREATE TABLE IF NOT EXISTS public.admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  full_name TEXT,
  email TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on admin_users
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;

-- Allow anyone to read admin_users for authentication
CREATE POLICY "Allow public read of admin_users for authentication"
  ON public.admin_users
  FOR SELECT
  USING (true);

-- Insert default admin user (password: admin123 - change this in production!)
-- Using bcrypt hash for 'admin123'
INSERT INTO public.admin_users (username, password_hash, full_name, email)
VALUES (
  'admin',
  '$2a$10$rOiPbz8E7vKJF5xKx5yPqeXQXz8YvQKJXz8YvQKJXz8YvQKJXz8Yv',
  'Administrador',
  'admin@inlog.biz'
)
ON CONFLICT (username) DO NOTHING;

-- Add updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = NOW();
   RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_admin_users_updated_at
  BEFORE UPDATE ON public.admin_users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
