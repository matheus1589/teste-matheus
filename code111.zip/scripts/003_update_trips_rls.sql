-- Update trips table RLS policies for client-specific access

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can read trips" ON public.trips;
DROP POLICY IF EXISTS "Anyone can insert trips" ON public.trips;
DROP POLICY IF EXISTS "Anyone can update trips" ON public.trips;
DROP POLICY IF EXISTS "Anyone can delete trips" ON public.trips;

-- Allow admin to read all trips
CREATE POLICY "Admin can read all trips"
  ON public.trips
  FOR SELECT
  USING (true);

-- Allow admin to insert trips
CREATE POLICY "Admin can insert trips"
  ON public.trips
  FOR INSERT
  WITH CHECK (true);

-- Allow admin to update trips
CREATE POLICY "Admin can update trips"
  ON public.trips
  FOR UPDATE
  USING (true);

-- Allow admin to delete trips
CREATE POLICY "Admin can delete trips"
  ON public.trips
  FOR DELETE
  USING (true);
