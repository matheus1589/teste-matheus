-- Create collection_requests table for managing client collection requests
CREATE TABLE IF NOT EXISTS public.collection_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_username TEXT NOT NULL,
  collection_type TEXT NOT NULL, -- 'exportacao' or 'importacao'
  status TEXT DEFAULT 'pendente', -- 'pendente', 'aprovada', 'rejeitada', 'aguardando_info'
  is_chemical BOOLEAN DEFAULT false,
  driver_name TEXT,
  origin TEXT,
  destination TEXT,
  pickup_address TEXT,
  delivery_address TEXT,
  ncm_products TEXT,
  net_weight NUMERIC,
  product_weight NUMERIC,
  cargo_type TEXT,
  volume_quantity INTEGER,
  is_container BOOLEAN,
  container_size TEXT,
  is_isotank BOOLEAN,
  additional_info_requested TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  approved_at TIMESTAMP WITH TIME ZONE
);

-- Create indexes for faster queries
CREATE INDEX IF NOT EXISTS idx_collection_requests_client_username 
  ON public.collection_requests(client_username);
CREATE INDEX IF NOT EXISTS idx_collection_requests_status 
  ON public.collection_requests(status);
CREATE INDEX IF NOT EXISTS idx_collection_requests_created_at 
  ON public.collection_requests(created_at DESC);

-- Enable Row Level Security
ALTER TABLE public.collection_requests ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Allow public read access"
  ON public.collection_requests
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow public insert access"
  ON public.collection_requests
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow public update access"
  ON public.collection_requests
  FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow public delete access"
  ON public.collection_requests
  FOR DELETE
  TO public
  USING (true);

-- Add updated_at trigger
CREATE TRIGGER update_collection_requests_updated_at
  BEFORE UPDATE ON public.collection_requests
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Add comments for documentation
COMMENT ON TABLE public.collection_requests IS 'Stores collection requests from clients for import/export operations';
COMMENT ON COLUMN public.collection_requests.collection_type IS 'Type of collection: exportacao or importacao';
COMMENT ON COLUMN public.collection_requests.status IS 'Request status: pendente, aprovada, rejeitada, aguardando_info';
COMMENT ON COLUMN public.collection_requests.is_chemical IS 'Whether the cargo contains chemical products';
COMMENT ON COLUMN public.collection_requests.additional_info_requested IS 'Additional information requested from client when status is aguardando_info';
