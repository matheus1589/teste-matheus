-- Create the collection-documents bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('collection-documents', 'collection-documents', true)
ON CONFLICT (id) DO NOTHING;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Allow public uploads to collection-documents" ON storage.objects;
DROP POLICY IF EXISTS "Allow public read access to collection-documents" ON storage.objects;
DROP POLICY IF EXISTS "Allow public update access to collection-documents" ON storage.objects;
DROP POLICY IF EXISTS "Allow public delete access to collection-documents" ON storage.objects;

-- Create policies for the bucket
CREATE POLICY "Allow public uploads to collection-documents"
ON storage.objects FOR INSERT
TO public
WITH CHECK (bucket_id = 'collection-documents');

CREATE POLICY "Allow public read access to collection-documents"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'collection-documents');

CREATE POLICY "Allow public update access to collection-documents"
ON storage.objects FOR UPDATE
TO public
USING (bucket_id = 'collection-documents');

CREATE POLICY "Allow public delete access to collection-documents"
ON storage.objects FOR DELETE
TO public
USING (bucket_id = 'collection-documents');
