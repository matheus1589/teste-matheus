-- Create the collection-documents bucket with explicit error handling
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public)
  VALUES ('collection-documents', 'collection-documents', true)
  ON CONFLICT (id) DO NOTHING;
  RAISE NOTICE 'Bucket collection-documents created or already exists';
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Error creating bucket: %', SQLERRM;
END $$;

-- Enable RLS on storage.objects
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist to avoid conflicts
DROP POLICY IF EXISTS "Allow public uploads to collection-documents" ON storage.objects;
DROP POLICY IF EXISTS "Allow public read access to collection-documents" ON storage.objects;
DROP POLICY IF EXISTS "Allow public update access to collection-documents" ON storage.objects;

-- Create fresh policies with proper permissions
CREATE POLICY "Allow public uploads to collection-documents"
ON storage.objects FOR INSERT
TO public
WITH CHECK (bucket_id = 'collection-documents');

CREATE POLICY "Allow public read access to collection-documents"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'collection-documents');

CREATE POLICY "Allow public update access to collection-documents"
ON storage.objects FOR UPDATE
TO public
USING (bucket_id = 'collection-documents');

-- Also add a delete policy for completeness
CREATE POLICY "Allow public delete access to collection-documents"
ON storage.objects FOR DELETE
TO public
USING (bucket_id = 'collection-documents');
