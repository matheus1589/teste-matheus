"use client"

import { useState, useEffect } from "react"
import { ClientPortalLogin } from "@/components/client-portal-login"
import { ClientPortalTrips } from "@/components/client-portal-trips"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { LogOut, ArrowLeft } from 'lucide-react'
import Link from "next/link"

export default function PortalPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [currentUser, setCurrentUser] = useState<{ username: string; name: string } | null>(null)

  useEffect(() => {
    const savedAuth = localStorage.getItem("portal_auth")
    if (savedAuth) {
      const authData = JSON.parse(savedAuth)
      setIsAuthenticated(true)
      setCurrentUser(authData)
    }
  }, [])

  const handleLogin = (username: string, name: string) => {
    setIsAuthenticated(true)
    setCurrentUser({ username, name })
    localStorage.setItem("portal_auth", JSON.stringify({ username, name }))
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    setCurrentUser(null)
    localStorage.removeItem("portal_auth")
  }

  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <Image
              src="/images/inlog-logo.png"
              alt="INLOG - Integração Logística"
              width={200}
              height={80}
              priority
              className="h-16 w-auto"
            />
          </div>
          
          {isAuthenticated && currentUser && (
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm font-medium">{currentUser.name}</p>
                <p className="text-xs text-muted-foreground">{currentUser.username}</p>
              </div>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            </div>
          )}
        </div>

        {!isAuthenticated ? (
          <ClientPortalLogin onLogin={handleLogin} />
        ) : (
          <ClientPortalTrips username={currentUser?.username || ""} />
        )}
      </div>
    </main>
  )
}
