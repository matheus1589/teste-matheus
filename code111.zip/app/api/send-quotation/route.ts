import { Resend } from 'resend';
import { NextResponse } from 'next/server';

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { 
      name, 
      email, 
      phone, 
      company, 
      origin, 
      destination, 
      cargoType, 
      weight, 
      message 
    } = body;

    // Validação básica
    if (!name || !email || !phone) {
      return NextResponse.json(
        { error: 'Nome, email e telefone são obrigatórios' },
        { status: 400 }
      );
    }

    const targetEmail = 'divin@inlog.biz';
    
    try {
      const { data, error } = await resend.emails.send({
        from: 'Cotação INLOG <onboarding@resend.dev>',
        to: [targetEmail],
        replyTo: email,
        subject: `Nova Solicitação de Cotação - ${company || name}`,
        html: `
          <!DOCTYPE html>
          <html>
            <head>
              <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #005f8f; color: white; padding: 20px; text-align: center; }
                .content { background: #f9f9f9; padding: 20px; }
                .field { margin-bottom: 15px; }
                .label { font-weight: bold; color: #005f8f; }
                .value { margin-top: 5px; }
                .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
              </style>
            </head>
            <body>
              <div class="container">
                <div class="header">
                  <h1>Nova Solicitação de Cotação</h1>
                </div>
                <div class="content">
                  <h2>Dados do Solicitante</h2>
                  <div class="field">
                    <div class="label">Nome:</div>
                    <div class="value">${name}</div>
                  </div>
                  <div class="field">
                    <div class="label">E-mail:</div>
                    <div class="value">${email}</div>
                  </div>
                  <div class="field">
                    <div class="label">Telefone:</div>
                    <div class="value">${phone}</div>
                  </div>
                  <div class="field">
                    <div class="label">Empresa:</div>
                    <div class="value">${company || 'Não informada'}</div>
                  </div>
                  
                  <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;" />
                  
                  <h2>Detalhes da Carga</h2>
                  <div class="field">
                    <div class="label">Origem:</div>
                    <div class="value">${origin || 'Não informada'}</div>
                  </div>
                  <div class="field">
                    <div class="label">Destino:</div>
                    <div class="value">${destination || 'Não informada'}</div>
                  </div>
                  <div class="field">
                    <div class="label">Tipo de Carga:</div>
                    <div class="value">${cargoType || 'Não informada'}</div>
                  </div>
                  <div class="field">
                    <div class="label">Peso Estimado:</div>
                    <div class="value">${weight || 'Não informado'}</div>
                  </div>
                  
                  ${message ? `
                    <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;" />
                    <h2>Mensagem Adicional</h2>
                    <div class="field">
                      <div class="value">${message}</div>
                    </div>
                  ` : ''}
                </div>
                <div class="footer">
                  <p>Esta é uma solicitação automática do site INLOG</p>
                  <p>Para responder, utilize o e-mail: ${email}</p>
                </div>
              </div>
            </body>
          </html>
        `,
      });

      if (error) {
        throw error;
      }

      return NextResponse.json({ success: true, data });
    } catch (emailError: any) {
      // Fallback para ambiente de teste
      if (emailError?.statusCode === 403 || emailError?.name === 'validation_error') {
        console.log('[Cotação] Limitação do Resend - domínio não verificado');
        console.log('[Cotação] Dados da cotação:', { name, email, phone, company, origin, destination });
        
        return NextResponse.json({ 
          success: true, 
          warning: 'Cotação registrada. Configure o domínio no Resend para envio automático de e-mails.' 
        });
      }
      throw emailError;
    }

  } catch (error) {
    console.error('Erro ao enviar cotação:', error);
    return NextResponse.json(
      { error: 'Falha ao enviar cotação' },
      { status: 500 }
    );
  }
}
