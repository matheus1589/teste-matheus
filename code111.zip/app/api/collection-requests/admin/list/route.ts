import { createServerClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const supabase = await createServerClient(await cookies())

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()
    if (userError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data: adminData, error: adminError } = await supabase
      .from("admin_users")
      .select("id")
      .eq("email", user.email)
      .eq("is_active", true)
      .single()

    if (adminError || !adminData) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const { data, error } = await supabase
      .from("collection_requests")
      .select(
        `
        id,
        client_username,
        collection_type,
        status,
        is_chemical,
        driver_name,
        origin,
        destination,
        pickup_address,
        delivery_address,
        ncm_products,
        net_weight,
        product_weight,
        cargo_type,
        volume_quantity,
        is_container,
        container_size,
        is_isotank,
        additional_info_requested,
        admin_notes,
        document_url,
        created_at,
        approved_at,
        client_users (
          company_name,
          contact_name
        )
      `,
      )
      .order("created_at", { ascending: false })

    if (error) {
      console.error("[v0] Supabase error:", error)
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    return NextResponse.json(data || [])
  } catch (error) {
    console.error("[v0] API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
