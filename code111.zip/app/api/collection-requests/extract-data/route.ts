import { type NextRequest, NextResponse } from "next/server"

// Simple document data extraction - in production, you'd use a real OCR service
export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Convert file to base64 for text extraction
    const buffer = await file.arrayBuffer()
    const text = new TextDecoder().decode(buffer)

    // Simple regex-based extraction (in production, use a real OCR/PDF parser)
    const extractedData = {
      driver_name: extractField(text, /(?:motorista|condutor|driver)[\s:]*([^\n]+)/i),
      driver_cpf: extractField(text, /(?:cpf)[\s:]*(\d{3}\.\d{3}\.\d{3}-\d{2}|\d{11})/i),
      vehicle_plate_head: extractField(text, /(?:placa|plate)[\s:]*([A-Z]{3}[-]?\d{4})/i),
      vehicle_plate_trailer: extractField(text, /(?:reboque|trailer)[\s:]*([A-Z]{3}[-]?\d{4})/i),
      origin: extractField(text, /(?:origem|from|saída)[\s:]*([^\n]+)/i),
      destination: extractField(text, /(?:destino|to|chegada)[\s:]*([^\n]+)/i),
      exporter: extractField(text, /(?:exportador|shipper)[\s:]*([^\n]+)/i),
      importer: extractField(text, /(?:importador|consignee)[\s:]*([^\n]+)/i),
      invoice: extractField(text, /(?:nf|nota fiscal|invoice)[\s:]*(\d+)/i),
    }

    return NextResponse.json({ extractedData })
  } catch (error) {
    console.error("Extraction error:", error)
    return NextResponse.json({ error: "Failed to extract data" }, { status: 500 })
  }
}

function extractField(text: string, regex: RegExp): string | null {
  const match = text.match(regex)
  return match ? match[1].trim() : null
}
