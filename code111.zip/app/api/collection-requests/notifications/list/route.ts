import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            try {
              cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
            } catch {
              // Handle errors during cookie setting
            }
          },
        },
      },
    )

    const searchParams = request.nextUrl.searchParams
    const clientUsername = searchParams.get("clientUsername")

    if (!clientUsername) {
      return NextResponse.json({ error: "clientUsername is required" }, { status: 400 })
    }

    const { data: notifications, error } = await supabase
      .from("collection_request_notifications")
      .select("*")
      .eq("client_username", clientUsername)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("[v0] Error fetching notifications:", error)
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    return NextResponse.json(notifications)
  } catch (error) {
    console.error("[v0] Error in list notifications:", error)
    return NextResponse.json({ error: "Failed to list notifications" }, { status: 500 })
  }
}
