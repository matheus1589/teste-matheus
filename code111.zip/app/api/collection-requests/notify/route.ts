import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            try {
              cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
            } catch {
              // Handle errors during cookie setting
            }
          },
        },
      },
    )

    const { collectionRequestId, clientUsername, status, reason } = await request.json()

    if (!collectionRequestId || !clientUsername || !status) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const { data: notification, error } = await supabase
      .from("collection_request_notifications")
      .insert({
        collection_request_id: collectionRequestId,
        client_username: clientUsername,
        status,
        message: getNotificationMessage(status, reason),
        read: false,
        created_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) {
      console.error("[v0] Error creating notification:", error)
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    return NextResponse.json(notification)
  } catch (error) {
    console.error("[v0] Error in notify collection request:", error)
    return NextResponse.json({ error: "Failed to create notification" }, { status: 500 })
  }
}

function getNotificationMessage(status: string, reason?: string): string {
  switch (status) {
    case "aprovada":
      return "Sua solicitação de coleta foi aprovada! A coleta pode prosseguir conforme planejado."
    case "rejeitada":
      return `Sua solicitação de coleta foi rejeitada. Motivo: ${reason || "Documentação incompleta"}`
    case "aguardando_info":
      return `Sua solicitação de coleta está aguardando informações adicionais: ${reason || "Verificar documentação"}`
    default:
      return "Sua solicitação de coleta foi atualizada."
  }
}
