"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Upload, FileText, Download, Scan, ClipboardList, Users, Shield } from 'lucide-react'
import { DocumentScanner } from "@/components/document-scanner"
import { MultiDocumentManager } from "@/components/multi-document-manager"
import { CollectionOrderManager } from "@/components/collection-order-manager"
import { FollowUpManager } from "@/components/follow-up-manager"
import Image from "next/image"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

interface ProcessedPage {
  id: string
  originalImage: string
  processedImage: string | null
}

export default function Home() {
  const [pages, setPages] = useState<ProcessedPage[]>([])
  const [currentPageIndex, setCurrentPageIndex] = useState<number | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [activeTab, setActiveTab] = useState("scanner")

  const handleClearPortalData = () => {
    const password = prompt("Digite a senha para limpar os dados do portal:")
    
    if (password !== "2025") {
      alert("Senha incorreta!")
      return
    }
    
    if (confirm("Tem certeza que deseja limpar todos os dados do portal do cliente? Esta ação não pode ser desfeita.")) {
      localStorage.removeItem("client_trips")
      alert("Dados do portal limpos com sucesso! Você pode agora reimportar a planilha para atualizar os dados.")
    }
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      const newPages: ProcessedPage[] = []
      let filesRead = 0

      Array.from(files).forEach((file, index) => {
        const reader = new FileReader()
        reader.onload = (event) => {
          newPages.push({
            id: `page-${Date.now()}-${index}`,
            originalImage: event.target?.result as string,
            processedImage: null,
          })
          filesRead++

          if (filesRead === files.length) {
            setPages((prev) => [...prev, ...newPages])
            setCurrentPageIndex(pages.length)
          }
        }
        reader.readAsDataURL(file)
      })
    }
  }

  const handleProcessComplete = (processedImageData: string) => {
    if (currentPageIndex !== null) {
      setPages((prev) => {
        const updated = [...prev]
        updated[currentPageIndex] = {
          ...updated[currentPageIndex],
          processedImage: processedImageData,
        }
        return updated
      })
    }
    setIsProcessing(false)
  }

  const handleSelectPage = (index: number) => {
    setCurrentPageIndex(index)
  }

  const handleDeletePage = (index: number) => {
    setPages((prev) => prev.filter((_, i) => i !== index))
    if (currentPageIndex === index) {
      setCurrentPageIndex(pages.length > 1 ? 0 : null)
    } else if (currentPageIndex !== null && currentPageIndex > index) {
      setCurrentPageIndex(currentPageIndex - 1)
    }
  }

  const handleReorderPages = (fromIndex: number, toIndex: number) => {
    setPages((prev) => {
      const updated = [...prev]
      const [moved] = updated.splice(fromIndex, 1)
      updated.splice(toIndex, 0, moved)
      return updated
    })
  }

  const handleReset = () => {
    setPages([])
    setCurrentPageIndex(null)
    setIsProcessing(false)
  }

  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-6">
            <Image
              src="/images/inlog.png"
              alt="INLOG - Integração Logística"
              width={300}
              height={120}
              priority
              className="h-16 md:h-20 w-auto"
            />
          </div>
          <div className="flex items-center justify-center gap-3 mb-4">
            <Scan className="w-8 h-8 md:w-10 md:h-10 text-primary" />
            <h1 className="text-3xl md:text-4xl font-bold text-foreground">Sistema INLOG</h1>
          </div>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto mb-6 px-4">
            Plataforma completa para digitalização de documentos e gestão de ordens de coleta
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-2 sm:gap-3 px-4">
            <Link href="/portal" className="w-full sm:w-auto">
              <Button variant="outline" size="lg" className="gap-2 w-full">
                <Users className="w-5 h-5" />
                <span className="hidden sm:inline">Portal Cliente</span>
                <span className="sm:hidden">Portal</span>
              </Button>
            </Link>
            <Link href="/admin" className="w-full sm:w-auto">
              <Button variant="default" size="lg" className="gap-2 w-full">
                <Shield className="w-5 h-5" />
                <span className="hidden sm:inline">Painel Admin</span>
                <span className="sm:hidden">Admin</span>
              </Button>
            </Link>
            <Button 
              variant="destructive" 
              size="lg" 
              className="gap-2 w-full sm:w-auto"
              onClick={handleClearPortalData}
            >
              <FileText className="w-5 h-5" />
              <span className="hidden md:inline">Limpar Dados do Portal</span>
              <span className="md:hidden">Limpar Dados</span>
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-3xl mx-auto grid-cols-3 mb-8 h-auto">
            <TabsTrigger value="scanner" className="gap-2 py-3">
              <Scan className="w-4 h-4" />
              <span className="hidden sm:inline">DocScanner</span>
              <span className="sm:hidden text-xs">Scanner</span>
            </TabsTrigger>
            <TabsTrigger value="collection" className="gap-2 py-3">
              <ClipboardList className="w-4 h-4" />
              <span className="hidden sm:inline">Ordem de Coleta</span>
              <span className="sm:hidden text-xs">Coleta</span>
            </TabsTrigger>
            <TabsTrigger value="followup" className="gap-2 py-3">
              <Upload className="w-4 h-4" />
              <span className="hidden sm:inline">Atualizar Follow-Up</span>
              <span className="sm:hidden text-xs">Follow-Up</span>
            </TabsTrigger>
          </TabsList>

          {/* Scanner Tab */}
          <TabsContent value="scanner">
            {pages.length === 0 ? (
              <Card className="max-w-2xl mx-auto p-8 md:p-12">
                <div className="text-center">
                  <div className="mb-6 flex justify-center">
                    <div className="w-20 h-20 md:w-24 md:h-24 rounded-full bg-primary/10 flex items-center justify-center">
                      <Upload className="w-10 h-10 md:w-12 md:h-12 text-primary" />
                    </div>
                  </div>
                  <h2 className="text-xl md:text-2xl font-semibold mb-3">Enviar Documentos</h2>
                  <p className="text-sm md:text-base text-muted-foreground mb-8 px-4">
                    Tire fotos ou selecione uma ou mais imagens do seu dispositivo
                  </p>
                  <label htmlFor="file-upload">
                    <Button size="lg" className="cursor-pointer w-full sm:w-auto" asChild>
                      <span>
                        <FileText className="w-5 h-5 mr-2" />
                        Escolher Imagens
                      </span>
                    </Button>
                  </label>
                  <input
                    id="file-upload"
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  <p className="text-xs md:text-sm text-muted-foreground mt-4 px-4">
                    Formatos suportados: JPG, PNG, WEBP • Múltiplas imagens suportadas
                  </p>
                </div>
              </Card>
            ) : (
              <div className="space-y-6">
                <MultiDocumentManager
                  pages={pages}
                  currentPageIndex={currentPageIndex}
                  onSelectPage={handleSelectPage}
                  onDeletePage={handleDeletePage}
                  onReorderPages={handleReorderPages}
                  onAddMore={handleImageUpload}
                  onReset={handleReset}
                />

                {currentPageIndex !== null && (
                  <Card className="p-4 md:p-6">
                    <div className="mb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <h3 className="text-lg md:text-xl font-semibold mb-2">
                          Página {currentPageIndex + 1} de {pages.length}
                        </h3>
                        <p className="text-xs md:text-sm text-muted-foreground">Ajuste os pontos de corte se necessário</p>
                      </div>
                      {pages[currentPageIndex].processedImage && (
                        <div className="text-sm text-green-600 font-medium">✓ Processado</div>
                      )}
                    </div>
                    <DocumentScanner
                      imageUrl={pages[currentPageIndex].originalImage}
                      onProcessComplete={handleProcessComplete}
                      isProcessing={isProcessing}
                      setIsProcessing={setIsProcessing}
                    />
                  </Card>
                )}
              </div>
            )}

            {/* Features */}
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 mt-16 max-w-5xl mx-auto px-4">
              <div className="text-center p-6">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Scan className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Detecção Automática</h3>
                <p className="text-sm text-muted-foreground">Reconhece bordas do documento automaticamente</p>
              </div>
              <div className="text-center p-6">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <FileText className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Múltiplas Páginas</h3>
                <p className="text-sm text-muted-foreground">Adicione várias páginas e combine em um único PDF</p>
              </div>
              <div className="text-center p-6 sm:col-span-2 md:col-span-1">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Download className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Exportar PDF</h3>
                <p className="text-sm text-muted-foreground">Converta para PDF de alta qualidade</p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="collection">
            <CollectionOrderManager />
          </TabsContent>

          <TabsContent value="followup">
            <FollowUpManager />
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}
