-- Drop existing policies on collection_requests
DROP POLICY IF EXISTS "Allow public read access" ON collection_requests;
DROP POLICY IF EXISTS "Allow public insert access" ON collection_requests;
DROP POLICY IF EXISTS "Allow public update access" ON collection_requests;
DROP POLICY IF EXISTS "Allow public delete access" ON collection_requests;

-- Create proper RLS policies for collection_requests
-- Allow users to read their own collection requests
CREATE POLICY "Users can read own collection requests" ON collection_requests
  FOR SELECT
  USING (
    auth.jwt() ->> 'email' IN (
      SELECT email FROM client_users WHERE username = collection_requests.client_username
    )
    OR auth.jwt() ->> 'role' = 'admin'
  );

-- Allow users to insert their own collection requests
CREATE POLICY "Users can insert own collection requests" ON collection_requests
  FOR INSERT
  WITH CHECK (
    auth.jwt() ->> 'email' IN (
      SELECT email FROM client_users WHERE username = collection_requests.client_username
    )
  );

-- Allow users to update their own collection requests
CREATE POLICY "Users can update own collection requests" ON collection_requests
  FOR UPDATE
  USING (
    auth.jwt() ->> 'email' IN (
      SELECT email FROM client_users WHERE username = collection_requests.client_username
    )
    OR auth.jwt() ->> 'role' = 'admin'
  );

-- Allow users to delete their own collection requests
CREATE POLICY "Users can delete own collection requests" ON collection_requests
  FOR DELETE
  USING (
    auth.jwt() ->> 'email' IN (
      SELECT email FROM client_users WHERE username = collection_requests.client_username
    )
  );
