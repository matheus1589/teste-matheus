-- Create the collection-documents bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('collection-documents', 'collection-documents', true)
ON CONFLICT (id) DO NOTHING;

-- Enable RLS on storage.objects if it's not already enabled (usually is by default)
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Policy to allow anyone to upload files to the collection-documents bucket
CREATE POLICY "Allow public uploads to collection-documents"
ON storage.objects FOR INSERT
TO public
WITH CHECK (bucket_id = 'collection-documents');

-- Policy to allow anyone to read files from the collection-documents bucket
CREATE POLICY "Allow public read access to collection-documents"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'collection-documents');

-- Policy to allow anyone to update their own files (optional, but good for completeness)
CREATE POLICY "Allow public update access to collection-documents"
ON storage.objects FOR UPDATE
TO public
USING (bucket_id = 'collection-documents');
