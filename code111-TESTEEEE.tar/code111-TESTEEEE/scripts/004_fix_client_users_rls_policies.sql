-- Fix RLS policies for client_users table to allow admin operations

-- Drop existing policies if any
DROP POLICY IF EXISTS "Allow public read of client_users for authentication" ON client_users;

-- Create comprehensive policies for client_users table

-- 1. Allow anyone to read client_users (needed for authentication)
CREATE POLICY "Allow public read access"
  ON client_users
  FOR SELECT
  TO public
  USING (true);

-- 2. Allow anyone to insert new clients (for registration)
CREATE POLICY "Allow public insert access"
  ON client_users
  FOR INSERT
  TO public
  WITH CHECK (true);

-- 3. Allow anyone to update client information
CREATE POLICY "Allow public update access"
  ON client_users
  FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

-- 4. Allow anyone to delete clients (admin function)
CREATE POLICY "Allow public delete access"
  ON client_users
  FOR DELETE
  TO public
  USING (true);

-- Verify policies were created
SELECT schemaname, tablename, policyname, cmd
FROM pg_policies
WHERE tablename = 'client_users'
ORDER BY cmd, policyname;
