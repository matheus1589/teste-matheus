-- Update collection_requests table with new fields
ALTER TABLE public.collection_requests
ADD COLUMN IF NOT EXISTS incoterms TEXT,
ADD COLUMN IF NOT EXISTS observation TEXT,
ADD COLUMN IF NOT EXISTS admin_observation TEXT,
ADD COLUMN IF NOT EXISTS is_palletized BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS pallet_quantity INTEGER,
ADD COLUMN IF NOT EXISTS loading_forecast TIMESTAMP WITH TIME ZONE;

-- Add comments for documentation
COMMENT ON COLUMN public.collection_requests.incoterms IS 'Incoterms for the shipment';
COMMENT ON COLUMN public.collection_requests.observation IS 'Client observations';
COMMENT ON COLUMN public.collection_requests.admin_observation IS 'Admin observations when processing the request';
COMMENT ON COLUMN public.collection_requests.is_palletized IS 'Whether the cargo is palletized';
COMMENT ON COLUMN public.collection_requests.pallet_quantity IS 'Quantity of pallets if palletized';
COMMENT ON COLUMN public.collection_requests.loading_forecast IS 'Forecast date/time for loading';
