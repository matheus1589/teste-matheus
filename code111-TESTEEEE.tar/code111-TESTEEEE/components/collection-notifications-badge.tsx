"use client"

import { useState, useEffect } from "react"
import { Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { toast } from "sonner"

interface Notification {
  id: string
  collection_request_id: string
  status: string
  message: string
  read: boolean
  created_at: string
}

export function CollectionNotificationsBadge() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(false)

  // Fetch notifications
  const fetchNotifications = async () => {
    try {
      const res = await fetch("/api/collection-requests/notifications/list")
      const data = await res.json()
      setNotifications(data.notifications || [])
    } catch (error) {
      console.error("[v0] Error fetching notifications:", error)
    }
  }

  useEffect(() => {
    fetchNotifications()
    // Poll for new notifications every 30 seconds
    const interval = setInterval(fetchNotifications, 30000)
    return () => clearInterval(interval)
  }, [])

  const handleMarkAsRead = async (notificationId: string) => {
    try {
      await fetch("/api/collection-requests/notifications/mark-read", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notification_id: notificationId }),
      })
      fetchNotifications()
    } catch (error) {
      console.error("[v0] Error marking notification as read:", error)
      toast.error("Erro ao marcar notificação como lida")
    }
  }

  const getNotificationColor = (status: string) => {
    switch (status) {
      case "aprovada":
        return "bg-green-50 border-green-200"
      case "rejeitada":
        return "bg-red-50 border-red-200"
      case "aguardando_info":
        return "bg-yellow-50 border-yellow-200"
      default:
        return "bg-blue-50 border-blue-200"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "aprovada":
        return "Aprovada"
      case "rejeitada":
        return "Rejeitada"
      case "aguardando_info":
        return "Aguardando Informações"
      default:
        return "Notificação"
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="w-5 h-5" />
          {notifications.length > 0 && (
            <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">
              {notifications.length}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <DropdownMenuLabel>Notificações de Coleta</DropdownMenuLabel>
        <DropdownMenuSeparator />

        {notifications.length === 0 ? (
          <div className="p-4 text-sm text-gray-500 text-center">Nenhuma notificação</div>
        ) : (
          <div className="max-h-96 overflow-y-auto space-y-2 p-2">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className={`p-3 rounded-lg border cursor-pointer transition-colors ${getNotificationColor(
                  notification.status,
                )} hover:opacity-80`}
                onClick={() => handleMarkAsRead(notification.id)}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <p className="font-semibold text-sm">{getStatusLabel(notification.status)}</p>
                    <p className="text-xs text-gray-600 mt-1">{notification.message}</p>
                    <p className="text-xs text-gray-400 mt-2">
                      {new Date(notification.created_at).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                  {!notification.read && <div className="w-2 h-2 bg-blue-500 rounded-full mt-1 flex-shrink-0" />}
                </div>
              </div>
            ))}
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
