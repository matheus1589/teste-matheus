"use client"

import { X, Download, ZoomIn, ZoomOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"

interface DocumentPreviewModalProps {
  isOpen: boolean
  onClose: () => void
  image: string | null
  pageNumber: number
}

export function DocumentPreviewModal({ isOpen, onClose, image, pageNumber }: DocumentPreviewModalProps) {
  const [zoom, setZoom] = useState(100)

  if (!isOpen || !image) return null

  const handleDownload = () => {
    const link = document.createElement("a")
    link.href = image
    link.download = `documento-pagina-${pageNumber}.jpg`
    link.click()
  }

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 25, 200))
  }

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 25, 50))
  }

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="relative bg-background rounded-lg max-w-6xl w-full max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <div>
            <h3 className="text-lg font-semibold">Página {pageNumber}</h3>
            <p className="text-sm text-muted-foreground">Visualização do documento processado</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleZoomOut} disabled={zoom <= 50}>
              <ZoomOut className="w-4 h-4" />
            </Button>
            <span className="text-sm font-medium min-w-12 text-center">{zoom}%</span>
            <Button variant="outline" size="sm" onClick={handleZoomIn} disabled={zoom >= 200}>
              <ZoomIn className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={handleDownload}>
              <Download className="w-4 h-4 mr-2" />
              Baixar
            </Button>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Image Container */}
        <div className="flex-1 overflow-auto p-4 bg-muted/30">
          <div className="flex items-center justify-center min-h-full">
            <img
              src={image || "/placeholder.svg"}
              alt={`Página ${pageNumber}`}
              className="max-w-full h-auto rounded shadow-lg"
              style={{ width: `${zoom}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
