"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Upload, FileSpreadsheet, CheckCircle2, AlertCircle } from 'lucide-react'
import * as XLSX from "xlsx"
import { createClient } from "@/lib/supabase/client"

interface TrackingUpdate {
  crt: string
  status: string
  details: string
  timestamp: Date
}

export function FollowUpManager() {
  const [file, setFile] = useState<File | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [result, setResult] = useState<{
    success: number
    failed: number
    errors: string[]
  } | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0])
      setResult(null)
    }
  }

  const parseTrackingFile = async (file: File): Promise<TrackingUpdate[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()

      reader.onload = (e) => {
        try {
          const data = e.target?.result
          const workbook = XLSX.read(data, { type: "binary" })
          const sheetName = workbook.SheetNames[0]
          const sheet = workbook.Sheets[sheetName]
          const rows = XLSX.utils.sheet_to_json(sheet, { header: 1 }) as any[][]

          console.log("[v0] Parsing tracking file, found", rows.length, "rows")

          const updates: TrackingUpdate[] = []
          
          // Skip header row
          for (let i = 1; i < rows.length; i++) {
            const row = rows[i]
            
            // Expected columns: CRT | Status | Details
            const crt = String(row[0] || "").trim()
            const status = String(row[1] || "").trim()
            const details = String(row[2] || "").trim()

            if (crt && status) {
              updates.push({
                crt,
                status,
                details,
                timestamp: new Date()
              })
            }
          }

          console.log("[v0] Parsed", updates.length, "tracking updates")
          resolve(updates)
        } catch (error) {
          console.error("[v0] Error parsing file:", error)
          reject(error)
        }
      }

      reader.onerror = () => reject(new Error("Erro ao ler o arquivo"))
      reader.readAsBinaryString(file)
    })
  }

  const handleUpload = async () => {
    if (!file) {
      alert("Por favor, selecione um arquivo")
      return
    }

    setIsProcessing(true)
    setResult(null)

    try {
      const updates = await parseTrackingFile(file)
      
      if (updates.length === 0) {
        alert("Nenhuma atualização de rastreamento encontrada no arquivo")
        setIsProcessing(false)
        return
      }

      const supabase = createClient()
      let successCount = 0
      let failedCount = 0
      const errors: string[] = []

      for (const update of updates) {
        try {
          // Find trip by CRT
          const { data: trips, error: searchError } = await supabase
            .from('trips')
            .select('*')
            .eq('crt', update.crt)

          if (searchError) {
            console.error("[v0] Error searching for trip:", searchError)
            errors.push(`${update.crt}: Erro ao buscar viagem`)
            failedCount++
            continue
          }

          if (!trips || trips.length === 0) {
            console.log("[v0] Trip not found:", update.crt)
            errors.push(`${update.crt}: Viagem não encontrada`)
            failedCount++
            continue
          }

          const trip = trips[0]
          
          // Get existing tracking details or create new array
          const existingDetails = trip.tracking_details || []
          
          // Add new update to tracking details
          const newDetails = [
            ...existingDetails,
            {
              status: update.status,
              details: update.details,
              timestamp: update.timestamp.toISOString()
            }
          ]

          // Update trip with new tracking information
          const { error: updateError } = await supabase
            .from('trips')
            .update({
              tracking_status: update.status,
              tracking_details: newDetails,
              tracking_updated_at: new Date().toISOString()
            })
            .eq('id', trip.id)

          if (updateError) {
            console.error("[v0] Error updating trip:", updateError)
            errors.push(`${update.crt}: Erro ao atualizar`)
            failedCount++
            continue
          }

          console.log("[v0] Successfully updated trip:", update.crt)
          successCount++
        } catch (error) {
          console.error("[v0] Error processing update:", error)
          errors.push(`${update.crt}: Erro ao processar`)
          failedCount++
        }
      }

      setResult({
        success: successCount,
        failed: failedCount,
        errors
      })
    } catch (error) {
      console.error("[v0] Error uploading tracking file:", error)
      alert("Erro ao processar o arquivo de rastreamento")
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center bg-gradient-to-r from-primary/10 via-primary/5 to-background p-8 rounded-2xl">
        <h2 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          Atualizar Follow-Up
        </h2>
        <p className="text-muted-foreground">
          Faça upload da planilha com atualizações de rastreamento das viagens
        </p>
      </div>

      <Card className="p-6">
        <div className="space-y-6">
          <div className="flex items-start gap-4 p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
            <FileSpreadsheet className="w-6 h-6 text-blue-600 dark:text-blue-400 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
                Formato da Planilha
              </h3>
              <p className="text-sm text-blue-800 dark:text-blue-200 mb-3">
                A planilha deve conter as seguintes colunas na primeira linha:
              </p>
              <div className="grid grid-cols-3 gap-2 text-sm">
                <div className="bg-white dark:bg-gray-900 p-2 rounded border border-blue-200 dark:border-blue-700">
                  <span className="font-medium">Coluna A:</span> CRT
                </div>
                <div className="bg-white dark:bg-gray-900 p-2 rounded border border-blue-200 dark:border-blue-700">
                  <span className="font-medium">Coluna B:</span> Status
                </div>
                <div className="bg-white dark:bg-gray-900 p-2 rounded border border-blue-200 dark:border-blue-700">
                  <span className="font-medium">Coluna C:</span> Detalhes
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tracking-file">Selecionar Arquivo Excel</Label>
            <Input
              id="tracking-file"
              type="file"
              accept=".xlsx,.xls"
              onChange={handleFileChange}
              disabled={isProcessing}
            />
            {file && (
              <p className="text-sm text-muted-foreground">
                Arquivo selecionado: {file.name}
              </p>
            )}
          </div>

          <Button
            onClick={handleUpload}
            disabled={!file || isProcessing}
            className="w-full gap-2"
            size="lg"
          >
            {isProcessing ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Processando...
              </>
            ) : (
              <>
                <Upload className="w-5 h-5" />
                Fazer Upload e Atualizar Rastreamento
              </>
            )}
          </Button>

          {result && (
            <div className="space-y-4 pt-4 border-t">
              <div className="grid md:grid-cols-2 gap-4">
                <Card className="p-4 bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-8 h-8 text-green-600 dark:text-green-400" />
                    <div>
                      <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                        {result.success}
                      </p>
                      <p className="text-sm text-green-700 dark:text-green-300">
                        Viagens atualizadas com sucesso
                      </p>
                    </div>
                  </div>
                </Card>

                {result.failed > 0 && (
                  <Card className="p-4 bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800">
                    <div className="flex items-center gap-3">
                      <AlertCircle className="w-8 h-8 text-red-600 dark:text-red-400" />
                      <div>
                        <p className="text-2xl font-bold text-red-600 dark:text-red-400">
                          {result.failed}
                        </p>
                        <p className="text-sm text-red-700 dark:text-red-300">
                          Falhas ao atualizar
                        </p>
                      </div>
                    </div>
                  </Card>
                )}
              </div>

              {result.errors.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm">Erros encontrados:</h4>
                  <div className="max-h-48 overflow-y-auto space-y-1">
                    {result.errors.map((error, index) => (
                      <p key={index} className="text-sm text-destructive bg-destructive/10 p-2 rounded">
                        {error}
                      </p>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </Card>
    </div>
  )
}
