"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { AdminLogin } from "./admin-login"
import { ClientManager } from "./client-manager"
import { AdminTripFilters, type TripFilters } from "./admin-trip-filters"
import { TripReportGenerator } from "./trip-report-generator"
import { FollowUpEmailSender } from "./follow-up-email-sender"
import { AdminCollectionRequests } from "./admin-collection-requests"
import { Trash2, Edit, Search, Users, Shield, LogOut, LayoutGrid, ListIcon, Truck } from "lucide-react"
import { toast } from "sonner"

interface Trip {
  id: string
  crt: string
  client_reference: string
  origem: string
  destino: string
  driver_name: string
  tracking_status: string
  tracking_details: any[]
  status: string
  client_username: string
  exportador: string
  start_date?: string
  placa_cavalo?: string
  placa_carreta?: string
  importador?: string
  created_at?: string
}

const statusOptions = [
  { value: "preparacao", label: "Preparação" },
  { value: "transito", label: "Trânsito" },
  { value: "aduana_origem", label: "Aduana Origem" },
  { value: "canal_vermelho", label: "Canal Vermelho" },
  { value: "aduana_destino", label: "Aduana Destino" },
  { value: "entrega", label: "Em transito para Entrega" },
  { value: "entregue", label: "Entregue" },
]

export function AdminPanel() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [adminUsername, setAdminUsername] = useState("")

  const [trips, setTrips] = useState<Trip[]>([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState<TripFilters>({})
  const [filteredTrips, setFilteredTrips] = useState<Trip[]>([])
  const [editingTrip, setEditingTrip] = useState<Trip | null>(null)
  const [newStatus, setNewStatus] = useState("")
  const [statusDetails, setStatusDetails] = useState("")
  const [viewMode, setViewMode] = useState<"card" | "list">("card")
  const supabase = createClient()

  const applyFilters = () => {
    let result = [...trips]

    // Filter by status
    if (filters.status) {
      result = result.filter((trip) => trip.tracking_status === filters.status)
    }

    // Filter by client username
    if (filters.clientUsername) {
      result = result.filter((trip) => trip.client_username === filters.clientUsername)
    }

    // Filter by exportador
    if (filters.exportador) {
      result = result.filter((trip) => trip.exportador === filters.exportador)
    }

    // Filter by date range
    if (filters.dateFrom) {
      result = result.filter((trip) => {
        const tripDate = new Date(trip.start_date || trip.created_at || "")
        return tripDate >= filters.dateFrom!
      })
    }

    if (filters.dateTo) {
      result = result.filter((trip) => {
        const tripDate = new Date(trip.start_date || trip.created_at || "")
        return tripDate <= filters.dateTo!
      })
    }

    // Filter by driver name
    if (filters.driverName) {
      result = result.filter((trip) => trip.driver_name?.toLowerCase().includes(filters.driverName!.toLowerCase()))
    }

    // Filter by placa (cavalo or carreta)
    if (filters.placa) {
      const placaLower = filters.placa.toLowerCase()
      result = result.filter(
        (trip) =>
          trip.placa_cavalo?.toLowerCase().includes(placaLower) ||
          trip.placa_carreta?.toLowerCase().includes(placaLower),
      )
    }

    // General search term
    if (filters.searchTerm) {
      const searchLower = filters.searchTerm.toLowerCase()
      result = result.filter(
        (trip) =>
          trip.crt?.toLowerCase().includes(searchLower) ||
          trip.client_reference?.toLowerCase().includes(searchLower) ||
          trip.driver_name?.toLowerCase().includes(searchLower) ||
          trip.exportador?.toLowerCase().includes(searchLower) ||
          trip.importador?.toLowerCase().includes(searchLower),
      )
    }

    setFilteredTrips(result)
  }

  useEffect(() => {
    const session = localStorage.getItem("admin_session")
    if (session) {
      try {
        const data = JSON.parse(session)
        setAdminUsername(data.username)
        setIsAuthenticated(true)
      } catch (e) {
        localStorage.removeItem("admin_session")
      }
    }
  }, [])

  useEffect(() => {
    if (isAuthenticated) {
      loadTrips()
    }
  }, [isAuthenticated])

  useEffect(() => {
    applyFilters()
  }, [trips, filters])

  const handleLogout = () => {
    localStorage.removeItem("admin_session")
    setIsAuthenticated(false)
    setAdminUsername("")
    toast.success("Logout realizado com sucesso")
  }

  const handleLogin = (username: string) => {
    setAdminUsername(username)
    setIsAuthenticated(true)
  }

  if (!isAuthenticated) {
    return <AdminLogin onLogin={handleLogin} />
  }

  const loadTrips = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase.from("trips").select("*").order("created_at", { ascending: false })

      if (error) throw error
      setTrips(data || [])
    } catch (error) {
      console.error("[v0] Error loading trips:", error)
      toast.error("Erro ao carregar viagens")
    } finally {
      setLoading(false)
    }
  }

  const updateTripStatus = async () => {
    if (!editingTrip || !newStatus) {
      toast.error("Selecione um status")
      return
    }

    try {
      const newMilestone = {
        status: newStatus,
        details: statusDetails || "Status atualizado",
        timestamp: new Date().toISOString(),
      }

      const updatedDetails = [...(editingTrip.tracking_details || []), newMilestone]

      const { error } = await supabase
        .from("trips")
        .update({
          tracking_status: newStatus,
          tracking_details: updatedDetails,
          tracking_updated_at: new Date().toISOString(),
        })
        .eq("id", editingTrip.id)

      if (error) throw error

      toast.success("Status atualizado com sucesso!")
      setEditingTrip(null)
      setNewStatus("")
      setStatusDetails("")
      loadTrips()
    } catch (error) {
      console.error("[v0] Error updating status:", error)
      toast.error("Erro ao atualizar status")
    }
  }

  const deleteTrip = async (tripId: string) => {
    if (!confirm("Tem certeza que deseja excluir esta viagem?")) return

    try {
      const { error } = await supabase.from("trips").delete().eq("id", tripId)

      if (error) throw error
      toast.success("Viagem excluída com sucesso!")
      loadTrips()
    } catch (error) {
      console.error("[v0] Error deleting trip:", error)
      toast.error("Erro ao excluir viagem")
    }
  }

  const handleFiltersChange = (newFilters: TripFilters) => {
    setFilters(newFilters)
  }

  const handleResetFilters = () => {
    setFilters({})
  }

  return (
    <div className="w-full">
      {isAuthenticated ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-gradient-to-r from-primary/10 to-background p-4 rounded-lg">
            <div className="flex items-center gap-3">
              <Shield className="w-6 h-6 text-primary" />
              <div>
                <h2 className="text-2xl font-bold">Painel Administrativo</h2>
                <p className="text-sm text-muted-foreground">Logado como: {adminUsername}</p>
              </div>
            </div>
            <Button onClick={handleLogout} variant="outline" className="gap-2 bg-transparent">
              <LogOut className="w-4 h-4" />
              Sair
            </Button>
          </div>

          <Tabs defaultValue="trips" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="trips" className="gap-2">
                <Search className="w-4 h-4" />
                Gerenciar Viagens
              </TabsTrigger>
              <TabsTrigger value="clients" className="gap-2">
                <Users className="w-4 h-4" />
                Gerenciar Clientes
              </TabsTrigger>
              <TabsTrigger value="reports" className="gap-2">
                <LayoutGrid className="w-4 h-4" />
                Relatórios
              </TabsTrigger>
              <TabsTrigger value="collection-requests" className="gap-2">
                <Truck className="w-4 h-4" />
                Solicitações de Coleta
              </TabsTrigger>
            </TabsList>

            <TabsContent value="trips" className="space-y-6">
              <AdminTripFilters onFiltersChange={handleFiltersChange} onReset={handleResetFilters} />

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold">Viagens Cadastradas</h3>
                  <p className="text-sm text-muted-foreground">
                    Exibindo {filteredTrips.length} de {trips.length} viagem(ns)
                  </p>
                </div>
                <div className="flex gap-2">
                  <div className="flex gap-1 border rounded-lg p-1">
                    <Button
                      variant={viewMode === "card" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setViewMode("card")}
                      className="gap-2"
                    >
                      <LayoutGrid className="w-4 h-4" />
                      Cards
                    </Button>
                    <Button
                      variant={viewMode === "list" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setViewMode("list")}
                      className="gap-2"
                    >
                      <ListIcon className="w-4 h-4" />
                      Lista
                    </Button>
                  </div>
                  <FollowUpEmailSender />
                  <TripReportGenerator trips={filteredTrips} filters={filters} />
                  <Button onClick={loadTrips} variant="outline">
                    Atualizar
                  </Button>
                </div>
              </div>

              {loading ? (
                <p className="text-center text-muted-foreground">Carregando viagens...</p>
              ) : (
                <>
                  {viewMode === "card" && (
                    <div className="grid gap-4">
                      {filteredTrips.map((trip) => (
                        <Card key={trip.id} className="p-4">
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1 space-y-2">
                              <div className="flex items-center gap-2">
                                <h3 className="font-semibold">CRT: {trip.crt}</h3>
                                <span
                                  className={`text-xs px-2 py-1 rounded-full ${
                                    trip.tracking_status === "entregue"
                                      ? "bg-green-100 text-green-700 dark:bg-green-950/20 dark:text-green-400"
                                      : trip.tracking_status === "canal_vermelho"
                                        ? "bg-red-100 text-red-700 dark:bg-red-950/20 dark:text-red-400"
                                        : "bg-blue-100 text-blue-700 dark:bg-blue-950/20 dark:text-blue-400"
                                  }`}
                                >
                                  {statusOptions.find((s) => s.value === trip.tracking_status)?.label ||
                                    trip.tracking_status}
                                </span>
                              </div>
                              <p className="text-sm text-muted-foreground">Ref: {trip.client_reference || "N/A"}</p>
                              <p className="text-sm">
                                <strong>Rota:</strong> {trip.origem} → {trip.destino}
                              </p>
                              <p className="text-sm">
                                <strong>Motorista:</strong> {trip.driver_name || "N/A"}
                              </p>
                              <p className="text-sm">
                                <strong>Cliente:</strong> {trip.client_username || "N/A"} | <strong>Exportador:</strong>{" "}
                                {trip.exportador || "N/A"}
                              </p>
                              {(trip.placa_cavalo || trip.placa_carreta) && (
                                <p className="text-sm">
                                  <strong>Placas:</strong> {trip.placa_cavalo || "N/A"} / {trip.placa_carreta || "N/A"}
                                </p>
                              )}
                            </div>

                            <div className="flex gap-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button
                                    variant="outline"
                                    size="icon"
                                    onClick={() => {
                                      setEditingTrip(trip)
                                      setNewStatus(trip.tracking_status)
                                    }}
                                  >
                                    <Edit className="w-4 h-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Atualizar Status - CRT: {trip.crt}</DialogTitle>
                                  </DialogHeader>
                                  <div className="space-y-4">
                                    <div className="space-y-2">
                                      <Label>Novo Status</Label>
                                      <Select value={newStatus} onValueChange={setNewStatus}>
                                        <SelectTrigger>
                                          <SelectValue placeholder="Selecione um status" />
                                        </SelectTrigger>
                                        <SelectContent>
                                          {statusOptions.map((option) => (
                                            <SelectItem key={option.value} value={option.value}>
                                              {option.label}
                                            </SelectItem>
                                          ))}
                                        </SelectContent>
                                      </Select>
                                    </div>

                                    <div className="space-y-2">
                                      <Label>Detalhes (opcional)</Label>
                                      <Textarea
                                        value={statusDetails}
                                        onChange={(e) => setStatusDetails(e.target.value)}
                                        placeholder="Adicione informações adicionais..."
                                        rows={3}
                                      />
                                    </div>

                                    <Button onClick={updateTripStatus} className="w-full">
                                      Atualizar Status
                                    </Button>
                                  </div>
                                </DialogContent>
                              </Dialog>

                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() => deleteTrip(trip.id)}
                                className="text-destructive hover:text-destructive"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  )}

                  {viewMode === "list" && (
                    <Card className="overflow-hidden">
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead className="bg-muted/50 border-b">
                            <tr>
                              <th className="text-left p-3 text-sm font-semibold">CRT</th>
                              <th className="text-left p-3 text-sm font-semibold">Referência</th>
                              <th className="text-left p-3 text-sm font-semibold">Cliente</th>
                              <th className="text-left p-3 text-sm font-semibold">Rota</th>
                              <th className="text-left p-3 text-sm font-semibold">Motorista</th>
                              <th className="text-left p-3 text-sm font-semibold">Status</th>
                              <th className="text-right p-3 text-sm font-semibold">Ações</th>
                            </tr>
                          </thead>
                          <tbody>
                            {filteredTrips.map((trip) => (
                              <tr key={trip.id} className="border-b hover:bg-muted/30 transition-colors">
                                <td className="p-3 text-sm font-medium">{trip.crt}</td>
                                <td className="p-3 text-sm text-muted-foreground">{trip.client_reference || "N/A"}</td>
                                <td className="p-3 text-sm">{trip.client_username || "N/A"}</td>
                                <td className="p-3 text-sm">
                                  <div className="flex items-center gap-1">
                                    <span className="truncate max-w-[100px]">{trip.origem}</span>
                                    <span>→</span>
                                    <span className="truncate max-w-[100px]">{trip.destino}</span>
                                  </div>
                                </td>
                                <td className="p-3 text-sm">{trip.driver_name || "N/A"}</td>
                                <td className="p-3">
                                  <span
                                    className={`text-xs px-2 py-1 rounded-full whitespace-nowrap ${
                                      trip.tracking_status === "entregue"
                                        ? "bg-green-100 text-green-700 dark:bg-green-950/20 dark:text-green-400"
                                        : trip.tracking_status === "canal_vermelho"
                                          ? "bg-red-100 text-red-700 dark:bg-red-950/20 dark:text-red-400"
                                          : "bg-blue-100 text-blue-700 dark:bg-blue-950/20 dark:text-blue-400"
                                    }`}
                                  >
                                    {statusOptions.find((s) => s.value === trip.tracking_status)?.label ||
                                      trip.tracking_status}
                                  </span>
                                </td>
                                <td className="p-3">
                                  <div className="flex gap-2 justify-end">
                                    <Dialog>
                                      <DialogTrigger asChild>
                                        <Button
                                          variant="outline"
                                          size="icon"
                                          className="h-8 w-8 bg-transparent"
                                          onClick={() => {
                                            setEditingTrip(trip)
                                            setNewStatus(trip.tracking_status)
                                          }}
                                        >
                                          <Edit className="w-3 h-3" />
                                        </Button>
                                      </DialogTrigger>
                                      <DialogContent>
                                        <DialogHeader>
                                          <DialogTitle>Atualizar Status - CRT: {trip.crt}</DialogTitle>
                                        </DialogHeader>
                                        <div className="space-y-4">
                                          <div className="space-y-2">
                                            <Label>Novo Status</Label>
                                            <Select value={newStatus} onValueChange={setNewStatus}>
                                              <SelectTrigger>
                                                <SelectValue placeholder="Selecione um status" />
                                              </SelectTrigger>
                                              <SelectContent>
                                                {statusOptions.map((option) => (
                                                  <SelectItem key={option.value} value={option.value}>
                                                    {option.label}
                                                  </SelectItem>
                                                ))}
                                              </SelectContent>
                                            </Select>
                                          </div>

                                          <div className="space-y-2">
                                            <Label>Detalhes (opcional)</Label>
                                            <Textarea
                                              value={statusDetails}
                                              onChange={(e) => setStatusDetails(e.target.value)}
                                              placeholder="Adicione informações adicionais..."
                                              rows={3}
                                            />
                                          </div>

                                          <Button onClick={updateTripStatus} className="w-full">
                                            Atualizar Status
                                          </Button>
                                        </div>
                                      </DialogContent>
                                    </Dialog>

                                    <Button
                                      variant="outline"
                                      size="icon"
                                      className="h-8 w-8 text-destructive hover:text-destructive bg-transparent"
                                      onClick={() => deleteTrip(trip.id)}
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </Button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </Card>
                  )}
                </>
              )}

              {!loading && filteredTrips.length === 0 && (
                <Card className="p-12 text-center">
                  <p className="text-muted-foreground">
                    {trips.length === 0
                      ? "Nenhuma viagem cadastrada"
                      : "Nenhuma viagem encontrada com os filtros aplicados"}
                  </p>
                  {trips.length > 0 && (
                    <Button onClick={handleResetFilters} variant="outline" className="mt-4 bg-transparent">
                      Limpar Filtros
                    </Button>
                  )}
                </Card>
              )}
            </TabsContent>

            <TabsContent value="clients">
              <ClientManager />
            </TabsContent>

            <TabsContent value="reports">{/* Placeholder for reports content */}</TabsContent>

            <TabsContent value="collection-requests">
              <AdminCollectionRequests />
            </TabsContent>
          </Tabs>
        </div>
      ) : (
        <AdminLogin onLogin={(username) => setAdminUsername(username) || setIsAuthenticated(true)} />
      )}
    </div>
  )
}
