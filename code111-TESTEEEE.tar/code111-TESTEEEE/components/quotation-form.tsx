"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, Send, CheckCircle } from 'lucide-react'
import { useToast } from "@/hooks/use-toast"

export function QuotationForm() {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [cargoType, setCargoType] = useState("")

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setIsLoading(true)

    const formData = new FormData(event.currentTarget)
    const data = {
      name: formData.get('name'),
      email: formData.get('email'),
      phone: formData.get('phone'),
      company: formData.get('company'),
      origin: formData.get('origin'),
      destination: formData.get('destination'),
      cargoType: cargoType,
      weight: formData.get('weight'),
      message: formData.get('message'),
    }

    try {
      const response = await fetch("/api/send-quotation", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (!response.ok) throw new Error("Falha ao enviar")

      setIsSuccess(true)
      toast({
        title: "Cotação enviada!",
        description: "Recebemos sua solicitação e entraremos em contato em breve.",
      })
    } catch (error) {
      toast({
        title: "Erro ao enviar",
        description: "Houve um problema ao enviar sua cotação. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (isSuccess) {
    return (
      <Card className="w-full max-w-2xl mx-auto border-green-200 bg-green-50">
        <CardContent className="pt-6 text-center py-12">
          <div className="flex justify-center mb-4">
            <CheckCircle className="h-16 w-16 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-green-800 mb-2">Solicitação Enviada com Sucesso!</h2>
          <p className="text-green-700 mb-6">
            Obrigado pelo interesse na INLOG. Nossa equipe comercial analisará sua solicitação e retornará o contato o mais breve possível.
          </p>
          <Button 
            onClick={() => setIsSuccess(false)} 
            variant="outline" 
            className="border-green-600 text-green-700 hover:bg-green-100"
          >
            Enviar nova cotação
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-lg">
      <CardHeader className="bg-[#005f8f] text-white rounded-t-lg">
        <CardTitle className="text-2xl">Solicitar Cotação</CardTitle>
        <CardDescription className="text-blue-100">
          Preencha o formulário abaixo com os detalhes da sua carga para receber uma proposta personalizada.
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Nome Completo *</Label>
              <Input id="name" name="name" required placeholder="Seu nome" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="company">Empresa</Label>
              <Input id="company" name="company" placeholder="Nome da empresa" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="email">E-mail Corporativo *</Label>
              <Input id="email" name="email" type="email" required placeholder="seu@email.com" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Telefone / WhatsApp *</Label>
              <Input id="phone" name="phone" required placeholder="(00) 00000-0000" />
            </div>
          </div>

          <div className="border-t pt-4 mt-4">
            <h3 className="text-sm font-semibold text-gray-500 mb-4 uppercase tracking-wider">Dados da Carga</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="origin">Cidade de Origem</Label>
                <Input id="origin" name="origin" placeholder="Cidade/UF" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="destination">Cidade de Destino</Label>
                <Input id="destination" name="destination" placeholder="Cidade/UF" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="cargoType">Tipo de Carga</Label>
              <Select value={cargoType} onValueChange={setCargoType}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="geral">Carga Geral</SelectItem>
                  <SelectItem value="quimica">Produtos Químicos</SelectItem>
                  <SelectItem value="container">Contêiner</SelectItem>
                  <SelectItem value="fracionada">Carga Fracionada</SelectItem>
                  <SelectItem value="outros">Outros</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="weight">Peso Estimado (kg)</Label>
              <Input id="weight" name="weight" placeholder="Ex: 1500 kg" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Observações Adicionais</Label>
            <Textarea 
              id="message" 
              name="message" 
              placeholder="Descreva detalhes específicos sobre a carga, dimensões ou necessidades especiais..." 
              className="min-h-[100px]"
            />
          </div>

          <Button type="submit" className="w-full bg-[#005f8f] hover:bg-[#004b73] h-12 text-lg" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Enviando...
              </>
            ) : (
              <>
                <Send className="mr-2 h-5 w-5" /> Enviar Solicitação
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
