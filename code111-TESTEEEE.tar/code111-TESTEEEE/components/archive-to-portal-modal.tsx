"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Archive, Check, TruckIcon } from 'lucide-react'
import { Card } from "@/components/ui/card"

interface ArchiveToPortalModalProps {
  isOpen: boolean
  onClose: () => void
  pdfData: string | null
}

interface PendingTrip {
  id: string
  crt: string
  clientReference: string
  origin: string
  destination: string
  startDate: string
  status: string
  exportador?: string
}

export function ArchiveToPortalModal({ isOpen, onClose, pdfData }: ArchiveToPortalModalProps) {
  const [crt, setCrt] = useState("")
  const [clientReference, setClientReference] = useState("")
  const [clientUsername, setClientUsername] = useState("")
  const [origin, setOrigin] = useState("")
  const [destination, setDestination] = useState("")
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")
  const [status, setStatus] = useState("Concluída")
  const [isSuccess, setIsSuccess] = useState(false)
  const [availableUsers, setAvailableUsers] = useState<string[]>([])
  const [pendingTrips, setPendingTrips] = useState<PendingTrip[]>([])
  const [selectedTripId, setSelectedTripId] = useState<string>("")

  useEffect(() => {
    const loadUsers = async () => {
      const supabase = createClient()
      
      const { data, error } = await supabase
        .from('client_users')
        .select('username')
      
      if (error) {
        console.error("[v0] Error loading users:", error)
        return
      }
      
      setAvailableUsers(data?.map(u => u.username) || [])
    }
    
    loadUsers()
  }, [])

  useEffect(() => {
    if (clientUsername) {
      loadPendingTrips(clientUsername)
    } else {
      setPendingTrips([])
      setSelectedTripId("")
    }
  }, [clientUsername])

  const loadPendingTrips = async (username: string) => {
    const supabase = createClient()
    
    console.log("[v0] Loading pending trips for user:", username)
    
    try {
      let query = supabase
        .from('trips')
        .select('*')
        .eq('client_username', username)
        .eq('status', 'Em Trânsito')
        .is('proof_of_delivery_url', null)
      
      // For cliente2, only show trips with exportador "PEROXIDOS"
      if (username === "cliente2") {
        query = query.ilike('exportador', '%PEROXIDOS%')
      }
      
      const { data, error } = await query
      
      if (error) {
        console.error("[v0] Error loading pending trips:", error)
        return
      }
      
      const mappedTrips: PendingTrip[] = (data || []).map(trip => ({
        id: trip.id,
        crt: trip.crt || '',
        clientReference: trip.client_reference || '',
        origin: trip.origem || '',
        destination: trip.destino || '',
        startDate: trip.start_date || '',
        status: trip.status || 'pending',
        exportador: trip.exportador || ''
      }))
      
      console.log("[v0] Pending trips found:", mappedTrips.length)
      setPendingTrips(mappedTrips)
    } catch (error) {
      console.error("[v0] Error loading pending trips:", error)
    }
  }

  const handleSelectPendingTrip = (tripId: string) => {
    const trip = pendingTrips.find(t => t.id === tripId)
    if (trip) {
      setSelectedTripId(tripId)
      setCrt(trip.crt)
      setClientReference(trip.clientReference)
      setOrigin(trip.origin)
      setDestination(trip.destination)
      
      let formattedStartDate = trip.startDate || ''
      
      console.log(`[v0] Original startDate from trip:`, trip.startDate, typeof trip.startDate)
      
      // Convert to string if it's not already
      if (typeof formattedStartDate !== 'string') {
        formattedStartDate = String(formattedStartDate)
      }
      
      if (formattedStartDate && !isNaN(Number(formattedStartDate)) && Number(formattedStartDate) > 1000) {
        // It's likely an Excel serial date
        const excelDate = Number(formattedStartDate)
        const excelEpoch = new Date(Date.UTC(1899, 11, 30))
        const date = new Date(excelEpoch.getTime() + excelDate * 24 * 60 * 60 * 1000)
        formattedStartDate = date.toISOString().split('T')[0]
        console.log(`[v0] Converted Excel serial date ${excelDate} to ISO: ${formattedStartDate}`)
      } else if (formattedStartDate) {
        // If it's already in ISO format, just use the date part
        if (formattedStartDate.includes('T')) {
          formattedStartDate = formattedStartDate.split('T')[0]
        }
        // If it's in Brazilian format (dd/mm/yyyy), convert to YYYY-MM-DD
        else if (formattedStartDate.includes('/')) {
          const parts = formattedStartDate.split('/')
          if (parts.length === 3) {
            formattedStartDate = `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`
          }
        }
      }
      
      console.log(`[v0] Selected trip ${tripId}, formatted startDate: ${formattedStartDate}`)
      
      setStartDate(formattedStartDate)
      setStatus("Concluída")
      setEndDate(new Date().toISOString().split('T')[0])
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!crt || !clientReference || !clientUsername || !origin || !destination || !startDate) {
      alert("Por favor, preencha todos os campos obrigatórios")
      return
    }

    const supabase = createClient()
    
    try {
      if (selectedTripId) {
        // Update existing trip
        console.log("[v0] Updating trip:", selectedTripId)
        
        const { error } = await supabase
          .from('trips')
          .update({
            end_date: endDate,
            status: status,
            proof_of_delivery_url: pdfData || null,
            updated_at: new Date().toISOString()
          })
          .eq('id', selectedTripId)
        
        if (error) {
          console.error("[v0] Error updating trip:", error)
          alert("Erro ao atualizar a viagem: " + error.message)
          return
        }
        
        setIsSuccess(true)
        setTimeout(() => {
          handleClose()
        }, 2000)
        return
      }
      
      // Check if trip with same CRT already exists
      const { data: existingTrips } = await supabase
        .from('trips')
        .select('id')
        .eq('crt', crt)
        .eq('client_username', clientUsername)
      
      if (existingTrips && existingTrips.length > 0) {
        alert("Uma viagem com este CRT já existe para este cliente. Por favor, use um CRT diferente.")
        return
      }

      // Create new trip
      console.log("[v0] Creating new trip")
      
      const { error } = await supabase
        .from('trips')
        .insert({
          crt,
          client_username: clientUsername,
          client_reference: clientReference,
          origem: origin,
          destino: destination,
          start_date: startDate,
          end_date: endDate,
          status,
          proof_of_delivery_url: pdfData || null
        })
      
      if (error) {
        console.error("[v0] Error creating trip:", error)
        alert("Erro ao criar a viagem: " + error.message)
        return
      }

      setIsSuccess(true)
      setTimeout(() => {
        handleClose()
      }, 2000)
    } catch (error) {
      console.error("[v0] Error saving trip:", error)
      alert("Erro ao salvar os dados")
    }
  }

  const handleClose = () => {
    setCrt("")
    setClientReference("")
    setClientUsername("")
    setOrigin("")
    setDestination("")
    setStartDate("")
    setEndDate("")
    setStatus("Concluída")
    setIsSuccess(false)
    setPendingTrips([])
    setSelectedTripId("")
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Archive className="w-5 h-5" />
            Arquivar Comprovante no Portal do Cliente
          </DialogTitle>
          <DialogDescription>
            Preencha as informações da viagem para disponibilizar o comprovante de entrega no portal do cliente
          </DialogDescription>
        </DialogHeader>

        {isSuccess ? (
          <div className="py-12 text-center">
            <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/20 flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Arquivado com Sucesso!</h3>
            <p className="text-muted-foreground">
              O comprovante foi arquivado e está disponível no portal do cliente
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="clientUsername">
                Usuário do Cliente <span className="text-destructive">*</span>
              </Label>
              <Select value={clientUsername} onValueChange={setClientUsername} required>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o usuário do cliente" />
                </SelectTrigger>
                <SelectContent>
                  {availableUsers.map((user) => (
                    <SelectItem key={user} value={user}>
                      {user}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Selecione o usuário do cliente que terá acesso a esta viagem
              </p>
            </div>

            {pendingTrips.length > 0 && (
              <div className="space-y-2">
                <Label>Viagens Pendentes de Comprovante</Label>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {pendingTrips.map((trip) => (
                    <Card
                      key={trip.id}
                      className={`p-3 cursor-pointer hover:bg-accent transition-colors ${
                        selectedTripId === trip.id ? 'border-primary bg-accent' : ''
                      }`}
                      onClick={() => handleSelectPendingTrip(trip.id)}
                    >
                      <div className="flex items-start gap-3">
                        <TruckIcon className="w-5 h-5 mt-0.5 text-muted-foreground" />
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-sm">{trip.crt}</span>
                            <span className="text-xs text-muted-foreground">{trip.clientReference}</span>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {trip.origin} → {trip.destination}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            Início: {trip.startDate ? new Date(trip.startDate).toLocaleDateString('pt-BR') : 'N/A'}
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">
                  Clique em uma viagem para preencher automaticamente os campos
                </p>
              </div>
            )}

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="crt">
                  CRT <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="crt"
                  placeholder="Ex: CRT-2024-001"
                  value={crt}
                  onChange={(e) => setCrt(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reference">
                  Referência do Cliente <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="reference"
                  placeholder="Ex: REF-12345"
                  value={clientReference}
                  onChange={(e) => setClientReference(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="origin">
                  Origem <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="origin"
                  placeholder="Ex: São Paulo - SP"
                  value={origin}
                  onChange={(e) => setOrigin(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="destination">
                  Destino <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="destination"
                  placeholder="Ex: Rio de Janeiro - RJ"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="startDate">
                  Data de Início <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="startDate"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="endDate">Data de Término</Label>
                <Input id="endDate" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Concluída">Concluída</SelectItem>
                    <SelectItem value="Em Trânsito">Em Trânsito</SelectItem>
                    <SelectItem value="Pendente">Pendente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-2 justify-end pt-4">
              <Button type="button" variant="outline" onClick={handleClose}>
                Cancelar
              </Button>
              <Button type="submit">
                <Archive className="w-4 h-4 mr-2" />
                Arquivar Comprovante
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  )
}
