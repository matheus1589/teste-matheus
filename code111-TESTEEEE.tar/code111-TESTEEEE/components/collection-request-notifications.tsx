"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Bell, X, CheckCircle, AlertCircle, XCircle } from "lucide-react"
import { toast } from "sonner"

interface Notification {
  id: string
  collection_request_id: string
  client_username: string
  status: "aprovada" | "rejeitada" | "aguardando_info"
  message: string
  read: boolean
  created_at: string
}

interface CollectionRequestNotificationsProps {
  username: string
}

export function CollectionRequestNotifications({ username }: CollectionRequestNotificationsProps) {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [showDropdown, setShowDropdown] = useState(false)
  const supabase = createClient()

  useEffect(() => {
    loadNotifications()

    const channel = supabase
      .channel(`collection_notifications:${username}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "collection_request_notifications",
          filter: `client_username=eq.${username}`,
        },
        (payload) => {
          const newNotification = payload.new as Notification
          setNotifications((prev) => [newNotification, ...prev])
          setUnreadCount((prev) => prev + 1)

          // Show toast notification
          showNotificationToast(newNotification)
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [username])

  const loadNotifications = async () => {
    try {
      const response = await fetch(`/api/collection-requests/notifications/list?clientUsername=${username}`)
      if (response.ok) {
        const data = await response.json()
        setNotifications(data)
        const unread = data.filter((n: Notification) => !n.read).length
        setUnreadCount(unread)
      }
    } catch (error) {
      console.error("[v0] Error loading notifications:", error)
    }
  }

  const showNotificationToast = (notification: Notification) => {
    const statusEmoji = {
      aprovada: "✓",
      rejeitada: "✗",
      aguardando_info: "⚠",
    }[notification.status]

    toast[notification.status === "aprovada" ? "success" : "info"](`${statusEmoji} ${notification.message}`)
  }

  const markAsRead = async (notificationId: string) => {
    try {
      const response = await fetch("/api/collection-requests/notifications/mark-read", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: notificationId }),
      })

      if (response.ok) {
        setNotifications((prev) => prev.map((n) => (n.id === notificationId ? { ...n, read: true } : n)))
        setUnreadCount((prev) => Math.max(0, prev - 1))
      }
    } catch (error) {
      console.error("[v0] Error marking notification as read:", error)
    }
  }

  const clearNotification = async (notificationId: string) => {
    try {
      const response = await fetch("/api/collection-requests/notifications/delete", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: notificationId }),
      })

      if (response.ok) {
        setNotifications((prev) => prev.filter((n) => n.id !== notificationId))
      }
    } catch (error) {
      console.error("[v0] Error deleting notification:", error)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "aprovada":
        return <CheckCircle className="w-5 h-5 text-green-600" />
      case "rejeitada":
        return <XCircle className="w-5 h-5 text-red-600" />
      case "aguardando_info":
        return <AlertCircle className="w-5 h-5 text-yellow-600" />
      default:
        return <Bell className="w-5 h-5 text-gray-600" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "aprovada":
        return "border-l-4 border-l-green-600 bg-green-50"
      case "rejeitada":
        return "border-l-4 border-l-red-600 bg-red-50"
      case "aguardando_info":
        return "border-l-4 border-l-yellow-600 bg-yellow-50"
      default:
        return "border-l-4 border-l-gray-600 bg-gray-50"
    }
  }

  return (
    <div className="relative">
      <button
        onClick={() => setShowDropdown(!showDropdown)}
        className="relative p-2 rounded-lg hover:bg-gray-100 transition-colors"
        title="Notificações de Coleta"
      >
        <Bell className="w-5 h-5 text-gray-700" />
        {unreadCount > 0 && (
          <span className="absolute top-1 right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
            {unreadCount}
          </span>
        )}
      </button>

      {showDropdown && (
        <div className="absolute right-0 mt-2 w-96 bg-white rounded-lg shadow-lg border border-gray-200 z-50 max-h-96 overflow-y-auto">
          <div className="p-4 border-b border-gray-200">
            <h3 className="font-semibold">Notificações de Coleta</h3>
            <p className="text-sm text-gray-500">{unreadCount} não lidas</p>
          </div>

          {notifications.length === 0 ? (
            <div className="p-8 text-center text-gray-500">Nenhuma notificação</div>
          ) : (
            <div className="space-y-2 p-2">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-3 rounded-lg flex items-start gap-3 ${getStatusColor(notification.status)} ${
                    !notification.read ? "opacity-100" : "opacity-75"
                  }`}
                  onClick={() => !notification.read && markAsRead(notification.id)}
                >
                  {getStatusIcon(notification.status)}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">{notification.message}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {new Date(notification.created_at).toLocaleDateString("pt-BR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      clearNotification(notification.id)
                    }}
                    className="text-gray-400 hover:text-gray-600 p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
