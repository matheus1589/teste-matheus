"use client"

import { Button } from "@/components/ui/button"
import { Share2, Mail } from 'lucide-react'
import { toast } from "sonner"

interface TrackingShareProps {
  crt: string
  origin: string
  destination: string
  trackingStatus?: string
  clientReference?: string
}

export function TrackingShare({ 
  crt, 
  origin, 
  destination, 
  trackingStatus,
  clientReference 
}: TrackingShareProps) {
  
  const generateTrackingMessage = () => {
    const statusText = trackingStatus || "em andamento"
    return `🚚 *Rastreamento de Carga - INLOG*\n\n` +
           `📋 CRT: ${crt}\n` +
           `${clientReference ? `📝 Ref: ${clientReference}\n` : ''}` +
           `📍 Origem: ${origin}\n` +
           `📍 Destino: ${destination}\n` +
           `📊 Status: ${statusText}\n\n` +
           `Acompanhe sua carga em tempo real.\n` +
           `INLOG - Integração Logística`
  }

  const handleWhatsAppShare = () => {
    const message = generateTrackingMessage()
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, '_blank')
    toast.success("WhatsApp aberto para compartilhamento")
  }

  const handleEmailShare = () => {
    const subject = `Rastreamento de Carga - CRT: ${crt}`
    const body = generateTrackingMessage()
    const mailtoUrl = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
    window.location.href = mailtoUrl
    toast.success("Cliente de e-mail aberto")
  }

  return (
    <div className="flex gap-2 flex-wrap">
      <Button 
        onClick={handleWhatsAppShare}
        variant="outline"
        size="sm"
        className="gap-2 bg-green-50 hover:bg-green-100 dark:bg-green-950/20 dark:hover:bg-green-950/30 text-green-700 dark:text-green-400 border-green-200 dark:border-green-800"
      >
        <Share2 className="w-4 h-4" />
        Compartilhar via WhatsApp
      </Button>
      <Button 
        onClick={handleEmailShare}
        variant="outline"
        size="sm"
        className="gap-2"
      >
        <Mail className="w-4 h-4" />
        Compartilhar via E-mail
      </Button>
    </div>
  )
}
