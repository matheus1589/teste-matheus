"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CollectionRequestForm } from "./collection-request-form"
import { CollectionRequestsList } from "./collection-requests-list"
import { Plus, List } from "lucide-react"

export function ClientCollectionRequestsTab() {
  const [refreshKey, setRefreshKey] = useState(0)

  const handleSuccess = () => {
    setRefreshKey((prev) => prev + 1)
  }

  return (
    <Tabs defaultValue="list" className="w-full">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="list" className="gap-2">
          <List className="w-4 h-4" />
          Minhas Solicitações
        </TabsTrigger>
        <TabsTrigger value="new" className="gap-2">
          <Plus className="w-4 h-4" />
          Nova Solicitação
        </TabsTrigger>
      </TabsList>

      <TabsContent value="list" className="space-y-6">
        <CollectionRequestsList key={refreshKey} />
      </TabsContent>

      <TabsContent value="new" className="space-y-6">
        <CollectionRequestForm onSuccess={handleSuccess} />
      </TabsContent>
    </Tabs>
  )
}
