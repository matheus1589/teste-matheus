"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { FileSpreadsheet, Download, Printer } from 'lucide-react'
import * as XLSX from 'xlsx'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'

interface Trip {
  id: string
  crt: string
  client_reference: string
  client_username: string
  start_date: string
  origem: string
  destino: string
  driver_name: string
  placa_cavalo: string
  placa_carreta: string
  exportador: string
  importador: string
  tracking_status: string
  status: string
  fatura: string
  created_at: string
}

interface TripReportGeneratorProps {
  trips: Trip[]
  filters: any
}

export function TripReportGenerator({ trips, filters }: TripReportGeneratorProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [selectedColumns, setSelectedColumns] = useState<string[]>([
    'crt',
    'client_reference',
    'client_username',
    'start_date',
    'origem',
    'destino',
    'driver_name',
    'placa_cavalo',
    'exportador',
    'tracking_status',
  ])

  const columns = [
    { id: 'crt', label: 'CRT' },
    { id: 'client_reference', label: 'Referência' },
    { id: 'client_username', label: 'Cliente' },
    { id: 'start_date', label: 'Data Início' },
    { id: 'origem', label: 'Origem' },
    { id: 'destino', label: 'Destino' },
    { id: 'driver_name', label: 'Motorista' },
    { id: 'placa_cavalo', label: 'Placa Cavalo' },
    { id: 'placa_carreta', label: 'Placa Carreta' },
    { id: 'exportador', label: 'Exportador' },
    { id: 'importador', label: 'Importador' },
    { id: 'tracking_status', label: 'Status Rastreamento' },
    { id: 'status', label: 'Status Geral' },
    { id: 'fatura', label: 'Fatura' },
    { id: 'created_at', label: 'Data Criação' },
  ]

  const toggleColumn = (columnId: string) => {
    if (selectedColumns.includes(columnId)) {
      setSelectedColumns(selectedColumns.filter(id => id !== columnId))
    } else {
      setSelectedColumns([...selectedColumns, columnId])
    }
  }

  const generateExcelReport = () => {
    if (trips.length === 0) {
      alert('Nenhuma viagem disponível para gerar relatório')
      return
    }

    // Prepare data
    const reportData = trips.map(trip => {
      const row: any = {}
      
      selectedColumns.forEach(colId => {
        const column = columns.find(c => c.id === colId)
        if (!column) return

        let value = trip[colId as keyof Trip]
        
        // Format dates
        if (colId === 'start_date' || colId === 'created_at') {
          try {
            value = value ? format(new Date(value), 'dd/MM/yyyy', { locale: ptBR }) : ''
          } catch {
            value = value || ''
          }
        }

        // Format status
        if (colId === 'tracking_status') {
          const statusMap: any = {
            'preparacao': 'Preparação',
            'transito': 'Trânsito',
            'aduana_origem': 'Aduana Origem',
            'canal_vermelho': 'Canal Vermelho',
            'aduana_destino': 'Aduana Destino',
            'entrega': 'Em Trânsito para Entrega',
            'entregue': 'Entregue',
          }
          value = statusMap[value as string] || value
        }

        row[column.label] = value || ''
      })

      return row
    })

    // Create workbook
    const ws = XLSX.utils.json_to_sheet(reportData)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, 'Viagens')

    // Auto-size columns
    const maxWidth = 50
    const colWidths = selectedColumns.map(colId => {
      const column = columns.find(c => c.id === colId)
      return { wch: Math.min(column?.label.length || 10, maxWidth) }
    })
    ws['!cols'] = colWidths

    // Generate filename
    const timestamp = format(new Date(), 'yyyyMMdd_HHmmss')
    const filename = `relatorio_viagens_${timestamp}.xlsx`

    // Download
    XLSX.writeFile(wb, filename)
    setIsOpen(false)
  }

  const printReport = () => {
    if (trips.length === 0) {
      alert('Nenhuma viagem disponível para imprimir')
      return
    }

    // Create print window
    const printWindow = window.open('', '_blank')
    if (!printWindow) return

    // Generate HTML table
    let html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Relatório de Viagens</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; }
          h1 { color: #333; margin-bottom: 20px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 12px; }
          th { background-color: #0ea5e9; color: white; }
          tr:nth-child(even) { background-color: #f9f9f9; }
          .header { margin-bottom: 20px; }
          .filters { background: #f0f0f0; padding: 10px; border-radius: 5px; margin-bottom: 20px; }
          @media print {
            body { padding: 0; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Relatório de Viagens - INLOG</h1>
          <p>Gerado em: ${format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</p>
          <p>Total de viagens: ${trips.length}</p>
        </div>
    `

    // Add filters info
    if (Object.keys(filters).length > 0) {
      html += '<div class="filters"><strong>Filtros aplicados:</strong> '
      const filterTexts = []
      if (filters.status) filterTexts.push(`Status: ${filters.status}`)
      if (filters.clientUsername) filterTexts.push(`Cliente: ${filters.clientUsername}`)
      if (filters.exportador) filterTexts.push(`Exportador: ${filters.exportador}`)
      if (filters.dateFrom) filterTexts.push(`Data início: ${format(filters.dateFrom, 'dd/MM/yyyy')}`)
      if (filters.dateTo) filterTexts.push(`Data fim: ${format(filters.dateTo, 'dd/MM/yyyy')}`)
      html += filterTexts.join(' | ')
      html += '</div>'
    }

    html += '<table><thead><tr>'

    // Add headers
    selectedColumns.forEach(colId => {
      const column = columns.find(c => c.id === colId)
      if (column) html += `<th>${column.label}</th>`
    })

    html += '</tr></thead><tbody>'

    // Add rows
    trips.forEach(trip => {
      html += '<tr>'
      selectedColumns.forEach(colId => {
        let value = trip[colId as keyof Trip]
        
        if (colId === 'start_date' || colId === 'created_at') {
          try {
            value = value ? format(new Date(value), 'dd/MM/yyyy', { locale: ptBR }) : ''
          } catch {
            value = value || ''
          }
        }

        if (colId === 'tracking_status') {
          const statusMap: any = {
            'preparacao': 'Preparação',
            'transito': 'Trânsito',
            'aduana_origem': 'Aduana Origem',
            'canal_vermelho': 'Canal Vermelho',
            'aduana_destino': 'Aduana Destino',
            'entrega': 'Em Trânsito para Entrega',
            'entregue': 'Entregue',
          }
          value = statusMap[value as string] || value
        }

        html += `<td>${value || '-'}</td>`
      })
      html += '</tr>'
    })

    html += '</tbody></table></body></html>'

    printWindow.document.write(html)
    printWindow.document.close()
    printWindow.print()
    setIsOpen(false)
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="default" className="gap-2">
          <FileSpreadsheet className="w-4 h-4" />
          Gerar Relatório
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Gerar Relatório de Viagens</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <Card className="p-4 bg-muted/50">
            <p className="text-sm">
              <strong>{trips.length}</strong> viagem(ns) será(ão) incluída(s) no relatório
            </p>
          </Card>

          <div className="space-y-3">
            <Label className="text-base font-semibold">Selecione as colunas para incluir:</Label>
            <div className="grid grid-cols-2 gap-3 max-h-80 overflow-y-auto p-4 border rounded-lg">
              {columns.map((column) => (
                <div key={column.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={column.id}
                    checked={selectedColumns.includes(column.id)}
                    onCheckedChange={() => toggleColumn(column.id)}
                  />
                  <label
                    htmlFor={column.id}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {column.label}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-3">
            <Button 
              onClick={generateExcelReport} 
              className="flex-1 gap-2"
              disabled={selectedColumns.length === 0}
            >
              <Download className="w-4 h-4" />
              Exportar Excel
            </Button>
            <Button 
              onClick={printReport} 
              variant="outline"
              className="flex-1 gap-2"
              disabled={selectedColumns.length === 0}
            >
              <Printer className="w-4 h-4" />
              Imprimir
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
