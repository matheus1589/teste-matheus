"use client"

import { Button } from "@/components/ui/button"
import { Download, RotateCcw } from "lucide-react"
import { jsPDF } from "jspdf"

interface DocumentPreviewProps {
  processedImage: string | null
  onReset: () => void
}

export function DocumentPreview({ processedImage, onReset }: DocumentPreviewProps) {
  const handleDownloadPDF = async () => {
    if (!processedImage) return

    const img = new Image()
    img.src = processedImage

    img.onload = () => {
      // Create PDF with image dimensions
      const imgWidth = img.width
      const imgHeight = img.height

      // Calculate PDF dimensions (A4 ratio)
      const pdfWidth = 210 // A4 width in mm
      const pdfHeight = (imgHeight * pdfWidth) / imgWidth

      const pdf = new jsPDF({
        orientation: pdfHeight > pdfWidth ? "portrait" : "landscape",
        unit: "mm",
        format: [pdfWidth, pdfHeight],
      })

      pdf.addImage(processedImage, "JPEG", 0, 0, pdfWidth, pdfHeight)
      pdf.save(`documento-${Date.now()}.pdf`)
    }
  }

  const handleDownloadImage = () => {
    if (!processedImage) return

    const link = document.createElement("a")
    link.href = processedImage
    link.download = `documento-${Date.now()}.jpg`
    link.click()
  }

  return (
    <div className="space-y-4">
      <div className="relative border-2 border-border rounded-lg overflow-hidden bg-muted min-h-[400px] flex items-center justify-center">
        {processedImage ? (
          <img src={processedImage || "/placeholder.svg"} alt="Documento processado" className="w-full h-auto" />
        ) : (
          <div className="text-center p-8">
            <p className="text-muted-foreground">O documento processado aparecerá aqui</p>
          </div>
        )}
      </div>

      {processedImage && (
        <div className="space-y-3">
          <Button onClick={handleDownloadPDF} className="w-full" size="lg">
            <Download className="w-5 h-5 mr-2" />
            Baixar PDF
          </Button>
          <Button onClick={handleDownloadImage} variant="outline" className="w-full bg-transparent" size="lg">
            <Download className="w-5 h-5 mr-2" />
            Baixar Imagem
          </Button>
          <Button onClick={onReset} variant="outline" className="w-full bg-transparent">
            <RotateCcw className="w-4 h-4 mr-2" />
            Novo Documento
          </Button>
        </div>
      )}
    </div>
  )
}
