import Link from "next/link"
import Image from "next/image"
import { Phone, Mail, MapPin, Facebook, Instagram, Linkedin } from 'lucide-react'

export function SiteFooter() {
  return (
    <footer className="bg-[#1a1a1a] text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12 mb-12">
          {/* Company Info */}
          <div className="space-y-6">
            <div className="relative h-12 w-40 bg-white/10 rounded p-2">
              <Image 
                src="/images/inlog-logo.png" 
                alt="INLOG Logo" 
                fill
                className="object-contain p-1"
              />
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              INLOG é uma empresa de logística em constante busca de alternativas inovadoras, fornecendo serviços de armazém geral e transporte rodoviário confiáveis e rápidos.
            </p>
            <div className="flex gap-4">
              <Link href="#" className="bg-white/10 p-2 rounded-full hover:bg-[#005f8f] transition-colors">
                <Facebook className="h-4 w-4" />
              </Link>
              <Link href="#" className="bg-white/10 p-2 rounded-full hover:bg-[#005f8f] transition-colors">
                <Instagram className="h-4 w-4" />
              </Link>
              <Link href="#" className="bg-white/10 p-2 rounded-full hover:bg-[#005f8f] transition-colors">
                <Linkedin className="h-4 w-4" />
              </Link>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-6 border-b border-[#005f8f] pb-2 inline-block">Links Rápidos</h3>
            <ul className="space-y-3 text-gray-400 text-sm">
              <li><Link href="/" className="hover:text-[#005f8f] transition-colors">Home</Link></li>
              <li><Link href="/quem-somos" className="hover:text-[#005f8f] transition-colors">Quem Somos</Link></li>
              <li><Link href="/servicos" className="hover:text-[#005f8f] transition-colors">Serviços</Link></li>
              <li><Link href="/cotacao" className="hover:text-[#005f8f] transition-colors">Solicitar Cotação</Link></li>
              <li><Link href="/portal" className="hover:text-[#005f8f] transition-colors">Portal do Cliente</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-bold mb-6 border-b border-[#005f8f] pb-2 inline-block">Nossos Serviços</h3>
            <ul className="space-y-3 text-gray-400 text-sm">
              <li>Transporte Rodoviário</li>
              <li>Armazenagem</li>
              <li>Transporte Internacional</li>
              <li>Cargas Químicas</li>
              <li>Projetos Logísticos</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-bold mb-6 border-b border-[#005f8f] pb-2 inline-block">Contato</h3>
            <ul className="space-y-4 text-gray-400 text-sm">
              <li className="flex gap-3">
                <MapPin className="h-5 w-5 text-[#005f8f] shrink-0 mt-0.5" />
                <span className="break-words">Rua Jose Geraldino Bittencourt 4001, Pedra de Amolar, Ilhota – SC</span>
              </li>
              <li className="flex gap-3">
                <Phone className="h-5 w-5 text-[#005f8f] shrink-0" />
                <span>+55 (47) 3343 7864</span>
              </li>
              <li className="flex gap-3">
                <Mail className="h-5 w-5 text-[#005f8f] shrink-0" />
                <span className="break-all">contato@inlog.biz</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} INLOG Integração Logística. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
