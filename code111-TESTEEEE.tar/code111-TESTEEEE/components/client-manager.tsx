"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { UserPlus, Edit, Trash2, Users } from 'lucide-react'
import { toast } from "sonner"

interface ClientUser {
  id: string
  username: string
  full_name: string
  email: string
  exportador: string
  importador: string
  is_active: boolean
  created_at: string
}

export function ClientManager() {
  const [clients, setClients] = useState<ClientUser[]>([])
  const [loading, setLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingClient, setEditingClient] = useState<ClientUser | null>(null)
  
  // Form fields
  const [username, setUsername] = useState("")
  const [fullName, setFullName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [exportador, setExportador] = useState("")
  const [importador, setImportador] = useState("")
  
  const supabase = createClient()

  useEffect(() => {
    loadClients()
  }, [])

  const loadClients = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('client_users')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error
      setClients(data || [])
    } catch (error) {
      console.error('Error loading clients:', error)
      toast.error('Erro ao carregar clientes')
    } finally {
      setLoading(false)
    }
  }

  const resetForm = () => {
    setUsername("")
    setFullName("")
    setEmail("")
    setPassword("")
    setExportador("")
    setImportador("")
    setEditingClient(null)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!username.trim() || !fullName.trim() || !email.trim()) {
      toast.error("Preencha todos os campos obrigatórios (usuário, nome e e-mail)")
      return
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email.trim())) {
      toast.error("Digite um e-mail válido")
      return
    }

    if (!editingClient && !password.trim()) {
      toast.error("Senha é obrigatória para novo cliente")
      return
    }

    try {
      if (editingClient) {
        // Update existing client
        const updateData: any = {
          full_name: fullName.trim(),
          email: email.trim().toLowerCase(),
          exportador: exportador.trim() || null,
          importador: importador.trim() || null,
          updated_at: new Date().toISOString()
        }

        if (password.trim()) {
          updateData.password_hash = password.trim()
        }

        const { data, error } = await supabase
          .from('client_users')
          .update(updateData)
          .eq('id', editingClient.id)
          .select()

        if (error) throw error
        toast.success("Cliente atualizado com sucesso!")
      } else {
        // Create new client
        const insertData = {
          username: username.trim().toLowerCase(),
          password_hash: password.trim(),
          full_name: fullName.trim(),
          email: email.trim().toLowerCase(),
          exportador: exportador.trim() || null,
          importador: importador.trim() || null,
          is_active: true
        }

        const { data, error } = await supabase
          .from('client_users')
          .insert(insertData)
          .select()

        if (error) throw error
        toast.success("Cliente cadastrado com sucesso!")
      }

      resetForm()
      setIsDialogOpen(false)
      await loadClients()
    } catch (error: any) {
      console.error('Error saving client:', error)
      if (error.code === '23505') {
        toast.error("Este nome de usuário já existe")
      } else {
        toast.error(`Erro ao salvar cliente: ${error.message || 'Erro desconhecido'}`)
      }
    }
  }

  const handleEdit = (client: ClientUser) => {
    setEditingClient(client)
    setUsername(client.username)
    setFullName(client.full_name || "")
    setEmail(client.email || "")
    setExportador(client.exportador || "")
    setImportador(client.importador || "")
    setPassword("")
    setIsDialogOpen(true)
  }

  const handleDelete = async (clientId: string) => {
    if (!confirm("Tem certeza que deseja excluir este cliente?")) return

    try {
      const { error } = await supabase
        .from('client_users')
        .delete()
        .eq('id', clientId)

      if (error) throw error
      toast.success("Cliente excluído com sucesso!")
      loadClients()
    } catch (error) {
      console.error('Error deleting client:', error)
      toast.error("Erro ao excluir cliente")
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="w-6 h-6 text-primary" />
          <h2 className="text-2xl font-bold">Gerenciar Clientes</h2>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open)
          if (!open) resetForm()
        }}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <UserPlus className="w-4 h-4" />
              Novo Cliente
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingClient ? "Editar Cliente" : "Cadastrar Novo Cliente"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Nome de Usuário *</Label>
                  <Input
                    id="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="usuario123"
                    disabled={!!editingClient}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fullName">Nome Completo *</Label>
                  <Input
                    id="fullName"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="João Silva"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-mail *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="cliente@example.com"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">
                    Senha {editingClient ? "(deixe vazio para não alterar)" : "*"}
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Digite a senha"
                    required={!editingClient}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="exportador">Exportador (Filtro de Acesso)</Label>
                <Textarea
                  id="exportador"
                  value={exportador}
                  onChange={(e) => setExportador(e.target.value)}
                  placeholder="Ex: EMPRESA ABC, EMPRESA XYZ (separado por vírgula)"
                  rows={2}
                />
                <p className="text-xs text-muted-foreground">
                  Cliente verá apenas viagens destes exportadores (deixe vazio para ver todos)
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="importador">Importador (Filtro de Acesso)</Label>
                <Textarea
                  id="importador"
                  value={importador}
                  onChange={(e) => setImportador(e.target.value)}
                  placeholder="Ex: IMPORTADORA A, IMPORTADORA B (separado por vírgula)"
                  rows={2}
                />
                <p className="text-xs text-muted-foreground">
                  Cliente verá apenas viagens destes importadores (deixe vazio para ver todos)
                </p>
              </div>

              <div className="flex gap-2 pt-4">
                <Button type="submit" className="flex-1">
                  {editingClient ? "Atualizar" : "Cadastrar"}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    resetForm()
                    setIsDialogOpen(false)
                  }}
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <p className="text-center text-muted-foreground">Carregando clientes...</p>
      ) : (
        <div className="grid gap-4">
          {clients.map((client) => (
            <Card key={client.id} className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{client.full_name}</h3>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      client.is_active 
                        ? 'bg-green-100 text-green-700 dark:bg-green-950/20 dark:text-green-400'
                        : 'bg-red-100 text-red-700 dark:bg-red-950/20 dark:text-red-400'
                    }`}>
                      {client.is_active ? 'Ativo' : 'Inativo'}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    <strong>Usuário:</strong> {client.username}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    <strong>E-mail:</strong> {client.email || 'Não cadastrado'}
                  </p>
                  {client.exportador && (
                    <p className="text-sm text-muted-foreground">
                      <strong>Exportadores:</strong> {client.exportador}
                    </p>
                  )}
                  {client.importador && (
                    <p className="text-sm text-muted-foreground">
                      <strong>Importadores:</strong> {client.importador}
                    </p>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleEdit(client)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => handleDelete(client.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {!loading && clients.length === 0 && (
        <Card className="p-12 text-center">
          <Users className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Nenhum cliente cadastrado</h3>
          <p className="text-muted-foreground mb-4">
            Comece cadastrando seu primeiro cliente
          </p>
        </Card>
      )}
    </div>
  )
}
