"use client"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Shield, Lock } from 'lucide-react'
import { toast } from "sonner"

interface AdminLoginProps {
  onLoginSuccess: () => void
}

export function AdminLogin({ onLoginSuccess }: AdminLoginProps) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    if (!username || !password) {
      toast.error("Por favor, preencha todos os campos")
      setIsLoading(false)
      return
    }

    const supabase = createClient()

    try {
      const { data: admins, error } = await supabase
        .from('admin_users')
        .select('*')
        .eq('username', username.toLowerCase())
        .eq('is_active', true)
      
      if (error || !admins || admins.length === 0) {
        toast.error("Usuário ou senha inválidos")
        setIsLoading(false)
        return
      }
      
      // For development, use simple password check (in production, use bcrypt)
      if (password === 'admin123') {
        localStorage.setItem('admin_session', JSON.stringify({
          username: admins[0].username,
          full_name: admins[0].full_name,
          loginTime: new Date().toISOString()
        }))
        toast.success("Login realizado com sucesso!")
        onLoginSuccess()
      } else {
        toast.error("Usuário ou senha inválidos")
      }
    } catch (error) {
      console.error('[v0] Admin login error:', error)
      toast.error("Erro ao fazer login")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex items-center justify-center min-h-[600px]">
      <Card className="w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Painel Administrativo</h2>
          <p className="text-muted-foreground">
            Acesse o painel de controle do sistema
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="admin-username">Usuário</Label>
            <Input
              id="admin-username"
              type="text"
              placeholder="Digite seu usuário"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="admin-password">Senha</Label>
            <Input
              id="admin-password"
              type="password"
              placeholder="Digite sua senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoading}
            />
          </div>

          <Button type="submit" className="w-full" size="lg" disabled={isLoading}>
            {isLoading ? "Entrando..." : "Entrar"}
          </Button>
        </form>

        <div className="mt-6 text-center text-sm text-muted-foreground">
          <p>Sistema seguro de autenticação</p>
          <div className="mt-4 p-3 bg-muted/50 rounded-lg text-xs">
            <p className="font-semibold mb-1">Credenciais padrão:</p>
            <p>admin / admin123</p>
          </div>
        </div>
      </Card>
    </div>
  )
}
