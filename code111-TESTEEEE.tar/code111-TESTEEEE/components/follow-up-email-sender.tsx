"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Mail, Send, CheckCircle2, XCircle, Loader2, Users } from 'lucide-react'
import { toast } from "sonner"

interface ClientUser {
  id: string
  username: string
  full_name: string
  email: string
  exportador: string
  importador: string
}

interface Trip {
  id: string
  crt: string
  client_reference: string
  origem: string
  destino: string
  driver_name: string
  tracking_status: string
  tracking_details: any[]
  exportador: string
  importador: string
  client_username: string
}

interface EmailResult {
  crt: string
  success: boolean
  message: string
}

export function FollowUpEmailSender() {
  const [clients, setClients] = useState<ClientUser[]>([])
  const [selectedClient, setSelectedClient] = useState<string>("")
  const [loading, setLoading] = useState(false)
  const [sending, setSending] = useState(false)
  const [results, setResults] = useState<EmailResult[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  
  const supabase = createClient()

  useEffect(() => {
    loadClients()
  }, [])

  const loadClients = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('client_users')
        .select('*')
        .eq('is_active', true)
        .order('full_name')

      if (error) throw error
      setClients(data || [])
    } catch (error) {
      console.error('[v0] Error loading clients:', error)
      toast.error('Erro ao carregar clientes')
    } finally {
      setLoading(false)
    }
  }

  const getClientTrips = async (clientUsername: string, clientExportador: string, clientImportador: string) => {
    try {
      let query = supabase
        .from('trips')
        .select('*')
        .order('created_at', { ascending: false })

      // Apply client filters
      if (clientExportador) {
        const exportadores = clientExportador.split(',').map(e => e.trim())
        query = query.in('exportador', exportadores)
      }

      if (clientImportador) {
        const importadores = clientImportador.split(',').map(i => i.trim())
        query = query.in('importador', importadores)
      }

      const { data, error } = await query

      if (error) throw error
      return data || []
    } catch (error) {
      console.error('[v0] Error loading client trips:', error)
      return []
    }
  }

  const handleSendFollowUps = async () => {
    if (!selectedClient) {
      toast.error("Selecione um cliente")
      return
    }

    const client = clients.find(c => c.username === selectedClient)
    if (!client) {
      toast.error("Cliente não encontrado")
      return
    }

    if (!client.email) {
      toast.error("Cliente não possui e-mail cadastrado")
      return
    }

    setSending(true)
    setResults([])

    try {
      // Get all trips for this client
      const trips = await getClientTrips(
        client.username,
        client.exportador,
        client.importador
      )

      if (trips.length === 0) {
        toast.error("Nenhuma viagem encontrada para este cliente")
        setSending(false)
        return
      }

      toast.info(`Enviando ${trips.length} e-mail(s)...`)
      const emailResults: EmailResult[] = []

      // Send one email per trip
      for (const trip of trips) {
        try {
          const response = await fetch('/api/send-follow-up', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              clientEmail: client.email,
              clientName: client.full_name,
              trip: {
                crt: trip.crt,
                client_reference: trip.client_reference,
                origem: trip.origem,
                destino: trip.destino,
                driver_name: trip.driver_name,
                tracking_status: trip.tracking_status,
                tracking_details: trip.tracking_details,
                exportador: trip.exportador,
                importador: trip.importador,
              }
            }),
          })

          const result = await response.json()

          emailResults.push({
            crt: trip.crt,
            success: response.ok,
            message: result.message || (response.ok ? 'E-mail enviado' : 'Erro ao enviar')
          })

          // Small delay between emails to avoid rate limiting
          await new Promise(resolve => setTimeout(resolve, 500))
        } catch (error) {
          console.error('[v0] Error sending email for trip:', trip.crt, error)
          emailResults.push({
            crt: trip.crt,
            success: false,
            message: 'Erro ao enviar e-mail'
          })
        }
      }

      setResults(emailResults)
      
      const successCount = emailResults.filter(r => r.success).length
      const failedCount = emailResults.length - successCount

      if (successCount === emailResults.length) {
        toast.success(`Todos os ${successCount} e-mails foram enviados com sucesso!`)
      } else if (successCount > 0) {
        toast.warning(`${successCount} e-mail(s) enviado(s), ${failedCount} falhou(ram)`)
      } else {
        toast.error(`Falha ao enviar todos os e-mails`)
      }

    } catch (error) {
      console.error('[v0] Error sending follow-ups:', error)
      toast.error('Erro ao enviar follow-ups')
    } finally {
      setSending(false)
    }
  }

  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2" variant="outline">
          <Mail className="w-4 h-4" />
          Disparar Follow-Up por E-mail
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-primary" />
            Enviar Follow-Up por E-mail
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
            <p className="text-sm text-blue-800 dark:text-blue-200">
              Esta função envia um e-mail separado para cada viagem do cliente selecionado,
              contendo todas as informações de rastreamento e status atualizado.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="client-select">Selecionar Cliente</Label>
            <Select 
              value={selectedClient} 
              onValueChange={setSelectedClient}
              disabled={loading || sending}
            >
              <SelectTrigger id="client-select">
                <SelectValue placeholder="Escolha um cliente" />
              </SelectTrigger>
              <SelectContent>
                {clients.map((client) => (
                  <SelectItem key={client.id} value={client.username}>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      <span>{client.full_name}</span>
                      <span className="text-xs text-muted-foreground">({client.email})</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {clients.length === 0 && !loading && (
              <p className="text-sm text-muted-foreground">
                Nenhum cliente ativo encontrado
              </p>
            )}
          </div>

          <Button
            onClick={handleSendFollowUps}
            disabled={!selectedClient || sending}
            className="w-full gap-2"
            size="lg"
          >
            {sending ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Enviando E-mails...
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                Enviar Follow-Ups
              </>
            )}
          </Button>

          {results.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between pt-4 border-t">
                <h3 className="font-semibold">Resultados do Envio</h3>
                <div className="flex gap-4 text-sm">
                  <span className="text-green-600 dark:text-green-400">
                    ✓ {results.filter(r => r.success).length} enviados
                  </span>
                  <span className="text-red-600 dark:text-red-400">
                    ✗ {results.filter(r => !r.success).length} falhas
                  </span>
                </div>
              </div>

              <div className="max-h-60 overflow-y-auto space-y-2">
                {results.map((result, index) => (
                  <Card key={index} className={`p-3 ${
                    result.success 
                      ? 'bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800'
                      : 'bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800'
                  }`}>
                    <div className="flex items-center gap-3">
                      {result.success ? (
                        <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">CRT: {result.crt}</p>
                        <p className="text-xs text-muted-foreground">{result.message}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
