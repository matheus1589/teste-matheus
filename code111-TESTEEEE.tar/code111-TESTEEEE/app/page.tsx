import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Truck, Package, Globe, ShieldCheck, Clock, BarChart3 } from 'lucide-react'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"

export default function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <SiteHeader />

      <main className="flex-1">
        {/* Hero Section */}
        <section id="home" className="relative py-12 sm:py-20 md:py-32 bg-slate-900 text-white overflow-hidden">
          <div className="absolute inset-0 z-0 opacity-40">
            <Image
              src="/logistics-truck-warehouse.jpg"
              alt="Background"
              fill
              className="object-cover"
              priority
            />
          </div>
          <div className="container relative z-10 mx-auto px-4 text-center">
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 sm:mb-6 tracking-tight">
              Transportadora Internacional,<br className="hidden sm:block" />
              Operador Logístico e Armazém
            </h1>
            <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-slate-200 mb-6 sm:mb-10 max-w-3xl mx-auto px-4">
              Serviços de transporte rodoviário e armazenagem de químicos e cargas secas com excelência e segurança.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center px-4">
              <Link href="/cotacao">
                <Button size="lg" className="w-full sm:w-auto text-base sm:text-lg px-6 sm:px-8 bg-[#005f8f] hover:bg-[#004b73] text-white border-none">
                  Obter Cotação Grátis
                </Button>
              </Link>
              <Link href="/portal">
                <Button size="lg" variant="outline" className="w-full sm:w-auto text-base sm:text-lg px-6 sm:px-8 bg-white/10 hover:bg-white/20 border-white text-white">
                  Acessar Portal do Cliente
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="py-12 sm:py-16 md:py-20 bg-slate-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10 sm:mb-16">
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-slate-900 mb-3 sm:mb-4">Nossos Serviços</h2>
              <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto px-4">
                Soluções completas em logística para impulsionar o seu negócio
              </p>
            </div>

            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 sm:gap-8">
              <div className="bg-white p-6 sm:p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-slate-100">
                <div className="w-12 h-12 sm:w-14 sm:h-14 bg-blue-100 rounded-lg flex items-center justify-center mb-4 sm:mb-6">
                  <Truck className="w-6 h-6 sm:w-7 sm:h-7 text-[#005f8f]" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3">Transporte Rodoviário</h3>
                <p className="text-sm sm:text-base text-slate-600">
                  Transporte de cargas secas e produtos químicos com frota moderna e rastreada em tempo real.
                </p>
              </div>

              <div className="bg-white p-6 sm:p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-slate-100">
                <div className="w-12 h-12 sm:w-14 sm:h-14 bg-blue-100 rounded-lg flex items-center justify-center mb-4 sm:mb-6">
                  <Package className="w-6 h-6 sm:w-7 sm:h-7 text-[#005f8f]" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3">Armazenagem</h3>
                <p className="text-sm sm:text-base text-slate-600">
                  Estrutura completa para armazenagem geral e de produtos químicos, com gestão WMS.
                </p>
              </div>

              <div className="bg-white p-6 sm:p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-slate-100 sm:col-span-2 md:col-span-1">
                <div className="w-12 h-12 sm:w-14 sm:h-14 bg-blue-100 rounded-lg flex items-center justify-center mb-4 sm:mb-6">
                  <Globe className="w-6 h-6 sm:w-7 sm:h-7 text-[#005f8f]" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3">Logística Internacional</h3>
                <p className="text-sm sm:text-base text-slate-600">
                  Atuação no Mercosul com filiais e pontos de apoio estratégicos na Argentina, Chile e Uruguai.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-12 sm:py-16 md:py-20">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-8 sm:gap-12 items-center">
              <div className="relative h-64 sm:h-80 md:h-[500px] rounded-2xl overflow-hidden order-2 md:order-1">
                <Image
                  src="/logistics-worker-tablet.jpg"
                  alt="Logistics Operations"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="order-1 md:order-2">
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-slate-900 mb-6 sm:mb-8">Por que escolher a Inlog?</h2>
                
                <div className="space-y-6 sm:space-y-8">
                  <div className="flex gap-3 sm:gap-4">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 sm:w-12 sm:h-12 bg-green-100 rounded-full flex items-center justify-center">
                        <ShieldCheck className="w-5 h-5 sm:w-6 sm:h-6 text-green-600" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg sm:text-xl font-bold mb-1 sm:mb-2">Consistência</h3>
                      <p className="text-sm sm:text-base text-slate-600">
                        Foco em baixa sinistralidade, cumprimento de prazos e pontualidade nas entregas.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3 sm:gap-4">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <Clock className="w-5 h-5 sm:w-6 sm:h-6 text-[#005f8f]" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg sm:text-xl font-bold mb-1 sm:mb-2">Disponibilidade</h3>
                      <p className="text-sm sm:text-base text-slate-600">
                        Alta disponibilidade de unidades de carga e transparência operacional.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3 sm:gap-4">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 sm:w-12 sm:h-12 bg-purple-100 rounded-full flex items-center justify-center">
                        <BarChart3 className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg sm:text-xl font-bold mb-1 sm:mb-2">Competitividade</h3>
                      <p className="text-sm sm:text-base text-slate-600">
                        Melhoria contínua de processos e alinhamento com as necessidades do seu negócio.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-12 sm:py-16 md:py-20 bg-slate-900 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-6 sm:mb-8">Conheça a Inlog</h2>
            <p className="text-base sm:text-lg text-slate-300 max-w-4xl mx-auto mb-8 sm:mb-12 leading-relaxed px-4">
              A INLOG é uma empresa de logística em constante busca de alternativas inovadoras. 
              Fornecemos serviços de armazém geral e transporte rodoviário confiáveis e rápidos, 
              garantindo excelência independentemente do destino. Contamos com estrutura preparada 
              para oferecer uma ampla gama de serviços complementares.
            </p>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-8 max-w-4xl mx-auto mt-12 sm:mt-16">
              <div className="p-3 sm:p-4 border border-slate-700 rounded-lg">
                <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-[#005f8f] mb-1 sm:mb-2">+15</div>
                <div className="text-xs sm:text-sm text-slate-400">Anos de Experiência</div>
              </div>
              <div className="p-3 sm:p-4 border border-slate-700 rounded-lg">
                <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-[#005f8f] mb-1 sm:mb-2">+500</div>
                <div className="text-xs sm:text-sm text-slate-400">Clientes Atendidos</div>
              </div>
              <div className="p-3 sm:p-4 border border-slate-700 rounded-lg">
                <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-[#005f8f] mb-1 sm:mb-2">100%</div>
                <div className="text-xs sm:text-sm text-slate-400">Frota Rastreada</div>
              </div>
              <div className="p-3 sm:p-4 border border-slate-700 rounded-lg">
                <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-[#005f8f] mb-1 sm:mb-2">4</div>
                <div className="text-xs sm:text-sm text-slate-400">Países Atendidos</div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section id="faq" className="py-12 sm:py-16 md:py-20 bg-slate-50">
          <div className="container mx-auto px-4 max-w-3xl">
            <div className="text-center mb-8 sm:mb-12">
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-slate-900 mb-3 sm:mb-4">Dúvidas Frequentes</h2>
              <p className="text-sm sm:text-base text-slate-600 px-4">Respostas para as principais perguntas de nossos clientes</p>
            </div>

            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger className="text-left text-sm sm:text-base">Quais tipos de transportes vocês operam?</AccordionTrigger>
                <AccordionContent className="text-sm sm:text-base">
                  Operamos com transporte rodoviário de carga, transporte de contêineres, transporte de produtos químicos e transporte internacional.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger className="text-left text-sm sm:text-base">Vocês atendem fora do país?</AccordionTrigger>
                <AccordionContent className="text-sm sm:text-base">
                  Sim, temos pontos estratégicos internacionais. Além da matriz em Ilhota/SC e filial em São Paulo, temos presença em Uruguaiana, Paso de los Libres (ARG), Santana do Livramento, São Borja, Los Andes (CL), Buenos Aires (ARG) e Chuy.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger className="text-left text-sm sm:text-base">A frota de vocês é 100% rastreada?</AccordionTrigger>
                <AccordionContent className="text-sm sm:text-base">
                  Sim, toda a nossa frota é rastreável e contamos com a tecnologia de sistema WMS, oferecendo transparência e controle total de todas as operações logísticas.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger className="text-left text-sm sm:text-base">Vocês trabalham com armazenagem de químicos?</AccordionTrigger>
                <AccordionContent className="text-sm sm:text-base">
                  Sim, somos especializados no transporte e armazenagem de produtos químicos, possuindo todas as licenças necessárias e recursos altamente especializados para garantir a segurança.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </section>

        {/* Certifications */}
        <section className="py-8 sm:py-12 border-t">
          <div className="container mx-auto px-4">
            <p className="text-center text-slate-500 mb-6 sm:mb-8 font-medium text-xs sm:text-sm">CERTIFICAÇÕES E PARCEIROS</p>
            <div className="flex flex-wrap justify-center items-center gap-6 sm:gap-8 md:gap-12 grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all duration-300">
              <Image src="/images/certifications/sassmaq.jpg" alt="SASSMAQ" width={80} height={48} className="h-8 sm:h-10 md:h-12 w-auto object-contain" />
              <Image src="/images/certifications/iso.jpg" alt="ISO 9001" width={80} height={48} className="h-8 sm:h-10 md:h-12 w-auto object-contain" />
              <Image src="/images/certifications/ibama.jpg" alt="IBAMA" width={80} height={48} className="h-8 sm:h-10 md:h-12 w-auto object-contain" />
              <Image src="/images/certifications/anvisa.jpg" alt="ANVISA" width={80} height={48} className="h-8 sm:h-10 md:h-12 w-auto object-contain" />
              <Image src="/images/certifications/policia-federal.jpg" alt="Polícia Federal" width={80} height={48} className="h-8 sm:h-10 md:h-12 w-auto object-contain" />
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  )
}
