import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { QuotationForm } from "@/components/quotation-form"

export default function QuotationPage() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <SiteHeader />
      
      <main className="flex-1">
        {/* Hero Section */}
        <div className="bg-[#005f8f] text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl font-bold mb-4">Solicite uma Cotação</h1>
            <p className="text-xl text-blue-100 max-w-2xl mx-auto">
              Preencha o formulário abaixo e receba uma proposta personalizada para sua necessidade logística.
            </p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-12 -mt-8">
          <QuotationForm />
        </div>

        {/* Info Section */}
        <div className="container mx-auto px-4 py-12 mb-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="font-bold text-lg mb-2 text-[#005f8f]">Atendimento Rápido</h3>
              <p className="text-gray-600">Nossa equipe comercial retornará seu contato em até 24 horas úteis.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="font-bold text-lg mb-2 text-[#005f8f]">Soluções Personalizadas</h3>
              <p className="text-gray-600">Analisamos sua necessidade para oferecer o melhor custo-benefício.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="font-bold text-lg mb-2 text-[#005f8f]">Cobertura Nacional</h3>
              <p className="text-gray-600">Atendemos todo o território nacional e transporte internacional (Mercosul).</p>
            </div>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
