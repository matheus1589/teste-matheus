export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get("q")

  if (!query || query.length < 3) {
    return Response.json({ error: "Query too short" }, { status: 400 })
  }

  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&countrycodes=br&limit=5`,
      {
        headers: {
          "User-Agent": "Coleta-Transport-App/1.0",
        },
      },
    )

    if (!response.ok) {
      return Response.json({ error: "Search failed" }, { status: response.status })
    }

    const data = await response.json()
    return Response.json(data)
  } catch (error) {
    console.error("[v0] Search address error:", error)
    return Response.json({ error: "Internal server error" }, { status: 500 })
  }
}
