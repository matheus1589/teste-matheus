import { NextRequest, NextResponse } from 'next/server'
import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)

async function sendEmail(to: string, subject: string, html: string) {
  try {
    const { data, error } = await resend.emails.send({
      from: 'INLOG <onboarding@resend.dev>',
      to: [to],
      subject,
      html,
    })
    
    if (error) {
      throw error
    }
    
    return data
  } catch (error: any) {
    console.error('Initial email send failed:', error)

    // Check if it's the testing limitation error
    // The error might come as a thrown object with a message, or a structured error object
    const errorMessage = error.message || error.name || JSON.stringify(error)
    
    if (
      errorMessage.includes('only send testing emails to your own email address') || 
      (error.statusCode === 403 && error.name === 'validation_error')
    ) {
      console.log('Resend testing limitation detected. Falling back to allowed email.')
      
      // Extract the allowed email from the error message if possible
      // The error message usually contains: "... (email@example.com) ..."
      const match = errorMessage.match(/$$([^)]+@\S+)$$/)
      const allowedEmail = match ? match[1] : 'matheus.logisticacmn@gmail.com'
      
      // Add a notice to the email body
      const testingHtml = `
        <div style="background-color: #fee2e2; border: 1px solid #ef4444; color: #b91c1c; padding: 12px; margin-bottom: 16px; border-radius: 4px; text-align: center; font-family: sans-serif;">
          <strong>MODO DE TESTE:</strong> Este e-mail foi redirecionado porque o domínio não foi verificado.<br>
          Destinatário original: ${to}
        </div>
        ${html}
      `
      
      // Try sending to the allowed email
      try {
        const { data: fallbackData, error: fallbackError } = await resend.emails.send({
          from: 'INLOG <onboarding@resend.dev>',
          to: [allowedEmail],
          subject: `[TESTE] ${subject}`,
          html: testingHtml,
        })

        if (fallbackError) {
          throw fallbackError
        }

        return fallbackData
      } catch (retryError) {
        console.error('Fallback email send failed:', retryError)
        throw retryError
      }
    }
    
    throw error
  }
}

function formatStatus(status: string): string {
  const statusMap: Record<string, string> = {
    'preparacao': 'Preparação',
    'transito': 'Em Trânsito',
    'aduana_origem': 'Aduana Origem',
    'canal_vermelho': 'Canal Vermelho',
    'aduana_destino': 'Aduana Destino',
    'entrega': 'Em Trânsito para Entrega',
    'entregue': 'Entregue',
  }
  return statusMap[status] || status
}

function generateFollowUpEmail(clientName: string, trip: any): string {
  const trackingTimeline = trip.tracking_details && trip.tracking_details.length > 0
    ? trip.tracking_details.map((detail: any) => `
        <div style="padding: 12px; border-left: 3px solid #3b82f6; margin-bottom: 12px; background: #f8fafc;">
          <p style="margin: 0; font-weight: 600; color: #1e40af;">${formatStatus(detail.status)}</p>
          <p style="margin: 4px 0 0 0; font-size: 14px; color: #64748b;">${detail.details || 'Atualização de status'}</p>
          <p style="margin: 4px 0 0 0; font-size: 12px; color: #94a3b8;">
            ${new Date(detail.timestamp).toLocaleString('pt-BR')}
          </p>
        </div>
      `).join('')
    : '<p style="color: #64748b;">Nenhuma atualização de rastreamento disponível</p>'

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      </head>
      <body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f1f5f9;">
        <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff;">
          <!-- Header -->
          <div style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); padding: 32px; text-align: center;">
            <h1 style="margin: 0; color: #ffffff; font-size: 28px;">INLOG</h1>
            <p style="margin: 8px 0 0 0; color: #dbeafe; font-size: 14px;">Integração Logística</p>
          </div>

          <!-- Content -->
          <div style="padding: 32px;">
            <h2 style="margin: 0 0 16px 0; color: #1e293b; font-size: 20px;">
              Olá, ${clientName}!
            </h2>
            
            <p style="margin: 0 0 24px 0; color: #475569; font-size: 14px; line-height: 1.6;">
              Segue atualização sobre o status da sua viagem:
            </p>

            <!-- Trip Details -->
            <div style="background-color: #f8fafc; border-radius: 8px; padding: 20px; margin-bottom: 24px;">
              <table style="width: 100%; border-collapse: collapse;">
                <tr>
                  <td style="padding: 8px 0; color: #64748b; font-size: 14px; font-weight: 600;">CRT:</td>
                  <td style="padding: 8px 0; color: #1e293b; font-size: 14px;">${trip.crt}</td>
                </tr>
                ${trip.client_reference ? `
                <tr>
                  <td style="padding: 8px 0; color: #64748b; font-size: 14px; font-weight: 600;">Referência:</td>
                  <td style="padding: 8px 0; color: #1e293b; font-size: 14px;">${trip.client_reference}</td>
                </tr>
                ` : ''}
                <tr>
                  <td style="padding: 8px 0; color: #64748b; font-size: 14px; font-weight: 600;">Origem:</td>
                  <td style="padding: 8px 0; color: #1e293b; font-size: 14px;">${trip.origem}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #64748b; font-size: 14px; font-weight: 600;">Destino:</td>
                  <td style="padding: 8px 0; color: #1e293b; font-size: 14px;">${trip.destino}</td>
                </tr>
                ${trip.driver_name ? `
                <tr>
                  <td style="padding: 8px 0; color: #64748b; font-size: 14px; font-weight: 600;">Motorista:</td>
                  <td style="padding: 8px 0; color: #1e293b; font-size: 14px;">${trip.driver_name}</td>
                </tr>
                ` : ''}
                ${trip.exportador ? `
                <tr>
                  <td style="padding: 8px 0; color: #64748b; font-size: 14px; font-weight: 600;">Exportador:</td>
                  <td style="padding: 8px 0; color: #1e293b; font-size: 14px;">${trip.exportador}</td>
                </tr>
                ` : ''}
                <tr>
                  <td style="padding: 8px 0; color: #64748b; font-size: 14px; font-weight: 600;">Status Atual:</td>
                  <td style="padding: 8px 0;">
                    <span style="background-color: #dbeafe; color: #1e40af; padding: 4px 12px; border-radius: 12px; font-size: 13px; font-weight: 600;">
                      ${formatStatus(trip.tracking_status)}
                    </span>
                  </td>
                </tr>
              </table>
            </div>

            <!-- Tracking Timeline -->
            <div style="margin-bottom: 24px;">
              <h3 style="margin: 0 0 16px 0; color: #1e293b; font-size: 16px;">Histórico de Rastreamento:</h3>
              ${trackingTimeline}
            </div>

            <div style="background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 16px; border-radius: 4px; margin-bottom: 24px;">
              <p style="margin: 0; color: #92400e; font-size: 13px;">
                <strong>Importante:</strong> Para atualizações em tempo real, acesse o portal do cliente em nosso sistema.
              </p>
            </div>
          </div>

          <!-- Footer -->
          <div style="background-color: #f8fafc; padding: 24px; text-align: center; border-top: 1px solid #e2e8f0;">
            <p style="margin: 0; color: #64748b; font-size: 12px;">
              Este é um e-mail automático. Por favor, não responda.
            </p>
            <p style="margin: 8px 0 0 0; color: #64748b; font-size: 12px;">
              © ${new Date().getFullYear()} INLOG - Integração Logística. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </body>
    </html>
  `
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { clientEmail, clientName, trip } = body

    if (!clientEmail || !clientName || !trip) {
      return NextResponse.json(
        { error: 'Dados incompletos', message: 'E-mail, nome do cliente e dados da viagem são obrigatórios' },
        { status: 400 }
      )
    }

    const subject = `Follow-Up - Viagem CRT: ${trip.crt}`
    const html = generateFollowUpEmail(clientName, trip)

    try {
      await sendEmail(clientEmail, subject, html)
      
      return NextResponse.json({
        success: true,
        message: 'E-mail enviado com sucesso'
      })
    } catch (emailError: any) {
      console.error('Email sending failed:', emailError)
      return NextResponse.json(
        { 
          error: 'Erro ao enviar e-mail', 
          message: emailError.message || 'Falha ao enviar e-mail. Verifique a configuração do Resend.'
        },
        { status: 500 }
      )
    }
  } catch (error) {
    console.error('Error in send-follow-up API:', error)
    return NextResponse.json(
      { error: 'Erro ao processar solicitação', message: 'Ocorreu um erro ao processar a solicitação' },
      { status: 500 }
    )
  }
}
