import { createServerClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createServerClient(await cookies())
    const { collectionType, isChemical, documentUrl, documentFilename, extractedData, userEmail, ...otherFields } =
      await request.json()

    if (!userEmail) {
      console.error("[v0] Authentication failed: No user email provided")
      return NextResponse.json({ error: "Unauthorized - No user email" }, { status: 401 })
    }

    // Get client username using the email provided
    const { data: clientData, error: clientError } = await supabase
      .from("client_users")
      .select("username")
      .eq("email", userEmail)
      .single()

    if (clientError || !clientData) {
      console.error("[v0] Client lookup failed:", clientError?.message || "Client not found")
      return NextResponse.json({ error: "Client user not found" }, { status: 404 })
    }

    // Create collection request
    const { data, error } = await supabase
      .from("collection_requests")
      .insert({
        client_username: clientData.username,
        collection_type: collectionType,
        is_chemical: isChemical,
        document_url: documentUrl,
        document_filename: documentFilename,
        ...extractedData,
        status: "pendente",
      })
      .select()
      .single()

    if (error) {
      console.error("[v0] Collection request creation failed:", error)
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("[v0] API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
