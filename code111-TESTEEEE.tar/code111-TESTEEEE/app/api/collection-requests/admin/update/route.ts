import { createServerClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createServerClient(await cookies())
    const { collectionRequestId, status, rejectionReason, additionalInfoRequested, adminNotes } = await request.json()

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()
    if (userError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check if user is admin
    const { data: adminData } = await supabase
      .from("admin_users")
      .select("username")
      .eq("email", user.email)
      .eq("is_active", true)
      .single()

    if (!adminData) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Get current status
    const { data: currentRequest } = await supabase
      .from("collection_requests")
      .select("status")
      .eq("id", collectionRequestId)
      .single()

    // Update collection request
    const updateData: any = {
      status,
      admin_notes: adminNotes,
      updated_at: new Date().toISOString(),
    }

    if (status === "aprovada") {
      updateData.approved_at = new Date().toISOString()
      updateData.approved_by = adminData.username
    } else if (status === "rejeitada") {
      updateData.rejected_at = new Date().toISOString()
      updateData.rejected_reason = rejectionReason
      updateData.rejected_by = adminData.username
    } else if (status === "aguardando_info") {
      updateData.additional_info_requested = additionalInfoRequested
    }

    const { error: updateError } = await supabase
      .from("collection_requests")
      .update(updateData)
      .eq("id", collectionRequestId)

    if (updateError) {
      return NextResponse.json({ error: updateError.message }, { status: 400 })
    }

    // Log status change
    await supabase.from("collection_request_status_history").insert({
      collection_request_id: collectionRequestId,
      old_status: currentRequest?.status,
      new_status: status,
      reason: status === "rejeitada" ? rejectionReason : additionalInfoRequested,
      changed_by: adminData.username,
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
