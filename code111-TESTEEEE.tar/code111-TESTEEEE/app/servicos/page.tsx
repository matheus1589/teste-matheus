import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Truck, Warehouse, Globe, FlaskConical, Laptop } from 'lucide-react'
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function ServicesPage() {
  const services = [
    {
      icon: <Globe className="h-12 w-12 text-[#005f8f]" />,
      title: "Transporte Internacional",
      description: "Atuamos com transporte rodoviário internacional, conectando o Brasil aos países do Mercosul com agilidade e segurança. Possuímos filiais e pontos de apoio estratégicos na Argentina, Chile e Uruguai.",
    },
    {
      icon: <FlaskConical className="h-12 w-12 text-[#005f8f]" />,
      title: "Produtos Químicos",
      description: "Especialistas no transporte e armazenagem de produtos químicos. Possuímos todas as licenças necessárias (Polícia Federal, Exército, IBAMA, ANVISA) e equipe altamente treinada para manuseio seguro.",
    },
    {
      icon: <Warehouse className="h-12 w-12 text-[#005f8f]" />,
      title: "Armazenagem",
      description: "Estrutura completa de armazém geral em Itajaí/SC, oferecendo serviços de ova, desova, paletização, etiquetagem e gestão de estoque com sistema WMS integrado.",
    },
    {
      icon: <Truck className="h-12 w-12 text-[#005f8f]" />,
      title: "Transporte Rodoviário",
      description: "Frota moderna e diversificada para atender diferentes tipos de carga (seca, container, fracionada). Veículos 100% rastreados garantindo visibilidade total da operação.",
    },
    {
      icon: <Laptop className="h-12 w-12 text-[#005f8f]" />,
      title: "Tecnologia",
      description: "Investimento constante em tecnologia. Utilizamos sistemas avançados de TMS e WMS, permitindo integração de dados e informações em tempo real para nossos clientes.",
    },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      
      <main className="flex-1">
        {/* Hero Section */}
        <div className="bg-[#005f8f] text-white py-20">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Nossos Serviços</h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Soluções logísticas integradas para impulsionar o seu negócio com eficiência e segurança.
            </p>
          </div>
        </div>

        {/* Services Grid */}
        <div className="container mx-auto px-4 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-100">
                <div className="mb-6 bg-blue-50 w-20 h-20 rounded-full flex items-center justify-center">
                  {service.icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-4">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed mb-6">
                  {service.description}
                </p>
                <Link href="/cotacao">
                  <Button variant="outline" className="w-full border-[#005f8f] text-[#005f8f] hover:bg-[#005f8f] hover:text-white">
                    Solicitar Cotação
                  </Button>
                </Link>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gray-100 py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Precisa de uma solução personalizada?</h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Nossa equipe de especialistas está pronta para desenhar o projeto logístico ideal para sua empresa.
            </p>
            <Link href="/contato">
              <Button className="bg-[#005f8f] hover:bg-[#004b73] text-white text-lg px-8 py-6 h-auto">
                Fale com um Especialista
              </Button>
            </Link>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
