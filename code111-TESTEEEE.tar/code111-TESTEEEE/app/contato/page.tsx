import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { MapPin, Phone, Mail, Clock } from 'lucide-react'

export default function ContactPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      
      <main className="flex-1">
        {/* Hero Section */}
        <div className="bg-gray-900 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl font-bold mb-4">Entre em Contato</h1>
            <p className="text-xl text-gray-300">Estamos prontos para atender sua empresa</p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold text-[#005f8f] mb-6">Informações de Contato</h2>
                <p className="text-gray-600 mb-8">
                  Entre em contato conosco para tirar dúvidas, enviar sugestões ou solicitar informações sobre nossos serviços.
                </p>
              </div>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-blue-50 p-3 rounded-full">
                    <MapPin className="h-6 w-6 text-[#005f8f]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800">Matriz / Centro Logístico</h3>
                    <p className="text-gray-600">Rua Jose Geraldino Bittencourt 4001</p>
                    <p className="text-gray-600">Pedra de Amolar – Ilhota – SC</p>
                    <p className="text-gray-600">CEP 88320-000</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-blue-50 p-3 rounded-full">
                    <Phone className="h-6 w-6 text-[#005f8f]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800">Telefones</h3>
                    <p className="text-gray-600">+55 (47) 3343 7864</p>
                    <p className="text-gray-600">+55 (47) 3343 7886</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-blue-50 p-3 rounded-full">
                    <Mail className="h-6 w-6 text-[#005f8f]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800">E-mail</h3>
                    <p className="text-gray-600">contato@inlog.biz</p>
                    <p className="text-gray-600">comercial@inlog.biz</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-blue-50 p-3 rounded-full">
                    <Clock className="h-6 w-6 text-[#005f8f]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800">Horário de Atendimento</h3>
                    <p className="text-gray-600">Segunda a Sexta: 08:00 - 18:00</p>
                  </div>
                </div>
              </div>

              <div className="pt-8 border-t">
                <h3 className="font-bold text-gray-800 mb-4">Filial Uruguaiana</h3>
                <p className="text-gray-600">Av. Setembrino de Carvalho 2030 - Vila Julia</p>
                <p className="text-gray-600">Uruguaiana - RS - Cep: 97500-440</p>
                <p className="text-gray-600">Fone: +55 (55) 3413-6414</p>
              </div>
            </div>

            {/* Map */}
            <div className="h-[500px] bg-gray-200 rounded-lg overflow-hidden shadow-md">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14608.70440190372!2d-48.76732324364072!3d-26.852353121646114!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94d8ccfd337050a1%3A0x83c70cf1ffd6dc88!2sINLOG%20Operador%20Log%C3%ADstico!5e0!3m2!1spt-BR!2sbr!4v1711045425479!5m2!1spt-BR!2sbr" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
