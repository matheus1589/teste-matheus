import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import Image from "next/image"
import { CheckCircle2 } from 'lucide-react'

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      
      <main className="flex-1">
        {/* Hero Section */}
        <div className="relative h-[300px] bg-gray-900 flex items-center justify-center">
          <div className="absolute inset-0 overflow-hidden">
            <Image 
              src="/logistics-worker-tablet.jpg" 
              alt="Quem Somos" 
              fill
              className="object-cover opacity-40"
            />
          </div>
          <div className="relative z-10 text-center text-white px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Quem Somos</h1>
            <p className="text-xl max-w-2xl mx-auto">Excelência em transporte e armazenagem desde 2003</p>
          </div>
        </div>

        {/* Content */}
        <div className="container mx-auto px-4 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-[#005f8f] mb-6">Conheça a INLOG</h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  A INLOG é uma empresa de logística em constante busca de alternativas inovadoras. Nós fornecemos aos nossos clientes serviços de armazém geral e transporte rodoviário confiáveis e rápidos, garantindo que suas necessidades logísticas sejam atendidas com excelência, independentemente do destino.
                </p>
                <p>
                  Contamos com uma estrutura preparada para oferecer uma ampla gama de serviços complementares, incluindo armazenagem, ova e desova, remoção de cargas e distribuição.
                </p>
                <p>
                  Mantemos uma constante interação com o ambiente, focados na aprendizagem contínua, no aprimoramento dos processos e na adaptação da estrutura organizacional. Nosso objetivo é aprimorar a qualidade das decisões estratégicas e alinhar as operações com as reais necessidades do negócio.
                </p>
              </div>
            </div>
            <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
              <Image 
                src="/logistics-truck-warehouse.jpg" 
                alt="Operação INLOG" 
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>

        {/* Values */}
        <div className="bg-gray-50 py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center text-[#005f8f] mb-12">Nossos Pilares</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-sm border-t-4 border-[#005f8f]">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <CheckCircle2 className="text-[#005f8f]" /> Consistência
                </h3>
                <p className="text-gray-600">
                  Nosso foco está em atender de forma primorosa os aspectos críticos para os clientes, incluindo baixa sinistralidade, cumprimento dos prazos de coleta e pontualidade nas entregas.
                </p>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-sm border-t-4 border-[#005f8f]">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <CheckCircle2 className="text-[#005f8f]" /> Disponibilidade
                </h3>
                <p className="text-gray-600">
                  O modal rodoviário destaca-se pela disponibilidade de unidades de carga. Na INLOG, operamos com transparência, comprometendo-nos apenas com aquilo que podemos cumprir.
                </p>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-sm border-t-4 border-[#005f8f]">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <CheckCircle2 className="text-[#005f8f]" /> Competitividade
                </h3>
                <p className="text-gray-600">
                  Focados na aprendizagem contínua e aprimoramento dos processos para melhorar a qualidade das decisões estratégicas e alinhar as operações com as necessidades do negócio.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
